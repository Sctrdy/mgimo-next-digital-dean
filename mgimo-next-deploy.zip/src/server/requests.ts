import "server-only";
import { getDb } from "./db";
import { HttpError } from "./errors";
import { notify } from "./notifications";
import type { DeanRequest, Delivery, Language, PublicUser, RequestEvent, RequestInput, RequestStatus, RequestType } from "@/lib/types";
import { STATUS_LABEL } from "@/lib/types";

type TypeRow = { code: string; title: string; description: string; eta_days: number; needs_country: number; default_language: string };

export function getRequestTypes(): RequestType[] {
  return (getDb().prepare("SELECT * FROM request_types ORDER BY sort").all() as TypeRow[]).map((t) => ({
    code: t.code, title: t.title, description: t.description, etaDays: t.eta_days, needsCountry: !!t.needs_country,
    defaultLanguage: t.default_language as Language,
  }));
}

export function getRequestType(code: string) {
  return getRequestTypes().find((t) => t.code === code) ?? null;
}

const LANGS: Language[] = ["ru", "en", "ru+en"];
const DELIVERIES: Delivery[] = ["electronic", "paper"];

/** Нормализация и проверка входных данных — общая для формы и NEXT AI. */
export function validateInput(raw: Partial<RequestInput> & Record<string, unknown>): RequestInput {
  const type = typeof raw.typeCode === "string" ? getRequestType(raw.typeCode) : null;
  if (!type) throw new HttpError(400, "Неизвестный тип обращения");
  const purpose = String(raw.purpose ?? "").trim().slice(0, 200);
  if (purpose.length < 3) throw new HttpError(400, "Укажите, для чего нужен документ");
  const language = LANGS.includes(raw.language as Language) ? (raw.language as Language) : type.defaultLanguage;
  const delivery = DELIVERIES.includes(raw.delivery as Delivery) ? (raw.delivery as Delivery) : "electronic";
  const copies = delivery === "electronic" ? 1 : Math.round(Number(raw.copies ?? 1));
  if (!Number.isFinite(copies) || copies < 1 || copies > 5) throw new HttpError(400, "Количество экземпляров — от 1 до 5");
  const country = type.needsCountry ? String(raw.country ?? "").trim().slice(0, 60) : null;
  if (type.needsCountry && !country) throw new HttpError(400, "Укажите страну назначения");
  const comment = raw.comment ? String(raw.comment).trim().slice(0, 500) : null;
  return { typeCode: type.code, purpose, copies, language, delivery, country, comment };
}

type ReqRow = {
  id: number; number: string; user_id: number; type_code: string; purpose: string; copies: number; language: string; delivery: string;
  country: string | null; comment: string | null; status: string; source: string; created_at: number; updated_at: number;
  title: string; eta_days: number; full_name?: string; group_name?: string | null; faculty?: string;
};

function map(r: ReqRow): DeanRequest {
  return {
    id: r.id, number: r.number, typeCode: r.type_code, title: r.title, purpose: r.purpose, copies: r.copies, language: r.language as Language,
    delivery: r.delivery as Delivery, country: r.country, comment: r.comment, status: r.status as RequestStatus, source: r.source as "form" | "ai",
    createdAt: r.created_at, updatedAt: r.updated_at, etaDays: r.eta_days,
    student: r.full_name ? { id: r.user_id, fullName: r.full_name, group: r.group_name ?? null, faculty: r.faculty ?? "" } : undefined,
  };
}

const BASE = `SELECT r.*, t.title, t.eta_days, u.full_name, u.group_name, u.faculty FROM requests r
  JOIN request_types t ON t.code = r.type_code JOIN users u ON u.id = r.user_id`;

export const ACTIVE: RequestStatus[] = ["submitted", "in_progress", "ready"];

/** Заявки студента — только свои. */
export function listRequests(userId: number): DeanRequest[] {
  return (getDb().prepare(`${BASE} WHERE r.user_id = ? ORDER BY r.created_at DESC`).all(userId) as ReqRow[]).map(map);
}

function events(requestId: number): RequestEvent[] {
  return (getDb().prepare("SELECT * FROM request_events WHERE request_id = ? ORDER BY at").all(requestId) as {
    id: number; at: number; status: string | null; actor: string; comment: string | null;
  }[]).map((e) => ({ id: e.id, at: e.at, status: e.status as RequestStatus | null, actor: e.actor, comment: e.comment }));
}

/** Одна заявка с учётом прав: студент видит только свою, сотрудник — любую. Чужая = 404. */
export function getRequest(user: PublicUser, id: number): DeanRequest {
  const row = getDb().prepare(`${BASE} WHERE r.id = ?`).get(id) as ReqRow | undefined;
  if (!row || (user.role !== "staff" && row.user_id !== user.id)) throw new HttpError(404, "Заявка не найдена");
  return { ...map(row), events: events(row.id) };
}

function nextNumber() {
  const { m } = getDb().prepare("SELECT MAX(CAST(SUBSTR(number, 7) AS INTEGER)) AS m FROM requests").get() as { m: number | null };
  return `MN-26-${String((m ?? 1000) + 1).padStart(5, "0")}`;
}

export function createRequest(user: PublicUser, input: RequestInput, source: "form" | "ai" = "form"): DeanRequest {
  if (user.role !== "student") throw new HttpError(403, "Подавать обращения могут только студенты");
  const v = validateInput(input as RequestInput & Record<string, unknown>);
  const db = getDb();
  const now = Date.now();
  const id = db.transaction(() => {
    const rid = db
      .prepare(`INSERT INTO requests (number,user_id,type_code,purpose,copies,language,delivery,country,comment,status,source,created_at,updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,'submitted',?,?,?)`)
      .run(nextNumber(), user.id, v.typeCode, v.purpose, v.copies, v.language, v.delivery, v.country ?? null, v.comment ?? null, source, now, now)
      .lastInsertRowid as number;
    db.prepare("INSERT INTO request_events (request_id,at,status,actor,comment) VALUES (?,?,'submitted',?,?)").run(
      rid, now, source === "ai" ? "Студент через NEXT AI" : "Студент", null,
    );
    return rid;
  })();
  const r = getRequest(user, id);
  notify(user.id, "request", "Обращение принято", `${r.number} · ${r.title}. Срок подготовки — до ${r.etaDays} раб. дн.`, `/dean/${id}`);
  return r;
}

// ---------- кабинет сотрудника ----------

export function staffListRequests(filter: { status?: string; q?: string } = {}): DeanRequest[] {
  const where: string[] = [];
  const args: unknown[] = [];
  if (filter.status && filter.status !== "all") {
    if (filter.status === "active") where.push("r.status IN ('submitted','in_progress','ready')");
    else { where.push("r.status = ?"); args.push(filter.status); }
  }
  if (filter.q) {
    where.push("(lc(r.number) LIKE ? OR lc(u.full_name) LIKE ? OR lc(t.title) LIKE ? OR lc(u.group_name) LIKE ? OR lc(r.purpose) LIKE ?)");
    const q = `%${filter.q.toLowerCase().replace(/[%_]/g, "")}%`;
    args.push(q, q, q, q, q);
  }
  const sql = `${BASE} ${where.length ? "WHERE " + where.join(" AND ") : ""}
    ORDER BY CASE r.status WHEN 'submitted' THEN 0 WHEN 'in_progress' THEN 1 WHEN 'ready' THEN 2 ELSE 3 END, r.created_at DESC`;
  return (getDb().prepare(sql).all(...args) as ReqRow[]).map(map);
}

const TRANSITIONS: Record<RequestStatus, RequestStatus[]> = {
  submitted: ["in_progress", "rejected"],
  in_progress: ["ready", "rejected"],
  ready: ["issued"],
  issued: [],
  rejected: [],
};

export function allowedTransitions(s: RequestStatus) {
  return TRANSITIONS[s];
}

export function staffUpdate(staff: PublicUser, id: number, change: { status?: string | null; comment?: string | null }) {
  if (staff.role !== "staff") throw new HttpError(403, "Недостаточно прав");
  const req = getRequest(staff, id);
  const comment = change.comment ? String(change.comment).trim().slice(0, 800) : null;
  const status = (change.status || null) as RequestStatus | null;
  if (!status && !comment) throw new HttpError(400, "Нет изменений");
  if (status && !TRANSITIONS[req.status].includes(status)) throw new HttpError(409, `Нельзя перевести из «${STATUS_LABEL[req.status]}» в «${STATUS_LABEL[status] ?? status}»`);
  if (status === "rejected" && !comment) throw new HttpError(400, "Укажите причину отклонения");
  const db = getDb();
  const now = Date.now();
  const actor = staff.fullName.split(" ").map((p, i) => (i === 0 ? p : p[0] + ".")).join(" ");
  db.transaction(() => {
    if (status) db.prepare("UPDATE requests SET status = ?, updated_at = ? WHERE id = ?").run(status, now, id);
    else db.prepare("UPDATE requests SET updated_at = ? WHERE id = ?").run(now, id);
    db.prepare("INSERT INTO request_events (request_id,at,status,actor,comment) VALUES (?,?,?,?,?)").run(id, now, status, actor, comment);
  })();
  const owner = req.student!.id;
  if (status) {
    const titles: Record<RequestStatus, string> = {
      submitted: "Обращение принято",
      in_progress: "Обращение взято в работу",
      ready: `${req.title} — готово`,
      issued: "Документ выдан",
      rejected: "Обращение отклонено",
    };
    notify(owner, "request", titles[status], `${req.number}${comment ? ` · ${comment}` : ` · статус «${STATUS_LABEL[status]}»`}`, `/dean/${id}`);
  } else {
    notify(owner, "request", "Комментарий деканата", `${req.number} · ${comment}`, `/dean/${id}`);
  }
  return getRequest(staff, id);
}

export function staffStats() {
  const rows = getDb().prepare("SELECT status, COUNT(*) AS n FROM requests GROUP BY status").all() as { status: RequestStatus; n: number }[];
  const by = Object.fromEntries(rows.map((r) => [r.status, r.n])) as Partial<Record<RequestStatus, number>>;
  return { submitted: by.submitted ?? 0, in_progress: by.in_progress ?? 0, ready: by.ready ?? 0, done: (by.issued ?? 0) + (by.rejected ?? 0) };
}
