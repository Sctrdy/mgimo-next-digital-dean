import "server-only";
import { getDb } from "./db";
import { getAssessments } from "./schedule";
import { addDays, diffDays, moscowNow, studyDay, type Now } from "@/lib/time";
import type { CourseProgress, SessionResult } from "@/lib/types";

export function markFor(score: number, control: string) {
  if (control === "Зачёт") return score >= 60 ? "зачтено" : "не зачтено";
  if (score >= 90) return "отлично";
  if (score >= 75) return "хорошо";
  if (score >= 60) return "удовл.";
  return "неуд.";
}

type CourseRow = { id: number; name: string; short: string; teacher: string; control: string; credits: number; hours_week: number };

export function getCourses(userId: number) {
  return getDb().prepare("SELECT * FROM courses WHERE user_id = ? ORDER BY id").all(userId) as CourseRow[];
}

export function getCourseProgress(userId: number, now: Now = moscowNow()): CourseProgress[] {
  const asm = getAssessments(userId, now);
  return getCourses(userId).map((c) => {
    const items = asm.filter((a) => a.courseId === c.id);
    const graded = items.filter((a) => a.score !== null);
    return {
      courseId: c.id, name: c.name, control: c.control, teacher: c.teacher, credits: c.credits,
      earned: graded.reduce((s, a) => s + (a.score ?? 0), 0),
      gradedMax: graded.reduce((s, a) => s + a.maxScore, 0),
      totalMax: items.reduce((s, a) => s + a.maxScore, 0),
      doneCount: items.filter((a) => a.past).length,
      totalCount: items.length,
      items,
    };
  });
}

type SessRow = { semester: string; sem_order: number; course: string; control: string; score: number; credits: number; retake_offset_days: number | null };

export function getSessionResults(userId: number): SessionResult[] {
  const rows = getDb().prepare("SELECT * FROM session_results WHERE user_id = ? ORDER BY sem_order, id").all(userId) as SessRow[];
  return rows.map((r) => ({
    semester: r.semester, order: r.sem_order, course: r.course, control: r.control, score: r.score,
    mark: markFor(r.score, r.control), credits: r.credits, passed: r.score >= 60,
  }));
}

export function getDebts(userId: number, now: Now = moscowNow()) {
  const rows = getDb()
    .prepare("SELECT * FROM session_results WHERE user_id = ? AND score < 60 ORDER BY sem_order")
    .all(userId) as SessRow[];
  return rows.map((r) => ({
    course: r.course, semester: r.semester, control: r.control, score: r.score,
    retakeDate: r.retake_offset_days !== null ? studyDay(addDays(now.date, r.retake_offset_days), 0) : null,
  }));
}

const weighted = (list: { score: number; credits: number }[]) => {
  const cr = list.reduce((s, r) => s + r.credits, 0);
  return cr ? Math.round((list.reduce((s, r) => s + r.score * r.credits, 0) / cr) * 10) / 10 : null;
};

export function getAcademicSummary(userId: number, now: Now = moscowNow()) {
  const sessions = getSessionResults(userId);
  const progress = getCourseProgress(userId, now);
  const asm = getAssessments(userId, now);
  const earned = progress.reduce((s, p) => s + p.earned, 0);
  const gradedMax = progress.reduce((s, p) => s + p.gradedMax, 0);
  const upcoming = asm.filter((a) => !a.past && a.kind !== "Экзамен" && a.kind !== "Зачёт" && diffDays(now.date, a.date) <= 14);

  const semesters = [...new Set(sessions.map((s) => s.order))].map((order) => {
    const list = sessions.filter((s) => s.order === order);
    return { order, label: list[0].semester, average: weighted(list) ?? 0, count: list.length, passed: list.filter((s) => s.passed).length };
  });

  return {
    average: weighted(sessions),
    currentPercent: gradedMax ? Math.round((earned / gradedMax) * 100) : null,
    currentEarned: earned,
    currentGradedMax: gradedMax,
    closed: sessions.filter((s) => s.passed).length,
    totalClosedTarget: sessions.length,
    upcomingCount: upcoming.length,
    nextUpcoming: upcoming[0] ?? null,
    debts: getDebts(userId, now),
    semesters,
    pendingGrades: asm.filter((a) => a.past && a.score === null).length,
  };
}

/** Нагрузка: часы аудиторных занятий по дням текущей недели и число событий контроля по неделям. */
export function getWorkload(userId: number, lessonsByDay: { date: string; count: number }[], now: Now = moscowNow()) {
  const asm = getAssessments(userId, now).filter((a) => !a.past);
  const weeks = Array.from({ length: 6 }, (_, i) => {
    const from = addDays(now.date, i * 7);
    const to = addDays(from, 6);
    return { label: i === 0 ? "Эта" : `+${i}`, from, count: asm.filter((a) => a.date >= from && a.date <= to).length };
  });
  return { days: lessonsByDay.map((d) => ({ ...d, hours: Math.round(d.count * 80 / 6) / 10 })), weeks };
}
