import "server-only";
import type { PublicUser } from "@/lib/types";

export type UserRow = {
  id: number; login: string; password_hash: string; role: "student" | "staff"; full_name: string; short_name: string;
  faculty: string; program: string; course: number | null; group_name: string | null; study_year: string;
  student_code: string | null; position: string | null;
};

export function toPublic(r: UserRow): PublicUser {
  return {
    id: r.id, login: r.login, role: r.role, fullName: r.full_name, shortName: r.short_name, faculty: r.faculty,
    program: r.program, course: r.course, group: r.group_name, studyYear: r.study_year, studentCode: r.student_code, position: r.position,
  };
}

