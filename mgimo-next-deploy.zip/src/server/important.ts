import "server-only";
import { getAssessments, getLessons, getTasks } from "./schedule";
import { getDebts } from "./academics";
import { listRequests, ACTIVE } from "./requests";
import { addDays, diffDays, inDays, moscowNow, relDay, studyDay, type Now } from "@/lib/time";
import type { ImportantItem } from "@/lib/types";

const q = (s: string) => `/assistant?q=${encodeURIComponent(s)}`;

/** «Важное для тебя»: только будущие события, у каждого — конкретное действие. */
export function getImportant(userId: number, now: Now = moscowNow()): ImportantItem[] {
  const items: ImportantItem[] = [];

  for (const a of getAssessments(userId, now)) {
    if (a.past) continue; // прошедшие события никогда не показываем как будущие
    const d = diffDays(now.date, a.date);
    const isFinal = a.kind === "Экзамен" || a.kind === "Зачёт";
    if (isFinal ? d > 45 : d > 14) continue;
    const when = `${relDay(a.date, now.date)}${a.time && a.time !== "23:59" ? `, ${a.time}` : a.time === "23:59" ? ", до 23:59" : ""}`;
    if (a.kind === "Дедлайн" || (a.kind === "Эссе" && !a.room)) {
      items.push({
        id: `a${a.id}`, kind: "deadline", title: a.title, subtitle: `${a.course} · ${inDays(d)}`, when, urgency: d,
        tone: d <= 2 ? "red" : "amber", action: { label: "План работы", href: q(`Помоги распланировать: «${a.title}» по курсу «${a.course}»`) },
      });
    } else if (isFinal) {
      // ближайший итоговый контроль — один, без дублирования всей сессии
      if (items.some((i) => i.kind === "exam")) continue;
      items.push({
        id: `a${a.id}`, kind: "exam", title: `${a.kind}: ${a.course}`, subtitle: `${inDays(d)}${a.room ? ` · ${a.room}` : ""}`, when, urgency: d + 5,
        tone: "violet", action: { label: "План подготовки", href: q(`Помоги подготовиться к экзамену: ${a.course}`) },
      });
    } else {
      items.push({
        id: `a${a.id}`, kind: "assessment", title: `${a.kind}: ${a.course}`, subtitle: `${a.title.replace(/^[^:]+:\s*/, "")} · ${inDays(d)}`, when,
        urgency: d, tone: d <= 3 ? "red" : "blue", action: { label: "Подготовиться", href: q(`Помоги подготовиться: ${a.title} (${a.course})`) },
      });
    }
  }

  for (const t of getTasks(userId, now)) {
    if (t.done || !t.dueDate) continue;
    const d = diffDays(now.date, t.dueDate);
    if (d >= 0) continue; // будущие задачи — в блоке «Мои задачи», здесь только просроченные
    items.push({
      id: `t${t.id}`, kind: "task", title: t.title, subtitle: d < 0 ? "Просрочено" : `Личная задача · ${inDays(d)}`,
      when: d < 0 ? relDay(t.dueDate, now.date) : `${relDay(t.dueDate, now.date)}${t.dueTime ? `, ${t.dueTime}` : ""}`,
      urgency: d - 0.5, tone: d < 0 ? "red" : "slate", action: { label: "Открыть задачи", href: "/schedule#tasks" },
    });
  }

  for (const r of listRequests(userId)) {
    if (!ACTIVE.includes(r.status)) continue;
    const ready = r.status === "ready";
    items.push({
      id: `r${r.id}`, kind: "request", title: ready ? `${r.title} готова` : r.title,
      subtitle: `${r.number} · ${ready ? "можно получить" : r.status === "in_progress" ? "в работе" : "ожидает обработки"}`,
      when: "", urgency: ready ? 0.2 : 8, tone: ready ? "green" : "slate",
      action: { label: ready ? "Получить" : "Статус", href: `/dean/${r.id}` },
    });
  }

  const horizon = studyDay(now.date, 3);
  for (const l of getLessons(userId, now.date, horizon, now)) {
    if (l.status === "normal") continue;
    if (l.date === now.date && l.end <= `${String(Math.floor(now.minutes / 60)).padStart(2, "0")}:${String(now.minutes % 60).padStart(2, "0")}`) continue;
    const d = diffDays(now.date, l.date);
    const what = l.status === "cancelled" ? "отменено" : l.status === "added" ? "добавлено" : l.was?.room ? `ауд. ${l.was.room} → ${l.room}` : "замена преподавателя";
    items.push({
      id: `l${l.id}`, kind: "change", title: `${l.course}: ${what}`, subtitle: l.note ?? "", when: `${relDay(l.date, now.date)}, ${l.start}`,
      urgency: d + 0.3, tone: "amber", action: { label: "В расписании", href: `/schedule?date=${l.date}` },
    });
  }

  for (const debt of getDebts(userId, now)) {
    const d = debt.retakeDate ? diffDays(now.date, debt.retakeDate) : 30;
    items.push({
      id: `debt-${debt.course}`, kind: "debt", title: `Задолженность: ${debt.course}`,
      subtitle: debt.retakeDate && d >= 0 ? `Пересдача ${relDay(debt.retakeDate, now.date)} · нужно заявление` : `${debt.semester} · нужно согласовать пересдачу`,
      when: debt.retakeDate && d >= 0 ? relDay(debt.retakeDate, now.date) : "", urgency: Math.min(d, 1), tone: "red",
      action: { label: "Подать заявление", href: "/dean/new?type=retake" },
    });
  }

  return items.sort((a, b) => a.urgency - b.urgency);
}

export function weekMarks(userId: number, monday: string, now: Now = moscowNow()) {
  const sunday = addDays(monday, 6);
  const lessons = getLessons(userId, monday, sunday, now);
  const asm = getAssessments(userId, now);
  return Array.from({ length: 7 }, (_, i) => {
    const date = addDays(monday, i);
    const ls = lessons.filter((l) => l.date === date && l.status !== "cancelled");
    return {
      date,
      lessons: ls.length,
      changes: lessons.some((l) => l.date === date && l.status !== "normal"),
      control: asm.some((a) => a.date === date),
    };
  });
}
