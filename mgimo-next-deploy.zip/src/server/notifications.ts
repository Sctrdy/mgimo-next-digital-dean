import "server-only";
import { getDb } from "./db";
import type { Notification } from "@/lib/types";

const PREF_BY_KIND: Record<Notification["kind"], string | null> = { request: "requests", schedule: "schedule", grade: "grades", system: null };

export function notify(userId: number, kind: Notification["kind"], title: string, body: string, href: string | null) {
  const db = getDb();
  // статусы обращений приходят всегда; остальное — по настройкам
  if (kind !== "request") {
    const row = db.prepare("SELECT notify_prefs FROM users WHERE id = ?").get(userId) as { notify_prefs: string } | undefined;
    const key = PREF_BY_KIND[kind];
    if (row && key && JSON.parse(row.notify_prefs)[key] === false) return;
  }
  db.prepare("INSERT INTO notifications (user_id,at,kind,title,body,href,read) VALUES (?,?,?,?,?,?,0)").run(userId, Date.now(), kind, title, body, href);
}

export function listNotifications(userId: number, limit = 30): Notification[] {
  return (getDb().prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY at DESC LIMIT ?").all(userId, limit) as {
    id: number; at: number; kind: string; title: string; body: string; href: string | null; read: number;
  }[]).map((n) => ({ id: n.id, at: n.at, kind: n.kind as Notification["kind"], title: n.title, body: n.body, href: n.href, read: !!n.read }));
}

export function unreadCount(userId: number) {
  return (getDb().prepare("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read = 0").get(userId) as { n: number }).n;
}

export function markRead(userId: number, id?: number) {
  if (id) getDb().prepare("UPDATE notifications SET read = 1 WHERE user_id = ? AND id = ?").run(userId, id);
  else getDb().prepare("UPDATE notifications SET read = 1 WHERE user_id = ?").run(userId);
}

export function getPrefs(userId: number): Record<string, boolean> {
  const row = getDb().prepare("SELECT notify_prefs FROM users WHERE id = ?").get(userId) as { notify_prefs: string };
  return JSON.parse(row.notify_prefs);
}

export function setPrefs(userId: number, prefs: Record<string, unknown>) {
  const cur = getPrefs(userId);
  for (const k of ["requests", "schedule", "grades", "digest"]) if (typeof prefs[k] === "boolean") cur[k] = prefs[k] as boolean;
  cur.requests = true; // статусы обращений отключить нельзя
  getDb().prepare("UPDATE users SET notify_prefs = ? WHERE id = ?").run(JSON.stringify(cur), userId);
  return cur;
}
