import "server-only";
import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";
import { getDb } from "./db";
import type { PublicUser } from "@/lib/types";
import { HttpError } from "./errors";
import { toPublic, type UserRow } from "./users";
export { HttpError };

export const SESSION_COOKIE = "mn_session";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7;

const sha = (t: string) => crypto.createHash("sha256").update(t).digest("hex");

// простая защита от перебора паролей (в памяти процесса)
const attempts = new Map<string, { n: number; until: number }>();

export async function verifyCredentials(login: string, password: string): Promise<PublicUser | "locked" | null> {
  const key = login.toLowerCase().trim();
  const a = attempts.get(key);
  if (a && a.until > Date.now()) return "locked";
  const row = getDb().prepare("SELECT * FROM users WHERE login = ?").get(key) as UserRow | undefined;
  const ok = row ? await bcrypt.compare(password, row.password_hash) : false;
  if (!ok || !row) {
    const n = (a?.n ?? 0) + 1;
    attempts.set(key, { n, until: n >= 5 ? Date.now() + 60_000 : 0 });
    return null;
  }
  attempts.delete(key);
  return toPublic(row);
}

export function createSession(userId: number) {
  const token = crypto.randomBytes(32).toString("base64url");
  const db = getDb();
  db.prepare("DELETE FROM sessions WHERE expires_at < ?").run(Date.now());
  db.prepare("INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?,?,?)").run(sha(token), userId, Date.now() + SESSION_TTL_MS);
  return { token, maxAge: SESSION_TTL_MS / 1000 };
}

export function destroySession(token: string | undefined) {
  if (token) getDb().prepare("DELETE FROM sessions WHERE token_hash = ?").run(sha(token));
}

export function userByToken(token: string | undefined): PublicUser | null {
  if (!token) return null;
  const row = getDb()
    .prepare("SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?")
    .get(sha(token), Date.now()) as UserRow | undefined;
  return row ? toPublic(row) : null;
}

export async function currentUser(): Promise<PublicUser | null> {
  const store = await cookies();
  return userByToken(store.get(SESSION_COOKIE)?.value);
}

/** Для страниц: без сессии — на /login */
export async function requireUser(): Promise<PublicUser> {
  const u = await currentUser();
  if (!u) redirect("/login");
  return u;
}

export async function requireStudentPage(): Promise<PublicUser> {
  const u = await requireUser();
  if (u.role !== "student") redirect("/staff");
  return u;
}

export async function requireStaffPage(): Promise<PublicUser> {
  const u = await requireUser();
  if (u.role !== "staff") redirect("/schedule");
  return u;
}


/** Для API: проверка сессии, роли и происхождения запроса (CSRF). */
export async function apiUser(opts: { role?: "student" | "staff"; mutating?: boolean } = {}): Promise<PublicUser> {
  if (opts.mutating) {
    const h = await headers();
    const origin = h.get("origin");
    const host = h.get("x-forwarded-host") ?? h.get("host");
    if (origin && host && new URL(origin).host !== host) throw new HttpError(403, "Запрос отклонён");
  }
  const u = await currentUser();
  if (!u) throw new HttpError(401, "Требуется вход");
  if (opts.role && u.role !== opts.role) throw new HttpError(403, "Недостаточно прав");
  return u;
}

export function apiError(e: unknown) {
  if (e instanceof HttpError) return Response.json({ error: e.message }, { status: e.status });
  console.error(e);
  return Response.json({ error: "Внутренняя ошибка сервера" }, { status: 500 });
}
