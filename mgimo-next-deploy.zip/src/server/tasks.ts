import "server-only";
import { getDb } from "./db";
import { HttpError } from "./errors";

export function createTask(userId: number, b: { title?: unknown; dueDate?: unknown; dueTime?: unknown; courseId?: unknown }) {
  const title = String(b.title ?? "").trim().slice(0, 140);
  if (title.length < 2) throw new HttpError(400, "Опишите задачу хотя бы парой слов");
  const dueDate = typeof b.dueDate === "string" && /^\d{4}-\d{2}-\d{2}$/.test(b.dueDate) ? b.dueDate : null;
  const dueTime = typeof b.dueTime === "string" && /^\d{2}:\d{2}$/.test(b.dueTime) ? b.dueTime : null;
  let courseId: number | null = null;
  if (b.courseId !== null && b.courseId !== undefined && b.courseId !== "") {
    const c = getDb().prepare("SELECT id FROM courses WHERE id = ? AND user_id = ?").get(Number(b.courseId), userId) as { id: number } | undefined;
    if (!c) throw new HttpError(400, "Дисциплина не найдена");
    courseId = c.id;
  }
  const id = getDb()
    .prepare("INSERT INTO tasks (user_id,title,due_date,due_time,done,course_id,created_at) VALUES (?,?,?,?,0,?,?)")
    .run(userId, title, dueDate, dueTime, courseId, Date.now()).lastInsertRowid as number;
  return { id, title, dueDate, dueTime, courseId };
}

export function setTaskDone(userId: number, id: number, done: boolean) {
  const r = getDb().prepare("UPDATE tasks SET done = ? WHERE id = ? AND user_id = ?").run(done ? 1 : 0, id, userId);
  if (!r.changes) throw new HttpError(404, "Задача не найдена");
}

export function deleteTask(userId: number, id: number) {
  const r = getDb().prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?").run(id, userId);
  if (!r.changes) throw new HttpError(404, "Задача не найдена");
}
