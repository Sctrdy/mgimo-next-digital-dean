import "server-only";
import { getDb } from "../db";
import { TOOLS, toolSchemas, systemPrompt, type ToolContext } from "./tools";
import { fallbackAnswer } from "./fallback";
import { moscowNow } from "@/lib/time";
import type { ChatMessage, ChatMeta, PublicUser } from "@/lib/types";

const MAX_STEPS = 5;
const API_URL = process.env.DEEPSEEK_BASE_URL ?? "https://api.deepseek.com";

type Msg =
  | { role: "system" | "user"; content: string }
  | { role: "assistant"; content: string | null; tool_calls?: ToolCall[] }
  | { role: "tool"; tool_call_id: string; content: string };
type ToolCall = { id: string; type: "function"; function: { name: string; arguments: string } };

type Row = { id: number; role: "user" | "assistant"; content: string; meta: string | null; at: number };

export function history(userId: number, limit = 60): ChatMessage[] {
  const rows = getDb().prepare("SELECT * FROM (SELECT * FROM chat_messages WHERE user_id = ? ORDER BY id DESC LIMIT ?) ORDER BY id").all(userId, limit) as Row[];
  return rows.map((r) => ({ id: r.id, role: r.role, content: r.content, at: r.at, meta: r.meta ? (JSON.parse(r.meta) as ChatMeta) : null }));
}

export function saveMessage(userId: number, role: "user" | "assistant", content: string, meta: ChatMeta | null = null): ChatMessage {
  const at = Date.now();
  const id = getDb().prepare("INSERT INTO chat_messages (user_id,role,content,meta,at) VALUES (?,?,?,?,?)").run(userId, role, content, meta ? JSON.stringify(meta) : null, at).lastInsertRowid as number;
  return { id, role, content, at, meta };
}

export function clearHistory(userId: number) {
  getDb().prepare("DELETE FROM chat_messages WHERE user_id = ?").run(userId);
}

async function callModel(messages: Msg[], key: string, signal: AbortSignal) {
  const r = await fetch(`${API_URL}/chat/completions`, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model: process.env.DEEPSEEK_MODEL || "deepseek-chat",
      messages,
      tools: toolSchemas(),
      tool_choice: "auto",
      temperature: 0.3,
      max_tokens: 1200,
    }),
    signal,
  });
  if (!r.ok) throw new Error(`DeepSeek ${r.status}: ${(await r.text()).slice(0, 200)}`);
  const d = (await r.json()) as { choices: { message: { content: string | null; tool_calls?: ToolCall[] } }[] };
  return d.choices[0].message;
}

/** Ответ на сообщение студента: цикл «модель → инструменты → модель», не больше MAX_STEPS шагов. */
export async function answer(user: PublicUser, text: string): Promise<{ content: string; meta: ChatMeta }> {
  const now = moscowNow();
  const ctx: ToolContext = { user, now, drafts: [] };
  const used = new Set<string>();
  const key = process.env.DEEPSEEK_API_KEY;

  if (!key) return fallbackAnswer(ctx, text);

  // последнее сохранённое сообщение — это текущий вопрос, он добавляется ниже отдельно
  const past = history(user.id, 15)
    .slice(0, -1)
    .filter((m) => m.content.trim())
    .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }) as Msg);
  const messages: Msg[] = [{ role: "system", content: systemPrompt(user, now) }, ...past, { role: "user", content: text }];

  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 45_000);
  try {
    for (let step = 0; step < MAX_STEPS; step++) {
      const msg = await callModel(messages, key, ctl.signal);
      if (!msg.tool_calls?.length) {
        return finalize(msg.content ?? "", ctx, used);
      }
      messages.push({ role: "assistant", content: msg.content ?? "", tool_calls: msg.tool_calls });
      for (const call of msg.tool_calls) {
        const tool = TOOLS[call.function.name];
        let result: unknown;
        if (!tool) result = { error: "Неизвестный инструмент" };
        else {
          used.add(tool.label);
          let args: Record<string, unknown> = {};
          try {
            args = JSON.parse(call.function.arguments || "{}");
          } catch {}
          try {
            result = tool.run(ctx, args);
          } catch {
            result = { error: "Не удалось получить данные" };
          }
        }
        messages.push({ role: "tool", tool_call_id: call.id, content: JSON.stringify(result).slice(0, 12000) });
      }
    }
    return finalize("Я собрал данные, но не успел сформулировать ответ. Попробуй задать вопрос короче.", ctx, used);
  } catch (e) {
    console.error("[NEXT AI]", e instanceof Error ? e.message : e);
    const fb = fallbackAnswer({ ...ctx, drafts: [] }, text);
    return { content: fb.content, meta: { ...fb.meta, fallback: true } };
  } finally {
    clearTimeout(timer);
  }
}

function finalize(content: string, ctx: ToolContext, used: Set<string>): { content: string; meta: ChatMeta } {
  const meta: ChatMeta = { tools: [...used] };
  // показываем последний подготовленный черновик; более ранние из этого же ответа отменяем
  if (ctx.drafts.length) {
    const last = ctx.drafts[ctx.drafts.length - 1];
    for (const d of ctx.drafts.slice(0, -1)) getDb().prepare("UPDATE drafts SET status = 'cancelled' WHERE id = ?").run(d.draftId);
    meta.draft = last;
  }
  return { content: content.trim() || (meta.draft ? "Черновик готов — проверь данные и подтверди отправку." : "Не получилось ответить. Попробуй переформулировать."), meta };
}
