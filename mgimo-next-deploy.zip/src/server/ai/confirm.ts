import "server-only";
import { getDb } from "../db";
import { HttpError } from "../errors";
import { createRequest } from "../requests";
import { saveMessage } from "./agent";
import type { ChatMeta, PublicUser, RequestInput } from "@/lib/types";

type DraftRow = { id: number; user_id: number; payload: string; status: string; created_at: number };

const DRAFT_TTL = 24 * 60 * 60 * 1000;

function ownDraft(user: PublicUser, draftId: number) {
  const d = getDb().prepare("SELECT * FROM drafts WHERE id = ?").get(draftId) as DraftRow | undefined;
  // чужой или несуществующий черновик — одинаковый ответ, чтобы не раскрывать существование
  if (!d || d.user_id !== user.id) throw new HttpError(404, "Черновик не найден");
  if (d.status !== "pending") throw new HttpError(409, d.status === "confirmed" ? "Эта заявка уже отправлена" : "Черновик отменён");
  if (Date.now() - d.created_at > DRAFT_TTL) throw new HttpError(410, "Черновик устарел — попроси NEXT AI подготовить его заново");
  return d;
}

function updateCardStatus(userId: number, draftId: number, patch: Partial<ChatMeta> & { status: "confirmed" | "cancelled" }) {
  const db = getDb();
  const rows = db.prepare("SELECT id, meta FROM chat_messages WHERE user_id = ? AND meta LIKE ?").all(userId, `%"draftId":${draftId},%`) as { id: number; meta: string }[];
  for (const r of rows) {
    const meta = JSON.parse(r.meta) as ChatMeta;
    if (meta.draft?.draftId !== draftId) continue;
    meta.draft.status = patch.status;
    if (patch.createdRequest) meta.createdRequest = patch.createdRequest;
    db.prepare("UPDATE chat_messages SET meta = ? WHERE id = ?").run(JSON.stringify(meta), r.id);
  }
}

/** Действие пользователя «Подтвердить»: только здесь черновик NEXT AI превращается в настоящую заявку. */
export function confirmDraft(user: PublicUser, draftId: number) {
  const d = ownDraft(user, draftId);
  const db = getDb();
  // атомарно забираем черновик, чтобы двойной клик не создал две заявки
  const taken = db.prepare("UPDATE drafts SET status = 'confirmed' WHERE id = ? AND status = 'pending'").run(d.id);
  if (!taken.changes) throw new HttpError(409, "Эта заявка уже отправлена");
  let request;
  try {
    request = createRequest(user, JSON.parse(d.payload) as RequestInput, "ai");
  } catch (e) {
    db.prepare("UPDATE drafts SET status = 'pending' WHERE id = ?").run(d.id);
    throw e;
  }
  db.prepare("UPDATE drafts SET request_id = ? WHERE id = ?").run(request.id, d.id);
  updateCardStatus(user.id, draftId, { status: "confirmed", createdRequest: { id: request.id, number: request.number } });
  const message = saveMessage(
    user.id,
    "assistant",
    `Готово: заявка **${request.number}** «${request.title}» отправлена в деканат. Срок подготовки — до ${request.etaDays} рабочих дней. Я пришлю уведомление, когда статус изменится.`,
  );
  return { request, message };
}

export function cancelDraft(user: PublicUser, draftId: number) {
  const d = ownDraft(user, draftId);
  getDb().prepare("UPDATE drafts SET status = 'cancelled' WHERE id = ?").run(d.id);
  updateCardStatus(user.id, draftId, { status: "cancelled" });
  return { message: saveMessage(user.id, "assistant", "Хорошо, черновик отменён. Если понадобится документ — просто напиши.") };
}
