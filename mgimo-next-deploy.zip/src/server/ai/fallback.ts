import "server-only";
import { createDraft, type ToolContext } from "./tools";
import { getAssessments, getDayStatus, getLessons, getTasks } from "../schedule";
import { getAcademicSummary, getCourseProgress } from "../academics";
import { listRequests, ACTIVE } from "../requests";
import { HttpError } from "../errors";
import { addDays, diffDays, inDays, relDay, studyDay, wdFull, dateLong, plural } from "@/lib/time";
import type { ChatMeta, Lesson, RequestInput } from "@/lib/types";
import { STATUS_LABEL } from "@/lib/types";

// Резервный режим без LLM: распознаёт намерение по ключевым словам и отвечает
// по тем же инструментам и с теми же правилами доступа.

const COUNTRIES: Record<string, string> = {
  итали: "Италия", франци: "Франция", германи: "Германия", испани: "Испания", китай: "Китай", кита: "Китай", сша: "США", оаэ: "ОАЭ",
  турци: "Турция", япони: "Япония", великобритани: "Великобритания", британи: "Великобритания", коре: "Республика Корея", греци: "Греция",
  португали: "Португалия", австри: "Австрия", швейцари: "Швейцария", нидерланд: "Нидерланды", финлянди: "Финляндия", сербию: "Сербия", серби: "Сербия",
  индию: "Индия", инди: "Индия", вьетнам: "Вьетнам", таиланд: "Таиланд", египет: "Египет", бразили: "Бразилия", катар: "Катар",
};

const lessonLine = (l: Lesson) =>
  `- **${l.start}–${l.end}** ${l.course} (${l.type.toLowerCase()}), ${l.room}${l.status === "cancelled" ? " — **отменено**" : l.status !== "normal" ? ` — ${l.note?.toLowerCase()}${l.was?.room ? ` (было ${l.was.room})` : ""}` : ""}`;

export function fallbackAnswer(ctx: ToolContext, raw: string): { content: string; meta: ChatMeta } {
  const t = raw.toLowerCase();
  const { user, now } = ctx;
  const meta: ChatMeta = { tools: [], fallback: true };
  const tag = (label: string) => !meta.tools!.includes(label) && meta.tools!.push(label);

  // --- документы ---
  if (/справк|документ|выписк|транскрипт|военкомат|посольств|виз[аеуы]|соцфонд|социальн|учебн\S* план|пересдач|индивидуальн\S* график/.test(t) && !/статус/.test(t)) {
    tag("Черновик заявки");
    let typeCode = "study_certificate";
    if (/виз|посольств|консульств/.test(t)) typeCode = "visa_certificate";
    else if (/военкомат/.test(t)) typeCode = "military";
    else if (/транскрипт|выписк/.test(t)) typeCode = "transcript";
    else if (/соцфонд|социальн|пенси/.test(t)) typeCode = "social_fund";
    else if (/учебн\S* план/.test(t)) typeCode = "curriculum";
    else if (/пересдач/.test(t)) typeCode = "retake";
    else if (/индивидуальн/.test(t)) typeCode = "individual_plan";

    const country = Object.entries(COUNTRIES).find(([k]) => t.includes(k))?.[1] ?? null;
    if (typeCode === "visa_certificate" && !country) {
      return { content: "Подготовлю справку для визы. **В какую страну** едешь? Напиши, например: «справка для визы в Италию».", meta };
    }
    const purposeMatch = raw.match(/для\s+([^.,!?]{3,80})/i);
    const purpose =
      typeCode === "visa_certificate" ? `Для визы${country ? ` (${country})` : ""}` : purposeMatch ? `Для ${purposeMatch[1].trim()}` : typeCode === "military" ? "Для предоставления в военкомат" : "По месту требования";
    const input: RequestInput = {
      typeCode, purpose, country, copies: 1,
      language: typeCode === "visa_certificate" ? "ru+en" : /англ|english/.test(t) ? "en" : typeCode === "transcript" ? "en" : "ru",
      delivery: /бумаж|оригинал|печат/.test(t) || typeCode === "military" ? "paper" : "electronic",
    };
    try {
      meta.draft = createDraft(user, input);
    } catch (e) {
      return { content: e instanceof HttpError ? e.message : "Не получилось подготовить черновик.", meta };
    }
    return {
      content: `Подготовил черновик: **${meta.draft.type.title}**. Данные профиля подставлены автоматически.\n\nПроверь, всё ли верно, и нажми **«Подтвердить и отправить»** — только после этого заявка уйдёт в деканат.`,
      meta,
    };
  }

  // --- статус обращений ---
  if (/статус|обращени|заявк/.test(t)) {
    tag("Обращения");
    const list = listRequests(user.id);
    const active = list.filter((r) => ACTIVE.includes(r.status));
    if (!list.length) return { content: "Обращений пока нет. Хочешь заказать справку? Просто напиши, какая нужна.", meta };
    const rows = (active.length ? active : list.slice(0, 3)).map((r) => `- **${r.title}**, ${r.number}: ${STATUS_LABEL[r.status].toLowerCase()}`);
    return { content: `${active.length ? `Активных обращений: ${active.length}.` : "Активных обращений нет. Последние:"}\n\n${rows.join("\n")}`, meta };
  }

  // --- подготовка ---
  if (/подготов|помоги|план/.test(t)) {
    tag("Контрольные");
    tag("Оценки");
    const upcoming = getAssessments(user.id, now).filter((a) => !a.past);
    const wantExam = /экзамен|сесси|зач[её]т/.test(t);
    const byCourse = upcoming.find((a) => t.includes(a.course.toLowerCase().slice(0, 6)));
    const target = byCourse ?? upcoming.find((a) => (wantExam ? a.kind === "Экзамен" || a.kind === "Зачёт" : a.kind !== "Экзамен" && a.kind !== "Зачёт")) ?? upcoming[0];
    if (!target) return { content: "Ближайших контрольных и экзаменов нет — можно спокойно закрывать задачи.", meta };
    const days = Math.max(1, diffDays(now.date, target.date));
    const prog = getCourseProgress(user.id, now).find((p) => p.courseId === target.courseId);
    const pct = prog && prog.gradedMax ? Math.round((prog.earned / prog.gradedMax) * 100) : null;
    const steps = days >= 4
      ? [
          `**${relDay(now.date, now.date)}–${relDay(addDays(now.date, Math.floor(days / 3)), now.date)}**: собрать конспекты и список тем, отметить слабые места`,
          `**до ${relDay(addDays(now.date, Math.floor((2 * days) / 3)), now.date)}**: разобрать темы по одной, по 40–60 минут в день`,
          `**${relDay(addDays(target.date, -1), now.date)}**: пробный вариант на время и повторение ошибок`,
        ]
      : ["**Сегодня**: пройтись по конспектам и ключевым определениям", "**Перед событием**: решить 1–2 задания на время и выспаться"];
    return {
      content: `**${target.kind}: ${target.course}** — ${inDays(days)} (${relDay(target.date, now.date)}${target.time && target.time !== "23:59" ? `, ${target.time}` : ""}).${
        pct !== null ? ` Текущий результат по предмету — ${prog!.earned} из ${prog!.gradedMax} (${pct}%).` : ""
      }\n\nПлан:\n${steps.map((s) => `- ${s}`).join("\n")}`,
      meta,
    };
  }

  // --- контрольные ---
  if (/контрольн|тест|дедлайн|экзамен|зач[её]т|сесси|эссе/.test(t)) {
    tag("Контрольные");
    const exams = /экзамен|сесси|зач[её]т/.test(t);
    const list = getAssessments(user.id, now)
      .filter((a) => !a.past && (exams ? a.kind === "Экзамен" || a.kind === "Зачёт" : a.kind !== "Экзамен" && a.kind !== "Зачёт"))
      .slice(0, 5);
    if (!list.length) return { content: exams ? "Зачётов и экзаменов в ближайшее время нет." : "Ближайших контрольных нет.", meta };
    return {
      content: `${exams ? "Ближайший итоговый контроль" : "Ближайшие события контроля"}:\n\n${list
        .map((a) => `- **${relDay(a.date, now.date)}**${a.time && a.time !== "23:59" ? `, ${a.time}` : a.time ? ", до 23:59" : ""}: ${a.title === a.kind ? `${a.kind}, ${a.course}` : `${a.title} (${a.course})`}`)
        .join("\n")}`,
      meta,
    };
  }

  // --- оценки ---
  if (/оценк|балл|успеваем|средн|задолженн|рейтинг/.test(t)) {
    tag("Оценки");
    const s = getAcademicSummary(user.id, now);
    const prog = getCourseProgress(user.id, now).filter((p) => p.gradedMax > 0);
    return {
      content: `Средний балл за прошлые сессии — **${s.average}** из 100, закрыто дисциплин: ${s.closed} из ${s.totalClosedTarget}.${
        s.debts.length ? ` Есть задолженность: **${s.debts.map((d) => d.course).join(", ")}**.` : " Задолженностей нет."
      }\n\nТекущий семестр:\n${prog.map((p) => `- ${p.name}: ${p.earned} из ${p.gradedMax}`).join("\n")}`,
      meta,
    };
  }

  // --- расписание ---
  if (/пар[аыу]|расписан|занят|завтра|сегодня|недел|аудитори|где|когда/.test(t)) {
    tag("Расписание");
    let date = now.date;
    let label = "Сегодня";
    if (/послезавтра/.test(t)) { date = addDays(now.date, 2); label = "Послезавтра"; }
    else if (/завтра/.test(t)) { date = addDays(now.date, 1); label = "Завтра"; }
    else if (!/сегодня/.test(t)) {
      const st = getDayStatus(user.id, now);
      if (st.kind === "next_day") { date = st.date; label = `Сегодня пары закончились. Ближайший учебный день — ${relDay(st.date, now.date)}`; }
    }
    if (/недел/.test(t)) {
      const to = addDays(now.date, 6);
      const ls = getLessons(user.id, now.date, to, now).filter((l) => l.status !== "cancelled");
      const days = [...new Set(ls.map((l) => l.date))];
      return { content: `На ближайшие 7 дней — ${ls.length} ${plural(ls.length, "пара", "пары", "пар")}:\n\n${days.map((d) => `- **${relDay(d, now.date)}**: ${ls.filter((l) => l.date === d).map((l) => `${l.start} ${l.course}`).join(", ")}`).join("\n")}`, meta };
    }
    if (date !== now.date && wdFull(date) === "воскресенье") date = studyDay(date, 0);
    const ls = getLessons(user.id, date, date, now);
    if (!ls.length) return { content: `${label} (${wdFull(date)}, ${dateLong(date)}) занятий нет.`, meta };
    return { content: `${label}, ${wdFull(date)}, ${dateLong(date)}:\n\n${ls.map(lessonLine).join("\n")}`, meta };
  }

  if (/задач|дела/.test(t)) {
    tag("Задачи");
    const open = getTasks(user.id, now).filter((x) => !x.done);
    return { content: open.length ? `Открытые задачи:\n\n${open.map((x) => `- ${x.title}${x.dueDate ? ` — ${relDay(x.dueDate, now.date)}` : ""}`).join("\n")}` : "Открытых задач нет.", meta };
  }

  return {
    content:
      "Я могу:\n\n- показать пары на сегодня, завтра или неделю\n- найти ближайшие контрольные и экзамены\n- рассказать об оценках и задолженностях\n- составить план подготовки\n- подготовить справку или заявление в деканат и проверить статус обращения\n\nСпроси своими словами.",
    meta,
  };
}
