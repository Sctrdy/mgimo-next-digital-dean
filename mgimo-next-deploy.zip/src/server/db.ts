import "server-only";
import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";
import { seed } from "./seed";

const SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  login TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('student','staff')),
  full_name TEXT NOT NULL,
  short_name TEXT NOT NULL,
  faculty TEXT NOT NULL,
  program TEXT NOT NULL,
  course INTEGER,
  group_name TEXT,
  study_year TEXT NOT NULL,
  student_code TEXT,
  position TEXT,
  notify_prefs TEXT NOT NULL DEFAULT '{"requests":true,"schedule":true,"grades":true,"digest":false}'
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS courses (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  name TEXT NOT NULL,
  short TEXT NOT NULL,
  teacher TEXT NOT NULL,
  control TEXT NOT NULL,
  credits INTEGER NOT NULL,
  hours_week REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS lesson_templates (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  course_id INTEGER NOT NULL REFERENCES courses(id),
  weekday INTEGER NOT NULL,
  pair INTEGER NOT NULL,
  type TEXT NOT NULL,
  room TEXT NOT NULL,
  teacher TEXT NOT NULL,
  parity TEXT NOT NULL DEFAULT 'all'
);
-- изменения задаются относительно «n-го учебного дня от сегодня»,
-- чтобы демо-данные всегда оставались актуальными
CREATE TABLE IF NOT EXISTS lesson_changes (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  study_day INTEGER NOT NULL,
  lesson_index INTEGER,
  kind TEXT NOT NULL CHECK (kind IN ('room','teacher','cancelled','added')),
  pair INTEGER,
  course_id INTEGER,
  type TEXT,
  room TEXT,
  teacher TEXT,
  note TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS assessments (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  course_id INTEGER NOT NULL REFERENCES courses(id),
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  offset_days INTEGER NOT NULL,
  time TEXT,
  room TEXT,
  score REAL,
  max_score REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS session_results (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  semester TEXT NOT NULL,
  sem_order INTEGER NOT NULL,
  course TEXT NOT NULL,
  control TEXT NOT NULL,
  score INTEGER NOT NULL,
  credits INTEGER NOT NULL,
  retake_offset_days INTEGER
);
CREATE TABLE IF NOT EXISTS tasks (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  title TEXT NOT NULL,
  due_date TEXT,
  due_offset_days INTEGER,
  due_time TEXT,
  done INTEGER NOT NULL DEFAULT 0,
  course_id INTEGER,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS request_types (
  code TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  eta_days INTEGER NOT NULL,
  needs_country INTEGER NOT NULL DEFAULT 0,
  default_language TEXT NOT NULL DEFAULT 'ru',
  sort INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS requests (
  id INTEGER PRIMARY KEY,
  number TEXT UNIQUE NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id),
  type_code TEXT NOT NULL REFERENCES request_types(code),
  purpose TEXT NOT NULL,
  copies INTEGER NOT NULL,
  language TEXT NOT NULL,
  delivery TEXT NOT NULL,
  country TEXT,
  comment TEXT,
  status TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'form',
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS request_events (
  id INTEGER PRIMARY KEY,
  request_id INTEGER NOT NULL REFERENCES requests(id),
  at INTEGER NOT NULL,
  status TEXT,
  actor TEXT NOT NULL,
  comment TEXT
);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  at INTEGER NOT NULL,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  href TEXT,
  read INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS drafts (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  payload TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  request_id INTEGER,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS chat_messages (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  meta TEXT,
  at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS campus_events (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  offset_days INTEGER NOT NULL,
  time TEXT NOT NULL,
  place TEXT NOT NULL,
  tag TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_requests_user ON requests(user_id);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_user ON chat_messages(user_id);
`;

type G = typeof globalThis & { __mnDb?: Database.Database };

export function getDb(): Database.Database {
  const g = globalThis as G;
  if (g.__mnDb) return g.__mnDb;
  const file = process.env.DB_PATH ?? path.join(process.cwd(), "data", "mgimo-next.db");
  if (file !== ":memory:") fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new Database(file);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  // LOWER() в SQLite работает только для ASCII — регистронезависимый поиск по кириллице через JS
  db.function("lc", { deterministic: true }, (s: unknown) => (typeof s === "string" ? s.toLowerCase() : s));
  db.exec(SCHEMA);
  const { n } = db.prepare("SELECT COUNT(*) AS n FROM users").get() as { n: number };
  if (n === 0) seed(db);
  g.__mnDb = db;
  return db;
}
