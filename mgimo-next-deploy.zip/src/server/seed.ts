import type Database from "better-sqlite3";
import bcrypt from "bcryptjs";

// Все люди, группы, аудитории и оценки — вымышленные.
// Даты задаются смещениями от «сегодня» и вычисляются при запросе.

type CourseSeed = { key: string; name: string; short: string; teacher: string; control: string; credits: number; hours: number };
type Tpl = [weekday: number, pair: number, course: string, type: string, room: string, parity?: "odd" | "even"];
type Asm = [course: string, kind: string, title: string, offset: number, time: string | null, room: string | null, score: number | null, max: number];
type Sess = [semester: string, order: number, course: string, control: string, score: number, credits: number, retakeOffset?: number];

const DAY = 86400000;

export function seed(db: Database.Database) {
  const hash = bcrypt.hashSync(process.env.DEMO_PASSWORD ?? "demo2026", 10);
  const now = Date.now();

  const insUser = db.prepare(`INSERT INTO users (login,password_hash,role,full_name,short_name,faculty,program,course,group_name,study_year,student_code,position)
    VALUES (@login,@hash,@role,@full,@short,@faculty,@program,@course,@group,@year,@code,@position)`);
  const insCourse = db.prepare(`INSERT INTO courses (user_id,name,short,teacher,control,credits,hours_week) VALUES (?,?,?,?,?,?,?)`);
  const insTpl = db.prepare(`INSERT INTO lesson_templates (user_id,course_id,weekday,pair,type,room,teacher,parity) VALUES (?,?,?,?,?,?,?,?)`);
  const insChange = db.prepare(`INSERT INTO lesson_changes (user_id,study_day,lesson_index,kind,pair,course_id,type,room,teacher,note) VALUES (?,?,?,?,?,?,?,?,?,?)`);
  const insAsm = db.prepare(`INSERT INTO assessments (user_id,course_id,kind,title,offset_days,time,room,score,max_score) VALUES (?,?,?,?,?,?,?,?,?)`);
  const insSess = db.prepare(`INSERT INTO session_results (user_id,semester,sem_order,course,control,score,credits,retake_offset_days) VALUES (?,?,?,?,?,?,?,?)`);
  const insTask = db.prepare(`INSERT INTO tasks (user_id,title,due_offset_days,due_time,done,course_id,created_at) VALUES (?,?,?,?,?,?,?)`);
  const insReq = db.prepare(`INSERT INTO requests (number,user_id,type_code,purpose,copies,language,delivery,country,comment,status,source,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const insEv = db.prepare(`INSERT INTO request_events (request_id,at,status,actor,comment) VALUES (?,?,?,?,?)`);
  const insNotif = db.prepare(`INSERT INTO notifications (user_id,at,kind,title,body,href,read) VALUES (?,?,?,?,?,?,?)`);

  const run = db.transaction(() => {
    // ---------- типы обращений ----------
    const types: [string, string, string, number, number, string][] = [
      ["study_certificate", "Справка об обучении", "Подтверждает статус студента. Подходит для работы, банка, соцзащиты, по месту требования.", 2, 0, "ru"],
      ["visa_certificate", "Справка для визы / посольства", "Справка об обучении с периодом каникул, двуязычная, для консульства или визового центра.", 3, 1, "ru+en"],
      ["transcript", "Выписка оценок (транскрипт)", "Перечень дисциплин с оценками и зачётными единицами. Для стажировок и обмена.", 5, 0, "en"],
      ["military", "Справка для военкомата", "Справка об обучении по установленной форме для отсрочки.", 2, 0, "ru"],
      ["social_fund", "Справка в Социальный фонд", "Для назначения или продления выплат.", 3, 0, "ru"],
      ["curriculum", "Копия учебного плана", "Учебный план направления с часами и формами контроля.", 4, 0, "ru"],
      ["retake", "Заявление на пересдачу", "Согласование даты пересдачи академической задолженности.", 3, 0, "ru"],
      ["individual_plan", "Заявление на индивидуальный график", "Для совмещения учёбы со стажировкой, спортом или по семейным обстоятельствам.", 7, 0, "ru"],
    ];
    const insType = db.prepare(`INSERT INTO request_types (code,title,description,eta_days,needs_country,default_language,sort) VALUES (?,?,?,?,?,?,?)`);
    types.forEach((t, i) => insType.run(t[0], t[1], t[2], t[3], t[4], t[5], i));

    // ---------- пользователи ----------
    const alina = insUser.run({
      login: "alina", hash, role: "student", full: "Воронцова Алина Сергеевна", short: "Алина Воронцова",
      faculty: "Факультет международных отношений", program: "Международные отношения", course: 2, group: "МО-2-03",
      year: "2026/27", code: "DEMO-24-0317", position: null,
    }).lastInsertRowid as number;
    const matvey = insUser.run({
      login: "matvey", hash, role: "student", full: "Лебедев Матвей Андреевич", short: "Матвей Лебедев",
      faculty: "Факультет международной экономики", program: "Экономика", course: 3, group: "МЭ-3-01",
      year: "2026/27", code: "DEMO-23-1142", position: null,
    }).lastInsertRowid as number;
    insUser.run({
      login: "dekanat", hash, role: "staff", full: "Карпова Елена Викторовна", short: "Елена Карпова",
      faculty: "Деканат (демо)", program: "—", course: null, group: null, year: "2026/27", code: null,
      position: "Специалист учебного отдела",
    });

    const addCourses = (uid: number, list: CourseSeed[]) => {
      const map: Record<string, { id: number; teacher: string }> = {};
      for (const c of list) {
        const id = insCourse.run(uid, c.name, c.short, c.teacher, c.control, c.credits, c.hours).lastInsertRowid as number;
        map[c.key] = { id, teacher: c.teacher };
      }
      return map;
    };

    // ---------- Алина ----------
    const A = addCourses(alina, [
      { key: "tmo", name: "Теория международных отношений", short: "ТМО", teacher: "доц. Беляев К. А.", control: "Экзамен", credits: 5, hours: 4 },
      { key: "hist", name: "История внешней политики России", short: "История ВП", teacher: "проф. Гладков С. И.", control: "Экзамен", credits: 4, hours: 2.67 },
      { key: "econ", name: "Мировая экономика", short: "Мир. экономика", teacher: "доц. Ткаченко А. Р.", control: "Экзамен", credits: 4, hours: 2.67 },
      { key: "law", name: "Международное публичное право", short: "Межд. право", teacher: "доц. Захарова Н. Л.", control: "Зачёт", credits: 3, hours: 2.67 },
      { key: "eng", name: "Английский язык", short: "Английский", teacher: "ст. преп. Миронова Е. В.", control: "Диф. зачёт", credits: 4, hours: 5.33 },
      { key: "fr", name: "Французский язык (второй)", short: "Французский", teacher: "ст. преп. Орлова-Дюваль М. П.", control: "Зачёт", credits: 3, hours: 4 },
      { key: "geo", name: "Политическая география", short: "Полит. география", teacher: "Соколов Д. В.", control: "Зачёт", credits: 2, hours: 1.33 },
    ]);
    const tplA: Tpl[] = [
      [1, 1, "tmo", "Лекция", "А-101"], [1, 2, "tmo", "Семинар", "Б-214"], [1, 3, "eng", "Практика", "Л-305"], [1, 4, "fr", "Практика", "Л-118"],
      [2, 2, "hist", "Лекция", "А-204"], [2, 3, "econ", "Лекция", "А-101"], [2, 4, "law", "Семинар", "Б-310"],
      [3, 1, "eng", "Практика", "Л-305"], [3, 2, "fr", "Практика", "Л-118"], [3, 3, "geo", "Лекция", "А-317", "odd"], [3, 3, "hist", "Семинар", "Б-122", "even"],
      [4, 1, "econ", "Семинар", "Б-208"], [4, 2, "law", "Лекция", "А-204"], [4, 3, "tmo", "Семинар", "Б-214"],
      [5, 2, "eng", "Практика", "Л-305"], [5, 3, "hist", "Семинар", "Б-122"], [5, 4, "econ", "Семинар", "Б-208"], [5, 5, "fr", "Практика", "Л-118"],
      [6, 2, "eng", "Практика", "Л-305"], [6, 3, "geo", "Семинар", "Б-019"],
    ];
    for (const [wd, pair, key, type, room, parity] of tplA) insTpl.run(alina, A[key].id, wd, pair, type, room, A[key].teacher, parity ?? "all");
    insChange.run(alina, 0, 99, "teacher", null, null, null, null, "Новикова И. А.", "Замена преподавателя");
    insChange.run(alina, 1, 0, "room", null, null, null, "Б-405", null, "Аудитория изменена");
    insChange.run(alina, 2, 1, "cancelled", null, null, null, null, null, "Отменено: преподаватель в командировке");
    insChange.run(alina, 4, null, "added", 5, A.law.id, "Консультация", "Б-310", null, "Дополнительная консультация к зачёту");

    const asmA: Asm[] = [
      ["tmo", "Тест", "Тест: школы реализма и либерализма", -45, "09:00", "Б-214", 18, 20],
      ["tmo", "Эссе", "Эссе: баланс сил в XXI веке", -24, null, null, 26, 30],
      ["tmo", "Контрольная", "Контрольная: теории интеграции", 3, "10:30", "Б-214", null, 20],
      ["tmo", "Экзамен", "Экзамен", 37, "10:00", "А-101", null, 30],
      ["hist", "Коллоквиум", "Коллоквиум: внешняя политика XVIII века", -33, "12:40", "Б-122", 17, 20],
      ["hist", "Эссе", "Эссе: Венский конгресс", 6, "23:59", null, null, 20],
      ["hist", "Экзамен", "Экзамен", 41, "10:00", "А-204", null, 40],
      ["econ", "Контрольная", "Контрольная: платёжный баланс", -12, "09:00", "Б-208", 14, 20],
      ["econ", "Презентация", "Презентация: экономика АСЕАН", -1, "12:40", "Б-208", null, 10],
      ["econ", "Экзамен", "Экзамен", 45, "10:00", "А-101", null, 30],
      ["law", "Коллоквиум", "Коллоквиум: источники международного права", -6, "12:40", "Б-310", 16, 20],
      ["law", "Зачёт", "Зачёт", 29, "14:10", "Б-310", null, 40],
      ["eng", "Презентация", "Presentation: Global Governance", -9, "10:30", "Л-305", 9, 10],
      ["eng", "Тест", "Midterm Test", 8, "09:00", "Л-305", null, 25],
      ["eng", "Зачёт", "Дифференцированный зачёт", 31, "09:00", "Л-305", null, 40],
      ["fr", "Тест", "Dictée", -3, "10:30", "Л-118", 8, 10],
      ["fr", "Зачёт", "Зачёт", 30, "10:30", "Л-118", null, 30],
      ["geo", "Эссе", "Эссе: геополитика Арктики", -2, null, null, null, 20],
      ["geo", "Зачёт", "Зачёт", 28, "12:40", "А-317", null, 40],
    ];
    for (const a of asmA) insAsm.run(alina, A[a[0]].id, a[1], a[2], a[3], a[4], a[5], a[6], a[7]);

    const sessA: Sess[] = [
      ["Осень 2025/26", 1, "Введение в теорию международных отношений", "Экзамен", 92, 4],
      ["Осень 2025/26", 1, "История России", "Экзамен", 85, 4],
      ["Осень 2025/26", 1, "Английский язык", "Диф. зачёт", 94, 4],
      ["Осень 2025/26", 1, "Французский язык", "Зачёт", 81, 3],
      ["Осень 2025/26", 1, "Основы экономики", "Экзамен", 78, 3],
      ["Осень 2025/26", 1, "Философия", "Зачёт", 88, 2],
      ["Осень 2025/26", 1, "Физическая культура", "Зачёт", 100, 1],
      ["Весна 2025/26", 2, "История международных отношений", "Экзамен", 90, 4],
      ["Весна 2025/26", 2, "Английский язык", "Экзамен", 96, 4],
      ["Весна 2025/26", 2, "Французский язык", "Зачёт", 86, 3],
      ["Весна 2025/26", 2, "Теория права", "Экзамен", 83, 3],
      ["Весна 2025/26", 2, "Социология", "Зачёт", 91, 2],
      ["Весна 2025/26", 2, "Информационные технологии", "Зачёт", 95, 2],
      ["Весна 2025/26", 2, "Физическая культура", "Зачёт", 100, 1],
    ];
    for (const s of sessA) insSess.run(alina, s[0], s[1], s[2], s[3], s[4], s[5], s[6] ?? null);

    insTask.run(alina, "Прочитать главы 4–5 Уолтца к семинару", 0, "21:00", 0, A.tmo.id, now);
    insTask.run(alina, "Собрать источники для эссе про Венский конгресс", 2, null, 0, A.hist.id, now);
    insTask.run(alina, "Записаться в клуб дебатов", -1, null, 1, null, now);

    // обращения Алины
    const r1 = insReq.run("MN-26-01184", alina, "study_certificate", "По месту требования (банк)", 1, "ru", "electronic", null, null, "ready", "form", now - 4 * DAY, now - 0.4 * DAY).lastInsertRowid as number;
    insEv.run(r1, now - 4 * DAY, "submitted", "Студент", null);
    insEv.run(r1, now - 3 * DAY, "in_progress", "Карпова Е. В.", null);
    insEv.run(r1, now - 0.4 * DAY, "ready", "Карпова Е. В.", "Справка подписана электронной подписью, PDF доступен в карточке заявки.");
    const r2 = insReq.run("MN-26-01236", alina, "curriculum", "Для подачи на летнюю школу", 1, "ru", "electronic", null, null, "in_progress", "form", now - 1.5 * DAY, now - 1 * DAY).lastInsertRowid as number;
    insEv.run(r2, now - 1.5 * DAY, "submitted", "Студент", null);
    insEv.run(r2, now - 1 * DAY, "in_progress", "Карпова Е. В.", "Запросили актуальную версию плана у учебного отдела.");
    insNotif.run(alina, now - 0.4 * DAY, "request", "Справка об обучении готова", "Заявка MN-26-01184 — можно скачать PDF.", `/dean/${r1}`, 0);
    insNotif.run(alina, now - 0.2 * DAY, "schedule", "Изменение в расписании", "Занятие через два учебных дня перенесено. Подробности в расписании.", "/schedule", 0);
    insNotif.run(alina, now - 3 * DAY, "grade", "Новая оценка", "Французский язык — Dictée: 8 из 10.", "/study", 1);

    // ---------- Матвей ----------
    const M = addCourses(matvey, [
      { key: "ectr", name: "Эконометрика", short: "Эконометрика", teacher: "доц. Рябинин П. С.", control: "Экзамен", credits: 5, hours: 4 },
      { key: "fin", name: "Корпоративные финансы", short: "Корп. финансы", teacher: "проф. Ушакова Л. М.", control: "Экзамен", credits: 5, hours: 4 },
      { key: "mkt", name: "Маркетинг на международных рынках", short: "Маркетинг", teacher: "доц. Фролов Г. Е.", control: "Зачёт", credits: 3, hours: 2.67 },
      { key: "beng", name: "Деловой английский", short: "Деловой англ.", teacher: "ст. преп. Харитонова А. Ю.", control: "Диф. зачёт", credits: 4, hours: 4 },
      { key: "de", name: "Немецкий язык", short: "Немецкий", teacher: "ст. преп. Вебер-Кузнецова О. Р.", control: "Зачёт", credits: 3, hours: 4 },
      { key: "mvko", name: "Международные валютно-кредитные отношения", short: "МВКО", teacher: "доц. Демидов В. А.", control: "Экзамен", credits: 4, hours: 2.67 },
      { key: "py", name: "Анализ данных в Python", short: "Python", teacher: "Ким С. Д.", control: "Зачёт", credits: 3, hours: 2.67 },
    ]);
    const tplM: Tpl[] = [
      [1, 3, "ectr", "Лекция", "А-310"], [1, 4, "ectr", "Семинар", "К-12"], [1, 5, "de", "Практика", "Л-221"],
      [2, 1, "fin", "Лекция", "А-112"], [2, 2, "fin", "Семинар", "Б-415"], [2, 3, "beng", "Практика", "Л-402"],
      [3, 2, "mvko", "Лекция", "А-112"], [3, 3, "py", "Практика", "К-07"], [3, 4, "de", "Практика", "Л-221"],
      [4, 3, "mkt", "Лекция", "А-310"], [4, 4, "mkt", "Семинар", "Б-111"], [4, 5, "beng", "Практика", "Л-402"],
      [5, 1, "ectr", "Семинар", "К-12"], [5, 2, "mvko", "Семинар", "Б-415"], [5, 3, "py", "Практика", "К-07", "even"], [5, 3, "fin", "Семинар", "Б-415", "odd"],
      [6, 1, "beng", "Практика", "Л-402"],
    ];
    for (const [wd, pair, key, type, room, parity] of tplM) insTpl.run(matvey, M[key].id, wd, pair, type, room, M[key].teacher, parity ?? "all");
    insChange.run(matvey, 1, 0, "room", null, null, null, "К-21", null, "Аудитория изменена");
    insChange.run(matvey, 3, null, "added", 6, M.ectr.id, "Консультация", "К-12", null, "Консультация перед контрольной");

    const asmM: Asm[] = [
      ["ectr", "Контрольная", "Контрольная: МНК и диагностика", -20, "14:10", "К-12", 15, 25],
      ["ectr", "Дедлайн", "Проект: модель спроса на рынке аренды", 5, "23:59", null, null, 25],
      ["ectr", "Экзамен", "Экзамен", 36, "10:00", "А-310", null, 50],
      ["fin", "Тест", "Тест: стоимость капитала", -14, "09:00", "Б-415", 17, 20],
      ["fin", "Контрольная", "Контрольная: оценка проектов (NPV/IRR)", 2, "10:30", "Б-415", null, 30],
      ["fin", "Экзамен", "Экзамен", 40, "10:00", "А-112", null, 50],
      ["mkt", "Контрольная", "Кейс-стади: выход бренда на рынок ОАЭ", -8, "12:40", "Б-111", 18, 20],
      ["mkt", "Зачёт", "Зачёт", 27, "12:40", "Б-111", null, 40],
      ["beng", "Презентация", "Pitch: startup in emerging markets", -4, "12:40", "Л-402", 22, 25],
      ["beng", "Зачёт", "Дифференцированный зачёт", 32, "12:40", "Л-402", null, 40],
      ["de", "Тест", "Wortschatztest", -11, "15:40", "Л-221", 12, 20],
      ["de", "Зачёт", "Зачёт", 30, "15:40", "Л-221", null, 40],
      ["mvko", "Коллоквиум", "Коллоквиум: Бреттон-Вудс и Ямайская система", -2, "10:30", "Б-415", 19, 20],
      ["mvko", "Экзамен", "Экзамен", 43, "10:00", "А-112", null, 40],
      ["py", "Дедлайн", "Домашнее задание 3: pandas", -5, "23:59", null, 9, 10],
      ["py", "Дедлайн", "Домашнее задание 4: визуализация", 4, "23:59", null, null, 10],
      ["py", "Зачёт", "Зачёт: защита проекта", 26, "12:40", "К-07", null, 40],
    ];
    for (const a of asmM) insAsm.run(matvey, M[a[0]].id, a[1], a[2], a[3], a[4], a[5], a[6], a[7]);

    const sessM: Sess[] = [
      ["Осень 2024/25", 1, "Микроэкономика", "Экзамен", 74, 5],
      ["Осень 2024/25", 1, "Математический анализ", "Экзамен", 68, 5],
      ["Осень 2024/25", 1, "Английский язык", "Диф. зачёт", 88, 4],
      ["Осень 2024/25", 1, "История экономических учений", "Зачёт", 82, 3],
      ["Весна 2024/25", 2, "Макроэкономика", "Экзамен", 79, 5],
      ["Весна 2024/25", 2, "Линейная алгебра", "Экзамен", 71, 4],
      ["Весна 2024/25", 2, "Английский язык", "Экзамен", 90, 4],
      ["Весна 2024/25", 2, "Немецкий язык", "Зачёт", 76, 3],
      ["Осень 2025/26", 3, "Теория вероятностей", "Экзамен", 81, 5],
      ["Осень 2025/26", 3, "Финансовый учёт", "Экзамен", 84, 4],
      ["Осень 2025/26", 3, "Немецкий язык", "Зачёт", 80, 3],
      ["Осень 2025/26", 3, "Деловой английский", "Диф. зачёт", 91, 4],
      ["Весна 2025/26", 4, "Статистика", "Экзамен", 52, 4, 9],
      ["Весна 2025/26", 4, "Финансовые рынки", "Экзамен", 86, 4],
      ["Весна 2025/26", 4, "Немецкий язык", "Зачёт", 83, 3],
      ["Весна 2025/26", 4, "Международная экономика", "Экзамен", 88, 4],
    ];
    for (const s of sessM) insSess.run(matvey, s[0], s[1], s[2], s[3], s[4], s[5], s[6] ?? null);

    insTask.run(matvey, "Собрать данные для проекта по эконометрике", 1, null, 0, M.ectr.id, now);
    insTask.run(matvey, "Повторить формулы WACC и NPV", 1, "20:00", 0, M.fin.id, now);
    insTask.run(matvey, "Найти научного руководителя для курсовой", 6, null, 0, null, now);

    const r3 = insReq.run("MN-26-01241", matvey, "military", "Для предоставления в военкомат", 1, "ru", "paper", null, null, "submitted", "form", now - 0.7 * DAY, now - 0.7 * DAY).lastInsertRowid as number;
    insEv.run(r3, now - 0.7 * DAY, "submitted", "Студент", null);
    const r4 = insReq.run("MN-26-01102", matvey, "study_certificate", "По месту работы родителей", 2, "ru", "paper", null, null, "issued", "form", now - 21 * DAY, now - 17 * DAY).lastInsertRowid as number;
    insEv.run(r4, now - 21 * DAY, "submitted", "Студент", null);
    insEv.run(r4, now - 20 * DAY, "in_progress", "Карпова Е. В.", null);
    insEv.run(r4, now - 19 * DAY, "ready", "Карпова Е. В.", "Оригиналы можно забрать в окне № 3.");
    insEv.run(r4, now - 17 * DAY, "issued", "Карпова Е. В.", "Выдано лично.");
    insNotif.run(matvey, now - 2 * DAY, "grade", "Новая оценка", "МВКО — коллоквиум: 19 из 20.", "/study", 0);
    insNotif.run(matvey, now - 5 * DAY, "system", "Академическая задолженность", "Статистика: назначена пересдача. Подайте заявление в разделе «Деканат».", "/dean/new?type=retake", 1);

    // ---------- кампус ----------
    const insEvent = db.prepare(`INSERT INTO campus_events (title,offset_days,time,place,tag) VALUES (?,?,?,?,?)`);
    insEvent.run("Модель ООН: регистрация делегаций", 2, "18:40", "Конференц-зал, корп. А", "Клубы");
    insEvent.run("Карьерный день: консалтинг и финансы", 5, "15:00", "Атриум", "Карьера");
    insEvent.run("Лекция приглашённого дипломата (демо)", 8, "17:10", "А-101", "Лекции");
    insEvent.run("Турнир по дебатам, отборочный этап", 12, "16:00", "Б-214", "Клубы");
  });
  run();
}
