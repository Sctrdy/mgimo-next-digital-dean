import "server-only";
import { getDb } from "./db";
import { addDays, diffDays, isoWeek, moscowNow, pairTime, studyDay, toMinutes, weekday, type Now } from "@/lib/time";
import type { Assessment, Lesson, Task } from "@/lib/types";
import { dayStatusFrom, type DayStatus } from "@/lib/status";
export type { DayStatus };

type TplRow = { id: number; course_id: number; weekday: number; pair: number; type: string; room: string; teacher: string; parity: string; course: string };
type ChangeRow = { id: number; study_day: number; lesson_index: number | null; kind: string; pair: number | null; course_id: number | null; type: string | null; room: string | null; teacher: string | null; note: string; course: string | null; c_teacher: string | null };

function templates(userId: number) {
  return getDb()
    .prepare("SELECT t.*, c.name AS course FROM lesson_templates t JOIN courses c ON c.id = t.course_id WHERE t.user_id = ?")
    .all(userId) as TplRow[];
}

function changes(userId: number) {
  return getDb()
    .prepare("SELECT ch.*, c.name AS course, c.teacher AS c_teacher FROM lesson_changes ch LEFT JOIN courses c ON c.id = ch.course_id WHERE ch.user_id = ?")
    .all(userId) as ChangeRow[];
}

function baseDay(tpls: TplRow[], date: string): Lesson[] {
  const wd = weekday(date);
  const parity = isoWeek(date) % 2 === 1 ? "odd" : "even";
  return tpls
    .filter((t) => t.weekday === wd && (t.parity === "all" || t.parity === parity))
    .sort((a, b) => a.pair - b.pair)
    .map((t) => {
      const p = pairTime(t.pair);
      return {
        id: `${date}-${t.pair}-${t.id}`, date, pair: t.pair, start: p.start, end: p.end, courseId: t.course_id, course: t.course,
        type: t.type, room: t.room, teacher: t.teacher, status: "normal" as const,
      };
    });
}

/** Расписание пользователя за период (включительно), с учётом переносов и замен. */
export function getLessons(userId: number, from: string, to: string, now: Now = moscowNow()): Lesson[] {
  const tpls = templates(userId);
  const chs = changes(userId);
  const byDate = new Map<string, ChangeRow[]>();
  for (const c of chs) {
    const d = studyDay(now.date, c.study_day);
    byDate.set(d, [...(byDate.get(d) ?? []), c]);
  }
  const out: Lesson[] = [];
  for (let d = from; diffDays(d, to) >= 0; d = addDays(d, 1)) {
    const day = baseDay(tpls, d);
    for (const c of byDate.get(d) ?? []) {
      if (c.kind === "added" && c.pair && c.course_id) {
        const p = pairTime(c.pair);
        day.push({
          id: `${d}-${c.pair}-add${c.id}`, date: d, pair: c.pair, start: p.start, end: p.end, courseId: c.course_id, course: c.course ?? "",
          type: c.type ?? "Занятие", room: c.room ?? "", teacher: c.teacher ?? c.c_teacher ?? "", status: "added", note: c.note,
        });
        continue;
      }
      if (!day.length || c.lesson_index === null) continue;
      const l = day[Math.min(c.lesson_index, day.length - 1)];
      if (c.kind === "cancelled") Object.assign(l, { status: "cancelled", note: c.note });
      if (c.kind === "room" && c.room) Object.assign(l, { status: "changed", note: c.note, was: { room: l.room }, room: c.room });
      if (c.kind === "teacher" && c.teacher) Object.assign(l, { status: "changed", note: c.note, was: { teacher: l.teacher }, teacher: c.teacher });
    }
    day.sort((a, b) => a.pair - b.pair);
    out.push(...day);
  }
  return out;
}

/** Состояние учебного дня: идёт пара / до пары / ближайшая пара следующего учебного дня. */
export function getDayStatus(userId: number, now: Now = moscowNow()): DayStatus {
  return dayStatusFrom(getLessons(userId, now.date, addDays(now.date, 14), now), now);
}

type AsmRow = { id: number; course_id: number; course: string; kind: string; title: string; offset_days: number; time: string | null; room: string | null; score: number | null; max_score: number };

export function isPast(date: string, time: string | null, now: Now) {
  if (date < now.date) return true;
  if (date > now.date) return false;
  return time ? toMinutes(time) <= now.minutes : false;
}

export function getAssessments(userId: number, now: Now = moscowNow()): Assessment[] {
  const rows = getDb()
    .prepare("SELECT a.*, c.name AS course FROM assessments a JOIN courses c ON c.id = a.course_id WHERE a.user_id = ? ORDER BY a.offset_days, a.time")
    .all(userId) as AsmRow[];
  return rows.map((r) => {
    // учебные события не ставим на воскресенье — переносим на понедельник
    let date = addDays(now.date, r.offset_days);
    if (weekday(date) === 7) date = addDays(date, 1);
    return {
      id: r.id, courseId: r.course_id, course: r.course, kind: r.kind as Assessment["kind"], title: r.title, date, time: r.time,
      room: r.room, score: r.score, maxScore: r.max_score, past: isPast(date, r.time, now),
    };
  });
}

export function getUpcomingAssessments(userId: number, now: Now = moscowNow()) {
  return getAssessments(userId, now).filter((a) => !a.past);
}

type TaskRow = { id: number; title: string; due_date: string | null; due_offset_days: number | null; due_time: string | null; done: number; course_id: number | null; course: string | null };

export function getTasks(userId: number, now: Now = moscowNow()): Task[] {
  const rows = getDb()
    .prepare("SELECT t.*, c.name AS course FROM tasks t LEFT JOIN courses c ON c.id = t.course_id WHERE t.user_id = ? ORDER BY t.done, t.id")
    .all(userId) as TaskRow[];
  return rows
    .map((r) => ({
      id: r.id, title: r.title, dueDate: r.due_date ?? (r.due_offset_days !== null ? addDays(now.date, r.due_offset_days) : null),
      dueTime: r.due_time, done: !!r.done, courseId: r.course_id, course: r.course,
    }))
    .sort((a, b) => Number(a.done) - Number(b.done) || (a.dueDate ?? "9999").localeCompare(b.dueDate ?? "9999"));
}
