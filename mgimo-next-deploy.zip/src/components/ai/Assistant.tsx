"use client";
import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowUp, Check, ExternalLink, Loader2, PencilLine, RotateCcw, ShieldCheck, Sparkles, X } from "lucide-react";
import type { ChatMessage, DraftPreview } from "@/lib/types";
import { Markdown } from "./Markdown";
import { RequestPreview } from "@/components/dean/RequestPreview";

const SUGGESTIONS = [
  "Какие у меня пары завтра?",
  "Когда следующая контрольная?",
  "Покажи мои оценки",
  "Помоги подготовиться к экзамену",
  "Мне нужна справка об обучении для визы в Италию",
  "Какой статус моего обращения?",
];

export function Assistant({ initial, firstName, mode, prefill }: { initial: ChatMessage[]; firstName: string; mode: "llm" | "fallback"; prefill: string | null }) {
  const router = useRouter();
  const [messages, setMessages] = useState(initial);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const bottom = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLTextAreaElement>(null);
  const sentPrefill = useRef(false);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: messages.length > initial.length ? "smooth" : "auto", block: "end" });
  }, [messages, busy, initial.length]);

  const send = async (msg: string) => {
    const body = msg.trim();
    if (!body || busy) return;
    setBusy(true);
    setError(null);
    setText("");
    const temp: ChatMessage = { id: -Date.now(), role: "user", content: body, at: Date.now(), meta: null };
    setMessages((m) => [...m, temp]);
    try {
      const r = await fetch("/api/ai/chat", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ message: body }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "NEXT AI сейчас недоступен");
      setMessages((m) => [...m.filter((x) => x.id !== temp.id), d.userMessage, d.message]);
    } catch (e) {
      setMessages((m) => m.filter((x) => x.id !== temp.id));
      setText(body);
      setError(e instanceof Error ? e.message : "Нет соединения. Проверь интернет и отправь ещё раз.");
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
    if (prefill && !sentPrefill.current) {
      sentPrefill.current = true;
      window.history.replaceState(null, "", "/assistant");
      send(prefill);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefill]);

  const onDraft = async (draftId: number, cancel: boolean) => {
    const r = await fetch("/api/ai/confirm", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ draftId, cancel }) });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error ?? "Не удалось выполнить действие");
    setMessages((m) => [
      ...m.map((x) =>
        x.meta?.draft?.draftId === draftId
          ? { ...x, meta: { ...x.meta, draft: { ...x.meta.draft, status: cancel ? ("cancelled" as const) : ("confirmed" as const) }, createdRequest: d.request ? { id: d.request.id, number: d.request.number } : undefined } }
          : x,
      ),
      d.message,
    ]);
    if (!cancel) router.refresh();
  };

  const clear = async () => {
    await fetch("/api/ai/chat", { method: "DELETE" });
    setMessages([]);
  };

  const empty = messages.length === 0;

  return (
    <div className="mx-auto flex min-h-[calc(100dvh-180px)] max-w-3xl flex-col lg:min-h-[calc(100dvh-120px)]">
      <header className="flex items-center gap-3">
        <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-violet text-white">
          <Sparkles size={20} />
        </span>
        <div className="min-w-0 flex-1">
          <h1 className="text-[20px] font-semibold leading-tight tracking-[-0.02em]">NEXT AI</h1>
          <p className="flex items-center gap-1 text-[12.5px] text-ink-3">
            <ShieldCheck size={13} className="text-green" /> Видит только твои данные
            {mode === "fallback" && <span className="ml-1 rounded bg-surface-2 px-1.5 text-[11px]">упрощённый режим</span>}
          </p>
        </div>
        {!empty && (
          <button onClick={clear} className="press flex h-9 items-center gap-1.5 rounded-xl px-2.5 text-[13px] font-medium text-ink-3 hover:bg-surface-2" aria-label="Новый диалог">
            <RotateCcw size={15} /> <span className="hidden sm:inline">Новый диалог</span>
          </button>
        )}
      </header>

      <div className="flex-1 py-5">
        {empty ? (
          <div className="pt-4 sm:pt-10">
            <h2 className="text-[26px] font-semibold leading-[1.15] tracking-[-0.03em] sm:text-[32px]">
              {firstName}, чем помочь?
            </h2>
            <p className="mt-2 max-w-md text-[14.5px] text-ink-2">
              Спроси о расписании, оценках или сроках. Могу подготовить справку — отправлю её в деканат только после твоего подтверждения.
            </p>
            <div className="mt-6 grid gap-2 sm:grid-cols-2">
              {SUGGESTIONS.map((s) => (
                <button key={s} onClick={() => send(s)} className="press rounded-2xl border border-line bg-surface px-4 py-3 text-left text-[14px] font-medium leading-snug hover:border-violet/40 hover:bg-violet-soft/40">
                  {s}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <ol className="space-y-5" aria-live="polite">
            {messages.map((m) => (
              <li key={m.id}>
                {m.role === "user" ? (
                  <div className="flex justify-end">
                    <p className="max-w-[85%] whitespace-pre-wrap rounded-[20px] rounded-br-md bg-navy px-4 py-2.5 text-[15px] leading-snug text-white dark:bg-primary">{m.content}</p>
                  </div>
                ) : (
                  <div className="flex gap-3">
                    <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-xl bg-violet-soft text-violet-ink">
                      <Sparkles size={15} />
                    </span>
                    <div className="min-w-0 flex-1 text-[15px] leading-relaxed text-ink-2">
                      <Markdown text={m.content} />
                      {m.meta?.draft && <DraftCard draft={m.meta.draft} created={m.meta.createdRequest} onAction={onDraft} />}
                      {m.meta?.createdRequest && !m.meta.draft && (
                        <Link href={`/dean/${m.meta.createdRequest.id}`} className="press mt-2 inline-flex items-center gap-1.5 rounded-lg bg-primary-soft px-2.5 py-1.5 text-[13px] font-semibold text-primary-soft-ink">
                          Открыть заявку {m.meta.createdRequest.number} <ExternalLink size={13} />
                        </Link>
                      )}
                      {!!m.meta?.tools?.length && <p className="mt-2 text-[12px] text-ink-3">Источник: {m.meta.tools.join(", ")}</p>}
                    </div>
                  </div>
                )}
              </li>
            ))}
            {busy && (
              <li className="flex gap-3" aria-label="NEXT AI печатает">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-xl bg-violet-soft text-violet-ink">
                  <Sparkles size={15} />
                </span>
                <span className="flex items-center gap-1 pt-2">
                  {[0, 1, 2].map((i) => (
                    <span key={i} className="h-1.5 w-1.5 rounded-full bg-violet" style={{ animation: `typing 1s ${i * 0.15}s infinite` }} />
                  ))}
                </span>
              </li>
            )}
          </ol>
        )}
        <div ref={bottom} />
      </div>

      <div className="sticky bottom-[calc(72px+env(safe-area-inset-bottom))] z-20 -mx-4 border-t border-line/60 bg-bg/95 px-4 pb-2 pt-2.5 backdrop-blur-xl lg:bottom-0 lg:mx-0 lg:border-none lg:px-0 lg:pb-4">
        {!empty && !busy && (
          <div className="no-scrollbar -mx-4 mb-2 flex gap-1.5 overflow-x-auto px-4 lg:mx-0 lg:px-0">
            {SUGGESTIONS.slice(0, 4).map((s) => (
              <button key={s} onClick={() => send(s)} className="press h-8 shrink-0 rounded-full border border-line bg-surface px-3 text-[12.5px] text-ink-2">
                {s}
              </button>
            ))}
          </div>
        )}
        {error && (
          <p role="alert" className="mb-2 rounded-xl bg-red-soft px-3 py-2 text-[13px] text-red">
            {error}
          </p>
        )}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(text);
          }}
          className="flex items-end gap-2 rounded-[22px] border border-line-strong bg-surface p-1.5 pl-4 shadow-soft focus-within:border-violet/60"
        >
          <textarea
            ref={input}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send(text);
              }
            }}
            rows={1}
            maxLength={1500}
            placeholder="Спроси NEXT AI"
            aria-label="Сообщение для NEXT AI"
            className="max-h-32 min-h-[40px] flex-1 resize-none bg-transparent py-2 text-[16px] leading-snug outline-none placeholder:text-ink-3"
            style={{ fieldSizing: "content" } as React.CSSProperties}
          />
          <button type="submit" disabled={!text.trim() || busy} className="press flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-violet text-white disabled:opacity-40" aria-label="Отправить">
            {busy ? <Loader2 size={18} className="animate-spin" /> : <ArrowUp size={19} />}
          </button>
        </form>
      </div>
    </div>
  );
}

function DraftCard({ draft, created, onAction }: { draft: DraftPreview; created?: { id: number; number: string }; onAction: (id: number, cancel: boolean) => Promise<void> }) {
  const [busy, setBusy] = useState<"ok" | "cancel" | null>(null);
  const [error, setError] = useState<string | null>(null);
  const act = async (cancel: boolean) => {
    setBusy(cancel ? "cancel" : "ok");
    setError(null);
    try {
      await onAction(draft.draftId, cancel);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Ошибка");
    }
    setBusy(null);
  };
  const qs = new URLSearchParams({ type: draft.type.code, purpose: draft.input.purpose, language: draft.input.language, delivery: draft.input.delivery });
  if (draft.input.country) qs.set("country", draft.input.country);
  if (draft.input.comment) qs.set("comment", draft.input.comment);
  return (
    <div className="mt-3 overflow-hidden rounded-[20px] border border-violet/30 bg-violet-soft/40 p-2">
      <div className="flex items-center gap-2 px-2 pb-2 pt-1">
        <span className="text-[12.5px] font-semibold text-violet-ink">NEXT AI Action · черновик заявки</span>
        <span className={`ml-auto rounded-full px-2 py-0.5 text-[11.5px] font-semibold ${draft.status === "confirmed" ? "bg-green-soft text-green" : draft.status === "cancelled" ? "bg-surface-2 text-ink-3" : "bg-surface text-ink-2"}`}>
          {draft.status === "confirmed" ? "Отправлено" : draft.status === "cancelled" ? "Отменено" : "Ждёт подтверждения"}
        </span>
      </div>
      <RequestPreview d={draft} />
      {draft.status === "pending" && (
        <div className="mt-2 grid gap-2 sm:grid-cols-[1fr_auto_auto]">
          <button onClick={() => act(false)} disabled={!!busy} className="press flex h-11 items-center justify-center gap-2 rounded-xl bg-violet text-[14px] font-semibold text-white disabled:opacity-60">
            {busy === "ok" ? <Loader2 size={17} className="animate-spin" /> : <Check size={17} />} Подтвердить и отправить
          </button>
          <Link href={`/dean/new?${qs}`} className="press flex h-11 items-center justify-center gap-1.5 rounded-xl border border-line-strong bg-surface px-3 text-[13.5px] font-semibold text-ink">
            <PencilLine size={15} /> Изменить
          </Link>
          <button onClick={() => act(true)} disabled={!!busy} className="press flex h-11 items-center justify-center gap-1.5 rounded-xl px-3 text-[13.5px] font-semibold text-ink-3 hover:bg-surface">
            <X size={15} /> Отменить
          </button>
        </div>
      )}
      {draft.status === "confirmed" && created && (
        <Link href={`/dean/${created.id}`} className="press mt-2 flex h-11 items-center justify-center gap-1.5 rounded-xl bg-surface text-[13.5px] font-semibold text-primary-soft-ink">
          Открыть заявку {created.number} <ExternalLink size={14} />
        </Link>
      )}
      {error && <p className="mt-2 rounded-xl bg-red-soft px-3 py-2 text-[13px] text-red">{error}</p>}
    </div>
  );
}
