"use client";
import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Bell, Search, FileText, CalendarDays, GraduationCap, CheckCircle2, Info, X, Loader2 } from "lucide-react";
import { Wordmark } from "./Logo";
import { Sheet } from "@/components/ui/Sheet";
import type { Notification } from "@/lib/types";
import { formatTimestamp } from "@/lib/time";

const KIND_ICON = { request: FileText, schedule: CalendarDays, grade: GraduationCap, system: Info } as const;

export function TopBar({ unread: initialUnread, home }: { unread: number; home: string }) {
  const [unread, setUnread] = useState(initialUnread);
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [items, setItems] = useState<Notification[] | null>(null);
  const [error, setError] = useState(false);
  const router = useRouter();

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/notifications", { cache: "no-store" });
      if (!r.ok) throw new Error();
      const d = (await r.json()) as { items: Notification[]; unread: number };
      setItems(d.items);
      setUnread(d.unread);
      setError(false);
    } catch {
      setError(true);
    }
  }, []);

  // живые уведомления: опрос раз в 20 секунд
  useEffect(() => {
    const t = setInterval(async () => {
      try {
        const r = await fetch("/api/notifications?count=1", { cache: "no-store" });
        if (r.ok) {
          const d = (await r.json()) as { unread: number };
          setUnread((prev) => {
            if (d.unread > prev) router.refresh();
            return d.unread;
          });
        }
      } catch {}
    }, 20000);
    return () => clearInterval(t);
  }, [router]);

  const [prevInitial, setPrevInitial] = useState(initialUnread);
  if (prevInitial !== initialUnread) {
    setPrevInitial(initialUnread);
    setUnread(initialUnread);
  }

  const openPanel = () => {
    setOpen(true);
    load();
  };

  const markAll = async () => {
    await fetch("/api/notifications", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({}) });
    setItems((x) => x?.map((n) => ({ ...n, read: true })) ?? null);
    setUnread(0);
  };

  const openItem = async (n: Notification) => {
    if (!n.read) {
      fetch("/api/notifications", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ id: n.id }) });
      setUnread((u) => Math.max(0, u - 1));
    }
    setOpen(false);
    if (n.href) router.push(n.href);
  };

  return (
    <>
      <header className="sticky top-0 z-30 border-b border-line/70 bg-bg/85 pt-safe backdrop-blur-xl lg:border-none lg:bg-transparent lg:backdrop-blur-none">
        <div className="mx-auto flex h-14 max-w-6xl items-center gap-2 px-4 lg:h-16 lg:px-8">
          <Link href={home} className="lg:hidden" aria-label="MGIMO NEXT — на главную">
            <Wordmark compact />
          </Link>
          <button
            onClick={() => setSearchOpen(true)}
            className="press ml-auto flex h-10 w-10 items-center justify-center rounded-full text-ink-2 hover:bg-surface-2 lg:ml-0 lg:w-[360px] lg:justify-start lg:gap-2.5 lg:rounded-xl lg:border lg:border-line lg:bg-surface lg:px-3.5 lg:text-[14px] lg:text-ink-3"
            aria-label="Поиск"
          >
            <Search size={19} />
            <span className="hidden lg:inline">{home === "/staff" ? "Поиск по номеру, ФИО или группе" : "Поиск по дисциплинам, заявкам, задачам"}</span>
          </button>
          <button
            onClick={openPanel}
            className="press relative flex h-10 w-10 items-center justify-center rounded-full text-ink-2 hover:bg-surface-2 lg:ml-auto lg:border lg:border-line lg:bg-surface"
            aria-label={unread ? `Уведомления: ${unread} новых` : "Уведомления"}
          >
            <Bell size={19} />
            {unread > 0 && (
              <span className="tnum absolute -right-0.5 -top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-primary px-1 text-[10.5px] font-bold text-white ring-2 ring-bg">
                {unread > 9 ? "9+" : unread}
              </span>
            )}
          </button>
        </div>
      </header>

      <Sheet open={open} onClose={() => setOpen(false)} title="Уведомления">
        {unread > 0 && (
          <button onClick={markAll} className="press mb-2 flex items-center gap-1.5 text-[13px] font-semibold text-primary-soft-ink">
            <CheckCircle2 size={15} /> Прочитать все
          </button>
        )}
        {error && <p className="py-6 text-center text-[14px] text-red">Не удалось загрузить уведомления. Проверьте соединение и откройте снова.</p>}
        {!items && !error && (
          <div className="flex justify-center py-10 text-ink-3">
            <Loader2 className="animate-spin" />
          </div>
        )}
        {items && items.length === 0 && <p className="py-10 text-center text-[14px] text-ink-3">Новых уведомлений нет</p>}
        <ul className="-mx-2">
          {items?.map((n) => {
            const Icon = KIND_ICON[n.kind] ?? Info;
            return (
              <li key={n.id}>
                <button onClick={() => openItem(n)} className="press flex w-full gap-3 rounded-2xl px-2 py-3 text-left hover:bg-surface-2">
                  <span className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${n.read ? "bg-surface-2 text-ink-3" : "bg-primary-soft text-primary-soft-ink"}`}>
                    <Icon size={17} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex items-start justify-between gap-2">
                      <span className={`text-[14px] ${n.read ? "font-medium text-ink-2" : "font-semibold text-ink"}`}>{n.title}</span>
                      {!n.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-primary" />}
                    </span>
                    <span className="mt-0.5 block text-[13px] leading-snug text-ink-3">{n.body}</span>
                    <span className="tnum mt-1 block text-[12px] text-ink-3">{formatTimestamp(n.at)}</span>
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      </Sheet>

      {searchOpen && <SearchDialog onClose={() => setSearchOpen(false)} staff={home === "/staff"} />}
    </>
  );
}

type Hit = { type: string; title: string; subtitle: string; href: string };

function SearchDialog({ onClose, staff }: { onClose: () => void; staff: boolean }) {
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<Hit[] | null>(null);
  const [loading, setLoading] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const router = useRouter();

  useEffect(() => {
    const t = setTimeout(() => input.current?.focus(), 50);
    return () => clearTimeout(t);
  }, []);

  const active = q.trim().length >= 2;
  useEffect(() => {
    if (!active) return;
    const ctl = new AbortController();
    const t = setTimeout(async () => {
      setLoading(true);
      try {
        const r = await fetch(`/api/search?q=${encodeURIComponent(q.trim())}`, { signal: ctl.signal });
        const d = (await r.json()) as { hits: Hit[] };
        setHits(d.hits);
      } catch {}
      setLoading(false);
    }, 180);
    return () => {
      clearTimeout(t);
      ctl.abort();
    };
  }, [q, active]);

  return (
    <Sheet open onClose={onClose} title="Поиск">
      <div className="sticky top-0 bg-surface pb-2">
        <label className="flex h-12 items-center gap-2.5 rounded-xl border border-line-strong bg-surface-2 px-3.5 focus-within:border-primary">
          <Search size={18} className="text-ink-3" />
          <input
            ref={input}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={staff ? "Номер, ФИО, группа" : "Дисциплина, преподаватель, номер заявки"}
            className="h-full min-w-0 flex-1 bg-transparent text-[16px] outline-none placeholder:text-ink-3"
            enterKeyHint="search"
          />
          {q && (
            <button onClick={() => setQ("")} aria-label="Очистить" className="text-ink-3">
              <X size={17} />
            </button>
          )}
        </label>
      </div>
      {active && loading && !hits && <p className="py-6 text-center text-[13px] text-ink-3">Ищем…</p>}
      {active && hits && hits.length === 0 && staff && <p className="py-8 text-center text-[14px] text-ink-2">Ничего не нашлось</p>}
      {active && hits && hits.length === 0 && !staff && (
        <div className="py-8 text-center">
          <p className="text-[14px] text-ink-2">Ничего не нашлось</p>
          <button
            onClick={() => {
              onClose();
              router.push(`/assistant?q=${encodeURIComponent(q)}`);
            }}
            className="press mt-3 text-[13.5px] font-semibold text-violet-ink"
          >
            Спросить NEXT AI
          </button>
        </div>
      )}
      <ul className="-mx-2">
        {active && hits?.map((h, i) => (
          <li key={i}>
            <Link href={h.href} onClick={onClose} className="press flex flex-col rounded-xl px-2 py-2.5 hover:bg-surface-2">
              <span className="text-[14px] font-medium">{h.title}</span>
              <span className="text-[12.5px] text-ink-3">
                {h.type}: {h.subtitle}
              </span>
            </Link>
          </li>
        ))}
      </ul>
      {!q && <p className="pt-2 text-[13px] text-ink-3">{staff ? "Например: «MN-26-012», «Лебедев», «МО-2-03»" : "Например: «экономика», «MN-26», «Беляев»"}</p>}
    </Sheet>
  );
}
