"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { STAFF_NAV, STUDENT_NAV } from "./nav";

export function BottomNav({ role }: { role: "student" | "staff" }) {
  const path = usePathname();
  const items = role === "staff" ? STAFF_NAV : STUDENT_NAV;
  return (
    <nav
      aria-label="Основная навигация"
      className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-surface/90 backdrop-blur-xl pb-safe lg:hidden"
    >
      <ul className="mx-auto flex max-w-xl items-stretch justify-around px-1.5 pt-1.5 pb-1">
        {items.map((it) => {
          const active = path === it.href || path.startsWith(it.href + "/");
          const Icon = it.icon;
          return (
            <li key={it.href} className="flex-1">
              <Link
                href={it.href}
                aria-current={active ? "page" : undefined}
                className="press group flex min-h-[54px] flex-col items-center justify-center gap-1 rounded-2xl"
              >
                <span
                  className={[
                    "flex h-8 w-14 items-center justify-center rounded-full transition-colors",
                    it.ai
                      ? active
                        ? "bg-violet text-white"
                        : "bg-violet-soft text-violet-ink"
                      : active
                        ? "bg-primary-soft text-primary-soft-ink"
                        : "text-ink-3 group-hover:text-ink-2",
                  ].join(" ")}
                >
                  <Icon size={21} strokeWidth={active ? 2.2 : 1.9} />
                </span>
                <span
                  className={[
                    "text-[11px] leading-none tracking-[-0.005em]",
                    active ? (it.ai ? "font-semibold text-violet-ink" : "font-semibold text-primary-soft-ink") : it.ai ? "font-medium text-violet-ink" : "text-ink-3",
                  ].join(" ")}
                >
                  {it.label}
                </span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
