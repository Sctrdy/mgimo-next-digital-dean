import { CalendarDays, GraduationCap, Sparkles, FileText, UserRound, Inbox, type LucideIcon } from "lucide-react";

export type NavItem = { href: string; label: string; icon: LucideIcon; ai?: boolean };

export const STUDENT_NAV: NavItem[] = [
  { href: "/schedule", label: "Расписание", icon: CalendarDays },
  { href: "/study", label: "Учёба", icon: GraduationCap },
  { href: "/assistant", label: "NEXT AI", icon: Sparkles, ai: true },
  { href: "/dean", label: "Деканат", icon: FileText },
  { href: "/profile", label: "Профиль", icon: UserRound },
];

export const STAFF_NAV: NavItem[] = [
  { href: "/staff", label: "Обращения", icon: Inbox },
  { href: "/profile", label: "Профиль", icon: UserRound },
];
