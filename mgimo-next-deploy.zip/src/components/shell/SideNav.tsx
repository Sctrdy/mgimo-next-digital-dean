"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { STAFF_NAV, STUDENT_NAV } from "./nav";
import { Wordmark } from "./Logo";
import type { PublicUser } from "@/lib/types";

export function SideNav({ user }: { user: PublicUser }) {
  const path = usePathname();
  const items = user.role === "staff" ? STAFF_NAV : STUDENT_NAV;
  return (
    <aside className="sticky top-0 hidden h-dvh w-[248px] shrink-0 flex-col border-r border-line bg-surface px-4 py-5 lg:flex">
      <Link href={items[0].href} className="px-2" aria-label="MGIMO NEXT — на главную">
        <Wordmark />
      </Link>
      <nav aria-label="Основная навигация" className="mt-8 flex flex-col gap-1">
        {items.map((it) => {
          const active = path === it.href || path.startsWith(it.href + "/");
          const Icon = it.icon;
          return (
            <Link
              key={it.href}
              href={it.href}
              aria-current={active ? "page" : undefined}
              className={[
                "press flex h-11 items-center gap-3 rounded-xl px-3 text-[14.5px]",
                active
                  ? it.ai
                    ? "bg-violet-soft font-semibold text-violet-ink"
                    : "bg-primary-soft font-semibold text-primary-soft-ink"
                  : it.ai
                    ? "font-medium text-violet-ink hover:bg-violet-soft/60"
                    : "text-ink-2 hover:bg-surface-2",
              ].join(" ")}
            >
              <Icon size={19} strokeWidth={active ? 2.2 : 1.9} />
              {it.label}
              {it.ai && <span className="ml-auto rounded-md bg-violet/10 px-1.5 py-0.5 text-[10.5px] font-semibold text-violet-ink">AI</span>}
            </Link>
          );
        })}
      </nav>
      <div className="mt-auto rounded-2xl bg-surface-2 p-3">
        <p className="text-[13px] font-semibold text-ink">{user.shortName}</p>
        <p className="mt-0.5 text-[12px] text-ink-3">{user.role === "staff" ? user.position : `${user.group} · ${user.course} курс`}</p>
      </div>
      <p className="mt-3 px-1 text-[11px] leading-snug text-ink-3">
        Неофициальный конкурсный прототип. Все данные демонстрационные и вымышленные.
      </p>
    </aside>
  );
}
