// Оригинальная монограмма N: две опоры и диагональ-«переход», точка — следующий шаг.
export function Monogram({ size = 32, className = "" }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden className={`shrink-0 ${className}`}>
      <rect width="64" height="64" rx="16" fill="#07172F" />
      <rect x="0.75" y="0.75" width="62.5" height="62.5" rx="15.25" fill="none" stroke="#45C9FF" strokeOpacity="0.18" strokeWidth="1.5" />
      <path d="M19 46V18M45 18v28" stroke="#FFFFFF" strokeWidth="6" strokeLinecap="round" />
      <path d="M20 19l24 26" stroke="#45C9FF" strokeWidth="6" strokeLinecap="round" />
      <circle cx="51" cy="13" r="3.5" fill="#1769E0" />
    </svg>
  );
}

export function Wordmark({ compact = false }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-2.5">
      <Monogram size={compact ? 28 : 32} />
      <span className="text-[15px] font-semibold leading-none tracking-[-0.01em] text-ink">
        MGIMO <span className="font-bold text-primary">NEXT</span>
      </span>
    </span>
  );
}
