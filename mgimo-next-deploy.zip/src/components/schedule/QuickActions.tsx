"use client";
import Link from "next/link";
import { FilePlus2, BarChart3, Sparkles, ListPlus } from "lucide-react";

export function QuickActions({ onCreateTask }: { onCreateTask: () => void }) {
  const cls = "press flex flex-col items-center justify-center gap-1.5 rounded-2xl border border-line bg-surface px-1 py-3 text-center text-[12px] font-medium leading-tight text-ink-2 hover:border-line-strong";
  return (
    <section aria-label="Быстрые действия" className="grid grid-cols-4 gap-2">
      <Link href="/dean/new" className={cls}>
        <FilePlus2 size={20} className="text-primary" /> Заказать справку
      </Link>
      <Link href="/study" className={cls}>
        <BarChart3 size={20} className="text-primary" /> Проверить оценки
      </Link>
      <Link href="/assistant" className={`${cls} border-violet/25 bg-violet-soft/60 text-violet-ink`}>
        <Sparkles size={20} className="text-violet" /> Открыть NEXT AI
      </Link>
      <button onClick={onCreateTask} className={cls}>
        <ListPlus size={20} className="text-primary" /> Создать задачу
      </button>
    </section>
  );
}
