"use client";
import Link from "next/link";
import { CalendarPlus, Clock3, DoorOpen, ListPlus, Sparkles, UserRound, AlertTriangle, FlagTriangleRight } from "lucide-react";
import { Sheet } from "@/components/ui/Sheet";
import type { Assessment, Lesson } from "@/lib/types";
import { dateLong, inDays, diffDays, wdFull, type Now } from "@/lib/time";

export function LessonSheet({
  lesson: l, onClose, assessments, now, onCreateTask,
}: { lesson: Lesson | null; onClose: () => void; assessments: Assessment[]; now: Now; onCreateTask: (courseId: number) => void }) {
  if (!l) return <Sheet open={false} onClose={onClose}>{null}</Sheet>;
  const next = assessments.filter((a) => a.courseId === l.courseId && !a.past).slice(0, 3);
  const row = (icon: React.ReactNode, label: string, value: React.ReactNode) => (
    <li className="flex items-center gap-3 py-2.5">
      <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-surface-2 text-ink-2">{icon}</span>
      <span className="w-24 shrink-0 text-[13px] text-ink-3">{label}</span>
      <span className="min-w-0 flex-1 text-[14px] font-medium">{value}</span>
    </li>
  );
  return (
    <Sheet open onClose={onClose} title={l.type}>
      <h3 className={`text-[21px] font-semibold leading-tight tracking-[-0.02em] ${l.status === "cancelled" ? "text-ink-3 line-through" : ""}`}>{l.course}</h3>
      {l.note && (
        <p className={`mt-2 flex items-center gap-2 rounded-xl px-3 py-2 text-[13px] font-medium ${l.status === "cancelled" ? "bg-red-soft text-red" : l.status === "added" ? "bg-violet-soft text-violet-ink" : "bg-amber-soft text-amber"}`}>
          <AlertTriangle size={15} className="shrink-0" />
          {l.note}
          {l.was?.room && `: было ${l.was.room}`}
          {l.was?.teacher && `: вместо ${l.was.teacher}`}
        </p>
      )}
      <ul className="mt-2 divide-y divide-line">
        {row(<Clock3 size={16} />, "Время", <span className="tnum">{wdFull(l.date)}, {dateLong(l.date)}, {l.start}–{l.end} ({l.pair} пара)</span>)}
        {row(<DoorOpen size={16} />, "Аудитория", l.room)}
        {row(<UserRound size={16} />, "Преподаватель", l.teacher)}
      </ul>

      {next.length > 0 && (
        <div className="mt-4">
          <p className="mb-2 text-[13px] font-semibold text-ink-2">Ближайший контроль по предмету</p>
          <ul className="space-y-1.5">
            {next.map((a) => (
              <li key={a.id} className="flex items-center gap-2.5 rounded-xl bg-surface-2 px-3 py-2.5 text-[13.5px]">
                <FlagTriangleRight size={15} className="shrink-0 text-violet-ink" />
                <span className="min-w-0 flex-1 truncate">{a.title}</span>
                <span className="shrink-0 text-[12.5px] text-ink-3">{inDays(diffDays(now.date, a.date))}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-5 grid grid-cols-1 gap-2 sm:grid-cols-3">
        <Link href={`/assistant?q=${encodeURIComponent(`Что повторить к занятию «${l.course}» (${l.type.toLowerCase()})?`)}`} className="press flex h-11 items-center justify-center gap-2 rounded-xl bg-violet-soft text-[13.5px] font-semibold text-violet-ink">
          <Sparkles size={16} /> Спросить AI
        </Link>
        <button onClick={() => onCreateTask(l.courseId)} className="press flex h-11 items-center justify-center gap-2 rounded-xl border border-line-strong text-[13.5px] font-semibold">
          <ListPlus size={16} /> Задача
        </button>
        <a href={`/api/calendar?lesson=${encodeURIComponent(l.id)}`} className="press flex h-11 items-center justify-center gap-2 rounded-xl border border-line-strong text-[13.5px] font-semibold">
          <CalendarPlus size={16} /> В календарь
        </a>
      </div>
    </Sheet>
  );
}
