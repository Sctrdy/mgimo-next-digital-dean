"use client";
import Link from "next/link";
import { useState } from "react";
import { AlarmClock, BookOpenCheck, CalendarClock, CheckCircle2, FileCheck2, FileClock, GraduationCap, ListTodo, ShieldAlert, Sparkles } from "lucide-react";
import type { ImportantItem } from "@/lib/types";
import { SectionTitle } from "@/components/ui/kit";

const ICON = {
  assessment: BookOpenCheck,
  exam: GraduationCap,
  deadline: AlarmClock,
  task: ListTodo,
  request: FileClock,
  change: CalendarClock,
  debt: ShieldAlert,
} as const;

const TONE: Record<ImportantItem["tone"], string> = {
  blue: "bg-primary-soft text-primary-soft-ink",
  violet: "bg-violet-soft text-violet-ink",
  amber: "bg-amber-soft text-amber",
  red: "bg-red-soft text-red",
  green: "bg-green-soft text-green",
  slate: "bg-surface-2 text-ink-2",
};

export function ImportantList({ items }: { items: ImportantItem[] }) {
  const [all, setAll] = useState(false);
  const shown = all ? items : items.slice(0, 5);
  return (
    <section aria-labelledby="important-title">
      <SectionTitle>
        <span id="important-title">Важное для тебя</span>
      </SectionTitle>
      {items.length === 0 ? (
        <div className="flex items-center gap-3 rounded-[20px] border border-line bg-surface px-4 py-4">
          <CheckCircle2 className="text-green" size={20} />
          <p className="text-[14px] text-ink-2">Срочных дел нет. Ближайшие две недели свободны от контрольных.</p>
        </div>
      ) : (
        <ul className="overflow-hidden rounded-[20px] border border-line bg-surface">
          {shown.map((it, i) => {
            const Icon = it.kind === "request" && it.tone === "green" ? FileCheck2 : ICON[it.kind];
            return (
              <li key={it.id} className={`flex gap-3 px-3.5 py-3 ${i ? "border-t border-line" : ""}`}>
                <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${TONE[it.tone]}`}>
                  <Icon size={17} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="line-clamp-2 text-[14px] font-semibold leading-snug">{it.title}</span>
                  <span className="mt-0.5 line-clamp-2 text-[12.5px] leading-snug text-ink-3">{it.subtitle}</span>
                  <Link
                    href={it.action.href}
                    className={`press mt-2 inline-flex h-8 items-center gap-1 rounded-lg px-2.5 text-[12.5px] font-semibold ${it.action.href.startsWith("/assistant") ? "bg-violet-soft text-violet-ink" : "bg-primary-soft text-primary-soft-ink"}`}
                  >
                    {it.action.href.startsWith("/assistant") && <Sparkles size={13} />}
                    {it.action.label}
                  </Link>
                </span>
                {it.when && <span className="w-[76px] shrink-0 pt-0.5 text-right text-[12px] leading-snug text-ink-3">{it.when}</span>}
              </li>
            );
          })}
          {items.length > 5 && (
            <li className="border-t border-line">
              <button onClick={() => setAll((a) => !a)} className="press h-11 w-full text-[13px] font-semibold text-primary-soft-ink">
                {all ? "Свернуть" : `Показать все (${items.length})`}
              </button>
            </li>
          )}
        </ul>
      )}
    </section>
  );
}
