"use client";
import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Check, Plus, Trash2, Loader2 } from "lucide-react";
import type { Task } from "@/lib/types";
import { SectionTitle, Button } from "@/components/ui/kit";
import { Sheet } from "@/components/ui/Sheet";
import { addDays, diffDays, relDay } from "@/lib/time";

export function TasksBlock({ tasks, today, onCreate }: { tasks: Task[]; today: string; onCreate: () => void }) {
  const router = useRouter();
  const [local, setLocal] = useState(tasks);
  const [, start] = useTransition();
  const [prevTasks, setPrevTasks] = useState(tasks);
  if (prevTasks !== tasks) {
    setPrevTasks(tasks);
    setLocal(tasks);
  }
  const open = local.filter((t) => !t.done);
  const done = local.filter((t) => t.done);

  const toggle = async (t: Task) => {
    setLocal((l) => l.map((x) => (x.id === t.id ? { ...x, done: !x.done } : x)));
    await fetch(`/api/tasks/${t.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ done: !t.done }) });
    start(() => router.refresh());
  };
  const remove = async (t: Task) => {
    setLocal((l) => l.filter((x) => x.id !== t.id));
    await fetch(`/api/tasks/${t.id}`, { method: "DELETE" });
    start(() => router.refresh());
  };

  return (
    <section aria-labelledby="tasks">
      <SectionTitle
        id="tasks"
        action={
          <button onClick={onCreate} className="press flex items-center gap-1 text-[13px] font-semibold text-primary-soft-ink">
            <Plus size={15} /> Добавить
          </button>
        }
      >
        Мои задачи
      </SectionTitle>
      <div className="overflow-hidden rounded-[20px] border border-line bg-surface">
        {open.length === 0 && <p className="px-4 py-4 text-[13.5px] text-ink-3">Открытых задач нет. Добавьте, например, подготовку к семинару.</p>}
        <ul>
          {[...open, ...done.slice(0, 3)].map((t, i) => {
            const d = t.dueDate ? diffDays(today, t.dueDate) : null;
            return (
              <li key={t.id} className={`group flex items-center gap-3 px-3.5 py-2.5 ${i ? "border-t border-line" : ""}`}>
                <button
                  onClick={() => toggle(t)}
                  aria-label={t.done ? "Вернуть в работу" : "Отметить выполненной"}
                  className={`press flex h-6 w-6 shrink-0 items-center justify-center rounded-lg border-2 ${t.done ? "border-green bg-green text-white" : "border-line-strong hover:border-primary"}`}
                >
                  {t.done && <Check size={14} strokeWidth={3} />}
                </button>
                <span className="min-w-0 flex-1">
                  <span className={`block text-[14px] leading-snug ${t.done ? "text-ink-3 line-through" : "font-medium"}`}>{t.title}</span>
                  {(t.dueDate || t.course) && !t.done && (
                    <span className={`block truncate text-[12px] ${d !== null && d < 0 ? "font-semibold text-red" : "text-ink-3"}`}>
                      {t.dueDate ? (d !== null && d < 0 ? `Просрочено, ${relDay(t.dueDate, today)}` : relDay(t.dueDate, today)) : ""}
                      {t.dueTime ? `, ${t.dueTime}` : ""}
                      {t.course ? `${t.dueDate ? " · " : ""}${t.course}` : ""}
                    </span>
                  )}
                </span>
                <button onClick={() => remove(t)} aria-label="Удалить задачу" className="press flex h-8 w-8 items-center justify-center rounded-lg text-ink-3 opacity-60 hover:bg-surface-2 hover:text-red group-hover:opacity-100">
                  <Trash2 size={15} />
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}

export function TaskSheet({
  open, onClose, courseId, courses, today,
}: { open: boolean; onClose: () => void; courseId?: number; courses: { id: number; name: string }[]; today: string }) {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [date, setDate] = useState(today);
  const [time, setTime] = useState("");
  const [course, setCourse] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // сброс формы при каждом открытии
  const [wasOpen, setWasOpen] = useState(open);
  if (open !== wasOpen) {
    setWasOpen(open);
    if (open) {
      setTitle("");
      setDate(addDays(today, 1));
      setTime("");
      setCourse(courseId ? String(courseId) : "");
      setError(null);
    }
  }

  const save = async () => {
    setBusy(true);
    setError(null);
    const r = await fetch("/api/tasks", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ title, dueDate: date || null, dueTime: time || null, courseId: course ? Number(course) : null }),
    });
    setBusy(false);
    if (!r.ok) {
      setError((await r.json().catch(() => ({}))).error ?? "Не удалось сохранить задачу");
      return;
    }
    onClose();
    router.refresh();
  };

  const field = "h-12 w-full rounded-xl border border-line-strong bg-surface px-3.5 text-[16px] outline-none focus:border-primary";
  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Новая задача"
      footer={
        <Button onClick={save} disabled={busy || title.trim().length < 2} className="w-full" size="lg">
          {busy && <Loader2 size={17} className="animate-spin" />} Сохранить задачу
        </Button>
      }
    >
      <div className="space-y-3">
        <label className="block">
          <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Что сделать</span>
          <input autoFocus value={title} onChange={(e) => setTitle(e.target.value)} className={field} placeholder="Например, прочитать статью к семинару" maxLength={140} />
        </label>
        <div className="grid grid-cols-2 gap-3">
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Срок</span>
            <input type="date" value={date} min={today} onChange={(e) => setDate(e.target.value)} className={field} />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Время</span>
            <input type="time" value={time} onChange={(e) => setTime(e.target.value)} className={field} />
          </label>
        </div>
        <label className="block">
          <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Дисциплина</span>
          <select value={course} onChange={(e) => setCourse(e.target.value)} className={field}>
            <option value="">Без дисциплины</option>
            {courses.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </label>
        {error && <p className="rounded-xl bg-red-soft px-3 py-2 text-[13px] text-red">{error}</p>}
      </div>
    </Sheet>
  );
}
