"use client";
import { useState } from "react";
import { Sheet } from "@/components/ui/Sheet";
import type { Assessment } from "@/lib/types";
import { diffDays, inDays, relDay, type Now } from "@/lib/time";

export function ControlsSheet({ open, onClose, assessments, now }: { open: boolean; onClose: () => void; assessments: Assessment[]; now: Now }) {
  const [tab, setTab] = useState<"current" | "final" | "past">("current");
  const list = assessments.filter((a) =>
    tab === "past" ? a.past : !a.past && (tab === "final" ? a.kind === "Экзамен" || a.kind === "Зачёт" : a.kind !== "Экзамен" && a.kind !== "Зачёт"),
  );
  const ordered = tab === "past" ? [...list].reverse() : list;
  return (
    <Sheet open={open} onClose={onClose} title="Контрольные, дедлайны и экзамены">
      <div className="mb-3 flex gap-1 rounded-xl bg-surface-2 p-1">
        {([["current", "Текущий контроль"], ["final", "Сессия"], ["past", "Прошедшие"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`press h-8 flex-1 rounded-lg text-[12.5px] font-semibold ${tab === k ? "bg-surface shadow-soft" : "text-ink-3"}`}>
            {l}
          </button>
        ))}
      </div>
      {ordered.length === 0 && <p className="py-8 text-center text-[14px] text-ink-3">Здесь пока пусто</p>}
      <ul className="divide-y divide-line">
        {ordered.map((a) => (
          <li key={a.id} className="flex items-center gap-3 py-2.5">
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[14px] font-medium">{a.title === "Экзамен" || a.title === "Зачёт" ? `${a.title}: ${a.course}` : a.title}</span>
              <span className="block truncate text-[12.5px] text-ink-3">
                {a.course !== a.title ? `${a.course}, ` : ""}
                {relDay(a.date, now.date)}
                {a.time && a.time !== "23:59" ? `, ${a.time}` : a.time ? ", до 23:59" : ""}
                {a.room ? `, ${a.room}` : ""}
              </span>
            </span>
            <span className="tnum shrink-0 text-right text-[13px]">
              {a.past ? (
                a.score !== null ? (
                  <span className="font-semibold">
                    {a.score}
                    <span className="text-ink-3">/{a.maxScore}</span>
                  </span>
                ) : (
                  <span className="text-ink-3">ждёт оценки</span>
                )
              ) : (
                <span className="text-ink-3">{inDays(diffDays(now.date, a.date))}</span>
              )}
            </span>
          </li>
        ))}
      </ul>
    </Sheet>
  );
}
