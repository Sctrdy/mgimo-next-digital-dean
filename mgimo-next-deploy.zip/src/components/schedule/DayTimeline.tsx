"use client";
import { useState } from "react";
import { ChevronDown, Coffee, FlagTriangleRight, PartyPopper } from "lucide-react";
import type { Assessment, Lesson } from "@/lib/types";
import { duration, toMinutes, type Now } from "@/lib/time";

export function lessonAssessments(l: Lesson, all: Assessment[]) {
  return all.filter(
    (a) => a.date === l.date && a.courseId === l.courseId && a.time && toMinutes(a.time) >= toMinutes(l.start) - 5 && toMinutes(a.time) < toMinutes(l.end),
  );
}

export function DayTimeline({
  date, lessons, assessments, now, onOpen,
}: { date: string; lessons: Lesson[]; assessments: Assessment[]; now: Now; onOpen: (l: Lesson) => void }) {
  const [showPast, setShowPast] = useState(false);
  const dayAsm = assessments.filter((a) => a.date === date);
  const attached = new Set(lessons.flatMap((l) => lessonAssessments(l, assessments).map((a) => a.id)));
  const loose = dayAsm.filter((a) => !attached.has(a.id));

  if (!lessons.length) {
    return (
      <div className="rounded-[20px] border border-dashed border-line-strong px-5 py-8 text-center">
        <PartyPopper className="mx-auto text-ink-3" size={22} />
        <p className="mt-2 text-[15px] font-semibold">Занятий нет</p>
        <p className="mt-0.5 text-[13.5px] text-ink-3">{loose.length ? "Но есть события контроля — ниже." : "Свободный день. Можно заняться задачами."}</p>
        {loose.length > 0 && <LooseList items={loose} />}
      </div>
    );
  }

  const isToday = date === now.date;
  const finished = isToday ? lessons.filter((l) => now.minutes >= toMinutes(l.end)) : [];
  const visible = showPast || finished.length === lessons.length ? lessons : lessons.slice(finished.length);
  const rows: React.ReactNode[] = [];
  visible.forEach((l, i) => {
    if (i > 0) {
      const prev = visible[i - 1];
      const gap = toMinutes(l.start) - toMinutes(prev.end);
      if (gap > 0) {
        const label = gap >= 90 ? `Окно ${duration(gap)}` : gap >= 40 ? `Большой перерыв, ${duration(gap)}` : `Перерыв ${duration(gap)}`;
        rows.push(
          <li key={`gap${i}`} className="grid grid-cols-[52px_20px_1fr] items-center gap-x-2 py-1">
            <span />
            <span className="flex justify-center">
              <span className="h-5 w-px border-l border-dashed border-line-strong" />
            </span>
            <span className="flex items-center gap-1.5 text-[12.5px] text-ink-3">
              {gap >= 40 && <Coffee size={13} />} {label}
            </span>
          </li>,
        );
      }
    }
    const s = toMinutes(l.start);
    const e = toMinutes(l.end);
    const live = isToday && now.minutes >= s && now.minutes < e && l.status !== "cancelled";
    const done = (isToday && now.minutes >= e) || date < now.date;
    const tags = lessonAssessments(l, assessments);
    const cancelled = l.status === "cancelled";
    rows.push(
      <li key={l.id} className={`grid grid-cols-[52px_20px_1fr] gap-x-2 ${done && !live ? "opacity-60" : ""}`}>
        <div className="tnum pt-3 text-right leading-tight">
          <div className={`text-[14px] font-semibold ${live ? "text-primary" : "text-ink"}`}>{l.start}</div>
          <div className="text-[12px] text-ink-3">{l.end}</div>
        </div>
        <div className="relative flex justify-center">
          {visible.length > 1 && (
            <span
              className={`absolute w-[2px] ${live ? "bg-primary" : "bg-line"}`}
              style={i === visible.length - 1 ? { top: 0, height: 16 } : { top: i === 0 ? 16 : 0, bottom: 0 }}
            />
          )}
          <span
            className={`relative mt-[15px] h-3 w-3 rounded-full border-2 ${
              live ? "now-dot border-primary bg-primary" : cancelled ? "border-line-strong bg-bg" : done ? "border-line-strong bg-line-strong" : "border-primary bg-surface"
            }`}
          />
        </div>
        <button
          onClick={() => onOpen(l)}
          className={[
            "press my-1 min-w-0 rounded-2xl border px-3.5 py-3 text-left",
            live ? "border-primary/40 bg-primary-soft/50 ring-1 ring-primary/20" : "border-line bg-surface hover:border-line-strong",
          ].join(" ")}
        >
          <div className="flex items-start justify-between gap-2">
            <span className={`text-[15px] font-semibold leading-snug tracking-[-0.01em] ${cancelled ? "text-ink-3 line-through" : ""}`}>{l.course}</span>
            <span className="tnum shrink-0 pt-0.5 text-[11.5px] text-ink-3">{l.pair} пара</span>
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-1 text-[13px] text-ink-2">
            <span className={`rounded-md px-1.5 py-px text-[12px] font-medium ${l.type === "Лекция" ? "bg-surface-2 text-ink-2" : l.type === "Консультация" ? "bg-violet-soft text-violet-ink" : "bg-primary-soft text-primary-soft-ink"}`}>
              {l.type}
            </span>
            <span className="font-medium text-ink">{l.room}</span>
            <span className="truncate text-ink-3">{l.teacher}</span>
          </div>
          {(l.status !== "normal" || tags.length > 0) && (
            <div className="mt-2 flex flex-wrap gap-1.5">
              {l.status === "changed" && (
                <span className="rounded-md bg-amber-soft px-1.5 py-0.5 text-[12px] font-medium text-amber">
                  {l.was?.room ? `Аудитория: ${l.was.room} → ${l.room}` : l.note}
                </span>
              )}
              {l.status === "cancelled" && <span className="rounded-md bg-red-soft px-1.5 py-0.5 text-[12px] font-medium text-red">{l.note}</span>}
              {l.status === "added" && <span className="rounded-md bg-violet-soft px-1.5 py-0.5 text-[12px] font-medium text-violet-ink">{l.note}</span>}
              {tags.map((a) => (
                <span key={a.id} className="inline-flex items-center gap-1 rounded-md bg-violet-soft px-1.5 py-0.5 text-[12px] font-semibold text-violet-ink">
                  <FlagTriangleRight size={12} /> {a.kind}
                </span>
              ))}
            </div>
          )}
          {live && (
            <div className="mt-2.5 h-1 overflow-hidden rounded-full bg-primary/15">
              <div className="h-full rounded-full bg-primary" style={{ width: `${((now.minutes - s) / (e - s)) * 100}%` }} />
            </div>
          )}
        </button>
      </li>,
    );
  });

  return (
    <>
      {finished.length > 0 && finished.length < lessons.length && (
        <button
          onClick={() => setShowPast((v) => !v)}
          className="press mb-1 flex h-9 items-center gap-1.5 rounded-xl px-2 text-[13px] font-medium text-ink-3 hover:bg-surface-2"
          aria-expanded={showPast}
        >
          <ChevronDown size={15} className={`transition-transform ${showPast ? "rotate-180" : ""}`} />
          {showPast ? "Скрыть прошедшие" : `Прошедшие занятия: ${finished.length}`}
        </button>
      )}
      <ol aria-label="Занятия">{rows}</ol>
      {loose.length > 0 && <LooseList items={loose} />}
    </>
  );
}

function LooseList({ items }: { items: Assessment[] }) {
  return (
    <ul className="mt-3 space-y-1.5 text-left">
      {items.map((a) => (
        <li key={a.id} className="flex items-center gap-2.5 rounded-xl bg-violet-soft/60 px-3 py-2 text-[13px]">
          <FlagTriangleRight size={14} className="shrink-0 text-violet-ink" />
          <span className="min-w-0 flex-1 truncate">
            <span className="font-semibold text-violet-ink">{a.kind}:</span> {a.title.replace(/^[^:]+:\s*/, "")}, {a.course}
          </span>
          <span className="tnum shrink-0 text-ink-3">{a.time === "23:59" ? "до 23:59" : a.time ?? ""}</span>
        </li>
      ))}
    </ul>
  );
}
