"use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ChevronLeft, ChevronRight, Download, ListChecks } from "lucide-react";
import type { Assessment, ImportantItem, Lesson, Task } from "@/lib/types";
import { addDays, dateLong, dayNum, diffDays, moscowNow, plural, wdFull, wdShort, type Now } from "@/lib/time";
import { dayStatusFrom } from "@/lib/status";
import { NowLine } from "./NowLine";
import { DayTimeline } from "./DayTimeline";
import { WeekGrid } from "./WeekGrid";
import { LessonSheet } from "./LessonSheet";
import { ImportantList } from "./ImportantList";
import { TasksBlock, TaskSheet } from "./TasksBlock";
import { QuickActions } from "./QuickActions";
import { ControlsSheet } from "./ControlsSheet";

type Mark = { date: string; lessons: number; changes: boolean; control: boolean };

export function ScheduleView(p: {
  now: Now; selected: string; monday: string; view: "day" | "week"; marks: Mark[]; lessons: Lesson[]; upcoming: Lesson[];
  assessments: Assessment[]; important: ImportantItem[]; tasks: Task[]; courses: { id: number; name: string }[]; firstName: string;
}) {
  const router = useRouter();
  const [now, setNow] = useState(p.now);
  const [selected, setSelected] = useState(p.selected);
  const [view, setView] = useState(p.view);
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [taskOpen, setTaskOpen] = useState<{ courseId?: number } | null>(null);
  const [controlsOpen, setControlsOpen] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setNow(moscowNow()), 30_000);
    return () => clearInterval(t);
  }, []);
  const [prevSelected, setPrevSelected] = useState(p.selected);
  if (prevSelected !== p.selected) {
    setPrevSelected(p.selected);
    setSelected(p.selected);
  }

  const status = useMemo(() => dayStatusFrom(p.upcoming, now), [p.upcoming, now]);
  const dayLessons = p.lessons.filter((l) => l.date === selected);
  const active = dayLessons.filter((l) => l.status !== "cancelled").length;

  const syncUrl = (date: string, v = view) => {
    const qs = new URLSearchParams();
    if (date !== now.date) qs.set("date", date);
    if (v === "week") qs.set("view", "week");
    window.history.replaceState(null, "", `/schedule${qs.size ? `?${qs}` : ""}`);
  };

  const pick = (date: string) => {
    if (date < p.monday || date > addDays(p.monday, 6)) {
      router.push(`/schedule?date=${date}${view === "week" ? "&view=week" : ""}`);
      return;
    }
    setSelected(date);
    syncUrl(date);
  };

  const switchView = (v: "day" | "week") => {
    setView(v);
    syncUrl(selected, v);
  };

  const isToday = selected === now.date;
  const rel = diffDays(now.date, selected);

  return (
    <div className="lg:grid lg:grid-cols-[minmax(0,1fr)_360px] lg:gap-8">
      <div className="min-w-0">
        {/* Заголовок */}
        <header className="flex items-end justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-[26px] font-semibold leading-[1.1] tracking-[-0.03em] sm:text-[30px]">Расписание</h1>
            <p className="mt-1 text-[14px] text-ink-3">
              <span className="capitalize">{isToday ? "сегодня" : rel === 1 ? "завтра" : wdFull(selected)}</span>, {dateLong(selected)}
              {" · "}
              <span className="whitespace-nowrap">{active ? `${active} ${plural(active, "пара", "пары", "пар")}` : "без занятий"}</span>
            </p>
          </div>
          <div className="flex shrink-0 items-center rounded-xl bg-surface-2 p-1" role="tablist" aria-label="Режим просмотра">
            {(["day", "week"] as const).map((v) => (
              <button
                key={v}
                role="tab"
                aria-selected={view === v}
                onClick={() => switchView(v)}
                className={`press h-8 rounded-lg px-3 text-[13px] font-semibold ${view === v ? "bg-surface text-ink shadow-soft" : "text-ink-3"}`}
              >
                {v === "day" ? "День" : "Неделя"}
              </button>
            ))}
          </div>
        </header>

        {/* Неделя */}
        <div className="mt-4 flex items-center gap-1">
          <button onClick={() => router.push(`/schedule?date=${addDays(p.monday, -7)}${view === "week" ? "&view=week" : ""}`)} className="press flex h-10 w-7 shrink-0 items-center justify-center rounded-lg text-ink-3 hover:bg-surface-2" aria-label="Предыдущая неделя">
            <ChevronLeft size={18} />
          </button>
          <ol className="grid flex-1 grid-cols-7 gap-1">
            {p.marks.map((m) => {
              const sel = m.date === selected;
              const today = m.date === now.date;
              return (
                <li key={m.date}>
                  <button
                    onClick={() => pick(m.date)}
                    aria-pressed={sel}
                    aria-label={`${wdFull(m.date)}, ${dateLong(m.date)}${m.lessons ? `, ${m.lessons} ${plural(m.lessons, "пара", "пары", "пар")}` : ""}`}
                    className={[
                      "press flex h-[62px] w-full flex-col items-center justify-center gap-1 rounded-2xl",
                      sel ? "bg-primary text-white shadow-[0_6px_18px_-8px_rgb(23_105_224/0.8)]" : today ? "bg-primary-soft text-primary-soft-ink" : "text-ink hover:bg-surface-2",
                    ].join(" ")}
                  >
                    <span className={`text-[11.5px] ${sel ? "text-white/80" : today ? "font-semibold" : "text-ink-3"}`}>{wdShort(m.date)}</span>
                    <span className="tnum text-[17px] font-semibold leading-none">{dayNum(m.date)}</span>
                    <span className="flex h-1.5 items-center gap-0.5">
                      {m.lessons > 0 && <span className={`h-1 w-1 rounded-full ${sel ? "bg-white" : "bg-primary"}`} />}
                      {m.control && <span className={`h-1 w-1 rounded-full ${sel ? "bg-cyan" : "bg-violet"}`} />}
                      {m.changes && <span className={`h-1 w-1 rounded-full ${sel ? "bg-amber-soft" : "bg-amber"}`} />}
                    </span>
                  </button>
                </li>
              );
            })}
          </ol>
          <button onClick={() => router.push(`/schedule?date=${addDays(p.monday, 7)}${view === "week" ? "&view=week" : ""}`)} className="press flex h-10 w-7 shrink-0 items-center justify-center rounded-lg text-ink-3 hover:bg-surface-2" aria-label="Следующая неделя">
            <ChevronRight size={18} />
          </button>
        </div>

        <div className="mt-4">
          <NowLine status={status} now={now} isToday={isToday} onJump={pick} onOpen={setLesson} />
        </div>

        <div className="mt-3">
          {view === "day" ? (
            <DayTimeline date={selected} lessons={dayLessons} assessments={p.assessments} now={now} onOpen={setLesson} />
          ) : (
            <WeekGrid monday={p.monday} lessons={p.lessons} assessments={p.assessments} now={now} selected={selected} onOpen={setLesson} onPick={(d) => { pick(d); switchView("day"); }} />
          )}
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <button onClick={() => setControlsOpen(true)} className="press inline-flex h-9 items-center gap-1.5 rounded-xl border border-line bg-surface px-3 text-[13px] font-medium text-ink-2 hover:bg-surface-2">
            <ListChecks size={15} /> Контрольные и экзамены
          </button>
          <a href="/api/calendar" className="press inline-flex h-9 items-center gap-1.5 rounded-xl border border-line bg-surface px-3 text-[13px] font-medium text-ink-2 hover:bg-surface-2">
            <Download size={15} /> Экспорт в календарь
          </a>
        </div>
      </div>

      <aside className="mt-8 space-y-7 lg:mt-0">
        <ImportantList items={p.important} />
        <QuickActions onCreateTask={() => setTaskOpen({})} />
        <TasksBlock tasks={p.tasks} today={now.date} onCreate={() => setTaskOpen({})} />
      </aside>

      <LessonSheet
        lesson={lesson}
        onClose={() => setLesson(null)}
        assessments={p.assessments}
        now={now}
        onCreateTask={(courseId) => {
          setLesson(null);
          setTaskOpen({ courseId });
        }}
      />
      <TaskSheet open={!!taskOpen} courseId={taskOpen?.courseId} courses={p.courses} today={now.date} onClose={() => setTaskOpen(null)} />
      <ControlsSheet open={controlsOpen} onClose={() => setControlsOpen(false)} assessments={p.assessments} now={now} />
    </div>
  );
}
