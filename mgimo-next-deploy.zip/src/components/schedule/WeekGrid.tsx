"use client";
import type { Assessment, Lesson } from "@/lib/types";
import { addDays, dayNum, wdShort, type Now } from "@/lib/time";
import { lessonAssessments } from "./DayTimeline";

export function WeekGrid({
  monday, lessons, assessments, now, selected, onOpen, onPick,
}: { monday: string; lessons: Lesson[]; assessments: Assessment[]; now: Now; selected: string; onOpen: (l: Lesson) => void; onPick: (d: string) => void }) {
  const days = Array.from({ length: 7 }, (_, i) => addDays(monday, i)).filter((d, i) => i < 6 || lessons.some((l) => l.date === d));
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
      {days.map((d) => {
        const ls = lessons.filter((l) => l.date === d);
        const today = d === now.date;
        return (
          <section key={d} className={`rounded-[20px] border bg-surface p-3 ${today ? "border-primary/40" : "border-line"}`}>
            <button onClick={() => onPick(d)} className="press mb-1.5 flex w-full items-baseline gap-2 px-1 text-left">
              <span className={`text-[14px] font-semibold capitalize ${today ? "text-primary" : ""}`}>{wdShort(d)}</span>
              <span className="tnum text-[13px] text-ink-3">{dayNum(d)}</span>
              {today && <span className="text-[12px] font-semibold text-primary">сегодня</span>}
              {d === selected && !today && <span className="h-1.5 w-1.5 rounded-full bg-primary" />}
              <span className="ml-auto text-[12px] text-ink-3">{ls.filter((l) => l.status !== "cancelled").length || "—"}</span>
            </button>
            {ls.length === 0 ? (
              <p className="px-1 py-2 text-[13px] text-ink-3">Нет занятий</p>
            ) : (
              <ul>
                {ls.map((l) => {
                  const tag = lessonAssessments(l, assessments)[0];
                  return (
                    <li key={l.id}>
                      <button onClick={() => onOpen(l)} className="press flex w-full items-center gap-2.5 rounded-xl px-1 py-1.5 text-left hover:bg-surface-2">
                        <span className="tnum w-11 shrink-0 text-[13px] font-semibold text-ink-2">{l.start}</span>
                        <span className={`h-7 w-[3px] shrink-0 rounded-full ${l.status === "cancelled" ? "bg-line-strong" : l.status === "normal" ? "bg-primary" : "bg-amber"}`} />
                        <span className="min-w-0 flex-1">
                          <span className={`block truncate text-[13.5px] font-medium ${l.status === "cancelled" ? "text-ink-3 line-through" : ""}`}>{l.course}</span>
                          <span className="block truncate text-[12px] text-ink-3">
                            {l.type}, {l.room}
                            {tag && <span className="font-semibold text-violet-ink"> · {tag.kind}</span>}
                          </span>
                        </span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        );
      })}
    </div>
  );
}
