"use client";
import { ArrowRight, CalendarCheck2, MoonStar } from "lucide-react";
import type { DayStatus } from "@/lib/status";
import type { Lesson } from "@/lib/types";
import { duration, relDay, type Now } from "@/lib/time";

/** Тонкая строка статуса над таймлайном: сама пара уже подсвечена в списке, здесь — только время. */
export function NowLine({
  status, now, isToday, onJump, onOpen,
}: { status: DayStatus; now: Now; isToday: boolean; onJump: (d: string) => void; onOpen: (l: Lesson) => void }) {
  const base = "press flex min-h-10 w-full items-center gap-2.5 rounded-xl px-3 py-2 text-left text-[13.5px]";

  if (!isToday) {
    return (
      <button onClick={() => onJump(now.date)} className={`${base} bg-surface-2 text-ink-2`}>
        <CalendarCheck2 size={16} className="shrink-0 text-primary" />
        <span className="flex-1">Вернуться к сегодняшнему дню</span>
        <ArrowRight size={15} className="shrink-0 text-ink-3" />
      </button>
    );
  }

  if (status.kind === "during") {
    return (
      <button onClick={() => onOpen(status.lesson)} className={`${base} bg-primary-soft text-primary-soft-ink`}>
        <span className="now-dot h-2 w-2 shrink-0 rounded-full bg-primary" />
        <span className="min-w-0 flex-1 truncate">
          <span className="font-semibold">Идёт {status.lesson.pair} пара</span>, до {status.lesson.end}
        </span>
        <span className="tnum shrink-0 font-semibold">ещё {duration(status.minutesLeft)}</span>
      </button>
    );
  }

  if (status.kind === "before") {
    return (
      <button onClick={() => onOpen(status.lesson)} className={`${base} bg-primary-soft text-primary-soft-ink`}>
        <span className="h-2 w-2 shrink-0 rounded-full border-2 border-primary" />
        <span className="min-w-0 flex-1 truncate">
          До начала {status.lesson.pair} пары, {status.lesson.room}
        </span>
        <span className="tnum shrink-0 font-semibold">{duration(status.minutesUntil)}</span>
      </button>
    );
  }

  if (status.kind === "next_day") {
    const l = status.lesson;
    return (
      <button onClick={() => onJump(status.date)} className={`${base} bg-surface-2 text-ink-2`}>
        <MoonStar size={16} className="shrink-0 text-primary" />
        <span className="min-w-0 flex-1">
          Занятия на сегодня закончились. Дальше: <span className="font-semibold text-ink">{relDay(status.date, now.date)}, {l.start}, {l.course}</span>
        </span>
        <ArrowRight size={15} className="shrink-0 text-ink-3" />
      </button>
    );
  }

  return null;
}
