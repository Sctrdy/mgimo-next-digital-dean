"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Bell, CalendarDays, LogOut, MapPin, Monitor, Moon, Sun, Info, Loader2 } from "lucide-react";
import type { PublicUser } from "@/lib/types";
import { Monogram } from "@/components/shell/Logo";
import { SectionTitle, Disclaimer } from "@/components/ui/kit";
import { relDay } from "@/lib/time";

type Theme = "light" | "dark" | "system";
type Event = { id: number; title: string; date: string; time: string; place: string; tag: string };

export function ProfileView({
  user, prefs: initialPrefs, events, academic, today,
}: {
  user: PublicUser; prefs: Record<string, boolean>; events: Event[]; today: string;
  academic: { average: number | null; closed: number; credits: number; courses: number; debts: number } | null;
}) {
  const router = useRouter();
  const [theme, setTheme] = useState<Theme>("system");
  const [prefs, setPrefs] = useState(initialPrefs);
  const [leaving, setLeaving] = useState(false);

  useEffect(() => {
    try {
      // значение из localStorage доступно только в браузере, поэтому читаем после монтирования
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setTheme((localStorage.getItem("mn-theme") as Theme) || "system");
    } catch {}
  }, []);

  const applyTheme = (t: Theme) => {
    setTheme(t);
    try {
      localStorage.setItem("mn-theme", t);
    } catch {}
    const dark = t === "dark" || (t === "system" && matchMedia("(prefers-color-scheme: dark)").matches);
    document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
  };

  const toggle = async (k: string) => {
    if (k === "requests") return;
    const next = { ...prefs, [k]: !prefs[k] };
    setPrefs(next);
    const r = await fetch("/api/profile", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ prefs: next }) });
    if (!r.ok) setPrefs(prefs);
  };

  const logout = async () => {
    setLeaving(true);
    await fetch("/api/auth/logout", { method: "POST" });
    router.replace("/login");
    router.refresh();
  };

  const student = user.role === "student";

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="sr-only">Профиль</h1>

      {/* Цифровая карточка — не удостоверение и не пропуск */}
      <section
        aria-label="Карточка MGIMO NEXT"
        className="relative overflow-hidden rounded-[28px] border border-white/60 p-5 text-navy shadow-soft dark:border-white/10 dark:text-white sm:p-6"
        style={{ background: "var(--card-grad)" }}
      >
        <svg className="pointer-events-none absolute -right-10 -top-12 h-56 w-56 opacity-[0.09] dark:opacity-[0.12]" viewBox="0 0 64 64" aria-hidden>
          <path d="M19 46V18M45 18v28M20 19l24 26" stroke="currentColor" strokeWidth="5" strokeLinecap="round" fill="none" />
        </svg>
        <div className="relative flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <Monogram size={34} />
            <span className="text-[14px] font-semibold tracking-[-0.01em]">
              MGIMO <span className="text-primary dark:text-cyan">NEXT</span>
            </span>
          </div>
          <span className="rounded-md border border-current/20 px-2 py-0.5 text-[11px] font-bold tracking-[0.08em] text-primary dark:text-cyan">DEMO</span>
        </div>
        <div className="relative mt-8">
          <p className="text-[13px] opacity-60">{student ? "Студент" : user.position}</p>
          <p className="mt-0.5 text-[22px] font-semibold leading-tight tracking-[-0.025em] sm:text-[26px]">{user.fullName}</p>
        </div>
        <dl className="relative mt-5 grid grid-cols-2 gap-x-4 gap-y-3 text-[13px] sm:grid-cols-4">
          {(student
            ? [
                ["Факультет", user.faculty.replace("Факультет ", "")],
                ["Направление", user.program],
                ["Курс и группа", `${user.course} курс, ${user.group}`],
                ["Учебный год", user.studyYear],
              ]
            : [
                ["Подразделение", user.faculty],
                ["Роль", "Обработка обращений"],
                ["Учебный год", user.studyYear],
              ]
          ).map(([k, v]) => (
            <div key={k} className="min-w-0">
              <dt className="opacity-55">{k}</dt>
              <dd className="mt-0.5 font-semibold leading-snug">{v}</dd>
            </div>
          ))}
        </dl>
        {student && <p className="relative mt-5 text-[11.5px] opacity-50">ID {user.studentCode} · карточка приложения, не является удостоверением</p>}
      </section>

      {academic && (
        <section className="mt-4 grid grid-cols-4 gap-2 text-center">
          {[
            ["Средний балл", academic.average?.toFixed(1) ?? "—"],
            ["Закрыто", String(academic.closed)],
            ["Дисциплин", String(academic.courses)],
            ["З. е. в семестре", String(academic.credits)],
          ].map(([l, v]) => (
            <div key={l} className="rounded-2xl border border-line bg-surface px-1 py-3">
              <p className="tnum text-[19px] font-semibold tracking-[-0.02em]">{v}</p>
              <p className="mt-0.5 text-[11.5px] leading-tight text-ink-3">{l}</p>
            </div>
          ))}
        </section>
      )}

      {student && (
        <section className="mt-8">
          <SectionTitle>Кампус и мероприятия</SectionTitle>
          <ul className="overflow-hidden rounded-[20px] border border-line bg-surface">
            {events.map((e, i) => (
              <li key={e.id} className={`flex gap-3 px-4 py-3 ${i ? "border-t border-line" : ""}`}>
                <span className="flex h-12 w-12 shrink-0 flex-col items-center justify-center self-start rounded-xl bg-surface-2">
                  <span className="tnum text-[16px] font-semibold leading-none">{Number(e.date.slice(8))}</span>
                  <span className="mt-0.5 text-[10.5px] text-ink-3">{relDay(e.date, today).split(",")[0]}</span>
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-[14px] font-semibold leading-snug">{e.title}</span>
                  <span className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[12.5px] text-ink-3">
                    <span className="inline-flex items-center gap-1">
                      <CalendarDays size={12} /> {e.time}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <MapPin size={12} /> {e.place}
                    </span>
                  </span>
                </span>
                <span className="h-fit shrink-0 rounded-md bg-primary-soft px-1.5 py-0.5 text-[11.5px] font-semibold text-primary-soft-ink">{e.tag}</span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="mt-8">
        <SectionTitle>Оформление</SectionTitle>
        <div className="grid grid-cols-3 gap-1.5 rounded-2xl border border-line bg-surface p-1.5" role="radiogroup" aria-label="Тема">
          {([
            ["light", "Светлая", Sun],
            ["dark", "Тёмная", Moon],
            ["system", "Как в системе", Monitor],
          ] as const).map(([k, l, Icon]) => (
            <button
              key={k}
              role="radio"
              aria-checked={theme === k}
              onClick={() => applyTheme(k)}
              className={`press flex h-16 flex-col items-center justify-center gap-1 rounded-xl text-[12.5px] font-semibold ${theme === k ? "bg-primary-soft text-primary-soft-ink" : "text-ink-3 hover:bg-surface-2"}`}
            >
              <Icon size={18} /> {l}
            </button>
          ))}
        </div>
      </section>

      <section className="mt-8">
        <SectionTitle>Уведомления</SectionTitle>
        <ul className="overflow-hidden rounded-[20px] border border-line bg-surface">
          {[
            ["requests", "Статусы обращений", "Приходят всегда"],
            ...(student
              ? [
                  ["schedule", "Изменения расписания", "Переносы, замены, отмены"],
                  ["grades", "Новые оценки", "Когда преподаватель выставил балл"],
                  ["digest", "Утренняя сводка", "Пары и дедлайны дня в 8:00"],
                ]
              : []),
          ].map(([k, l, hint], i) => (
            <li key={k} className={i ? "border-t border-line" : ""}>
              <button onClick={() => toggle(k)} role="switch" aria-checked={!!prefs[k]} disabled={k === "requests"} className="press flex w-full items-center gap-3 px-4 py-3 text-left disabled:cursor-default">
                <Bell size={17} className="shrink-0 text-ink-3" />
                <span className="min-w-0 flex-1">
                  <span className="block text-[14.5px] font-medium">{l}</span>
                  <span className="block text-[12.5px] text-ink-3">{hint}</span>
                </span>
                <span className={`relative h-7 w-12 shrink-0 rounded-full transition-colors ${prefs[k] ? "bg-primary" : "bg-line-strong"} ${k === "requests" ? "opacity-60" : ""}`}>
                  <span className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow transition-[left] ${prefs[k] ? "left-[22px]" : "left-0.5"}`} />
                </span>
              </button>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-8 space-y-3">
        <button onClick={logout} disabled={leaving} className="press flex h-12 w-full items-center justify-center gap-2 rounded-2xl border border-line bg-surface text-[15px] font-semibold text-red hover:bg-red-soft">
          {leaving ? <Loader2 size={18} className="animate-spin" /> : <LogOut size={18} />} Выйти из аккаунта
        </button>
        <div className="flex gap-2.5 rounded-2xl bg-surface-2 px-4 py-3">
          <Info size={16} className="mt-0.5 shrink-0 text-ink-3" />
          <Disclaimer className="!text-[12.5px]" />
        </div>
      </section>
    </div>
  );
}
