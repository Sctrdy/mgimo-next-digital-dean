import { CheckCircle2, Circle, CircleDot, Download, FileText, MessageSquareText, Sparkles, XCircle } from "lucide-react";
import type { DeanRequest, RequestStatus } from "@/lib/types";
import { DELIVERY_LABEL, LANGUAGE_LABEL, STATUS_LABEL } from "@/lib/types";
import { StatusBadge } from "@/components/ui/kit";
import { formatTimestamp } from "@/lib/time";

const FLOW: RequestStatus[] = ["submitted", "in_progress", "ready", "issued"];

export function RequestHeader({ r }: { r: DeanRequest }) {
  return (
    <div>
      <div className="flex flex-wrap items-center gap-2">
        <StatusBadge status={r.status} />
        <span className="tnum text-[13px] text-ink-3">{r.number}</span>
        {r.source === "ai" && (
          <span className="inline-flex items-center gap-1 rounded-full bg-violet-soft px-2 py-0.5 text-[12px] font-semibold text-violet-ink">
            <Sparkles size={12} /> через NEXT AI
          </span>
        )}
      </div>
      <h1 className="mt-2 text-[24px] font-semibold leading-tight tracking-[-0.025em]">{r.title}</h1>
      <p className="mt-1 text-[14px] text-ink-3">Подана {formatTimestamp(r.createdAt)}</p>
    </div>
  );
}

/** Шкала статусов: где заявка сейчас. */
export function StatusTrack({ status }: { status: RequestStatus }) {
  if (status === "rejected") {
    return (
      <div className="flex items-center gap-2 rounded-2xl bg-red-soft px-4 py-3 text-[14px] font-medium text-red">
        <XCircle size={18} /> Обращение отклонено. Причина — в истории ниже.
      </div>
    );
  }
  const idx = FLOW.indexOf(status);
  return (
    <ol className="grid grid-cols-4 gap-1.5" aria-label="Этапы обработки">
      {FLOW.map((s, i) => (
        <li key={s}>
          <div className={`h-1.5 rounded-full ${i <= idx ? (status === "ready" && i === idx ? "bg-green" : "bg-primary") : "bg-line"}`} />
          <p className={`mt-1.5 text-[12px] leading-tight ${i === idx ? "font-semibold text-ink" : i < idx ? "text-ink-2" : "text-ink-3"}`}>{STATUS_LABEL[s]}</p>
        </li>
      ))}
    </ol>
  );
}

export function RequestFields({ r }: { r: DeanRequest }) {
  const rows: [string, string | null][] = [
    ["Назначение", r.purpose],
    ["Страна", r.country],
    ["Язык", LANGUAGE_LABEL[r.language]],
    ["Формат", DELIVERY_LABEL[r.delivery]],
    ["Экземпляров", r.delivery === "paper" ? String(r.copies) : null],
    ["Комментарий", r.comment],
    ["Срок", `до ${r.etaDays} рабочих дней`],
  ];
  return (
    <dl className="divide-y divide-line overflow-hidden rounded-[20px] border border-line bg-surface">
      {rows
        .filter(([, v]) => v)
        .map(([k, v]) => (
          <div key={k} className="grid grid-cols-[120px_1fr] gap-3 px-4 py-3 text-[14px]">
            <dt className="text-ink-3">{k}</dt>
            <dd className="font-medium">{v}</dd>
          </div>
        ))}
    </dl>
  );
}

export function RequestHistory({ r }: { r: DeanRequest }) {
  const ev = [...(r.events ?? [])].reverse();
  return (
    <ol className="relative">
      {ev.map((e, i) => {
        const Icon = e.status === "ready" || e.status === "issued" ? CheckCircle2 : e.status === "rejected" ? XCircle : e.status ? CircleDot : MessageSquareText;
        return (
          <li key={e.id} className="relative flex gap-3 pb-4 last:pb-0">
            {i < ev.length - 1 && <span className="absolute left-[13px] top-7 bottom-0 w-px bg-line" />}
            <span className={`relative flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${i === 0 ? "bg-primary-soft text-primary-soft-ink" : "bg-surface-2 text-ink-3"}`}>
              <Icon size={15} />
            </span>
            <div className="min-w-0 flex-1 pt-0.5">
              <p className="text-[14px] font-semibold">{e.status ? STATUS_LABEL[e.status] : "Комментарий"}</p>
              <p className="tnum text-[12.5px] text-ink-3">
                {formatTimestamp(e.at)}, {e.actor}
              </p>
              {e.comment && <p className="mt-1.5 rounded-xl bg-surface-2 px-3 py-2 text-[13.5px] leading-snug text-ink-2">{e.comment}</p>}
            </div>
          </li>
        );
      })}
      {ev.length === 0 && (
        <li className="flex items-center gap-2 text-[13px] text-ink-3">
          <Circle size={14} /> История пока пуста
        </li>
      )}
    </ol>
  );
}

export function DocumentLink({ r }: { r: DeanRequest }) {
  if (r.status !== "ready" && r.status !== "issued") return null;
  if (r.delivery === "paper") {
    return (
      <div className="flex items-center gap-3 rounded-2xl bg-green-soft px-4 py-3 text-green">
        <FileText size={20} className="shrink-0" />
        <p className="text-[14px] font-medium">{r.status === "ready" ? "Оригинал готов: заберите его в деканате, окно № 3, с паспортом." : "Документ выдан."}</p>
      </div>
    );
  }
  return (
    <a href={`/api/requests/${r.id}/document`} target="_blank" className="press flex items-center gap-3 rounded-2xl bg-green-soft px-4 py-3 text-green">
      <Download size={20} className="shrink-0" />
      <span className="min-w-0 flex-1">
        <span className="block text-[14.5px] font-semibold">Открыть документ</span>
        <span className="block text-[12.5px] opacity-80">Демо-версия документа с пометкой DEMO</span>
      </span>
    </a>
  );
}
