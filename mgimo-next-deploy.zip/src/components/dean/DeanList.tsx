"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import { FilePlus2, Search, Inbox, ChevronRight, Sparkles, X } from "lucide-react";
import type { DeanRequest, RequestType } from "@/lib/types";
import { ButtonLink, PageHeader, StatusBadge, Empty, SectionTitle } from "@/components/ui/kit";
import { formatTimestamp } from "@/lib/time";

const FILTERS = [
  { key: "all", label: "Все" },
  { key: "work", label: "В работе" },
  { key: "ready", label: "Готовы" },
  { key: "done", label: "Архив" },
] as const;

export function DeanList({ requests, popular, initialFilter }: { requests: DeanRequest[]; popular: RequestType[]; initialFilter: string }) {
  const [filter, setFilter] = useState(FILTERS.some((f) => f.key === initialFilter) ? initialFilter : "all");
  const [q, setQ] = useState("");
  const count = (k: string) => requests.filter((r) => match(r, k)).length;
  const list = useMemo(
    () =>
      requests.filter((r) => match(r, filter)).filter((r) => {
        const s = q.trim().toLowerCase();
        return !s || [r.number, r.title, r.purpose].some((x) => x.toLowerCase().includes(s));
      }),
    [requests, filter, q],
  );

  return (
    <div className="lg:grid lg:grid-cols-[minmax(0,1fr)_340px] lg:gap-8">
      <div className="min-w-0">
        <PageHeader
          title="Деканат"
          subtitle="Справки, выписки и заявления онлайн"
          action={
            <span className="hidden sm:block">
              <ButtonLink href="/dean/new">
                <FilePlus2 size={17} /> Новое обращение
              </ButtonLink>
            </span>
          }
        />
        <ButtonLink href="/dean/new" size="lg" className="mb-5 w-full sm:hidden">
          <FilePlus2 size={18} /> Новое обращение
        </ButtonLink>

        <div className="no-scrollbar -mx-4 flex gap-1.5 overflow-x-auto px-4 pb-1" role="tablist" aria-label="Фильтр заявок">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              role="tab"
              aria-selected={filter === f.key}
              onClick={() => setFilter(f.key)}
              className={`press flex h-9 shrink-0 items-center gap-1.5 rounded-full px-3.5 text-[13.5px] font-semibold ${filter === f.key ? "bg-navy text-white dark:bg-primary" : "border border-line bg-surface text-ink-2"}`}
            >
              {f.label}
              <span className={`tnum text-[12px] ${filter === f.key ? "text-white/70" : "text-ink-3"}`}>{count(f.key)}</span>
            </button>
          ))}
        </div>

        <label className="mt-3 flex h-11 items-center gap-2.5 rounded-xl border border-line bg-surface px-3.5 focus-within:border-primary">
          <Search size={17} className="text-ink-3" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск по номеру или названию" className="h-full min-w-0 flex-1 bg-transparent text-[15px] outline-none placeholder:text-ink-3" />
          {q && (
            <button onClick={() => setQ("")} aria-label="Очистить поиск" className="text-ink-3">
              <X size={16} />
            </button>
          )}
        </label>

        <div className="mt-3 overflow-hidden rounded-[20px] border border-line bg-surface">
          {list.length === 0 ? (
            <Empty
              icon={<Inbox size={22} />}
              title={q ? "Ничего не найдено" : "Здесь пока пусто"}
              text={q ? "Попробуйте другой номер или название документа." : "Подайте обращение — статус будет обновляться здесь и в уведомлениях."}
            />
          ) : (
            <ul>
              {list.map((r, i) => (
                <li key={r.id} className={i ? "border-t border-line" : ""}>
                  <Link href={`/dean/${r.id}`} className="press flex items-center gap-3 px-4 py-3.5 hover:bg-surface-2/60">
                    <span className="min-w-0 flex-1">
                      <span className="flex items-center gap-2">
                        <span className="truncate text-[15px] font-semibold">{r.title}</span>
                        {r.source === "ai" && <Sparkles size={14} className="shrink-0 text-violet" aria-label="Создано через NEXT AI" />}
                      </span>
                      <span className="tnum mt-0.5 block truncate text-[12.5px] text-ink-3">
                        {r.number} · {formatTimestamp(r.createdAt)} · {r.purpose}
                      </span>
                    </span>
                    <StatusBadge status={r.status} />
                    <ChevronRight size={17} className="hidden shrink-0 text-ink-3 sm:block" />
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <aside className="mt-8 lg:mt-0">
        <SectionTitle>Часто заказывают</SectionTitle>
        <ul className="grid grid-cols-2 gap-2 lg:grid-cols-1">
          {popular.map((t) => (
            <li key={t.code}>
              <Link href={`/dean/new?type=${t.code}`} className="press flex h-full flex-col rounded-2xl border border-line bg-surface p-3.5 hover:border-line-strong">
                <span className="text-[14px] font-semibold leading-snug">{t.title}</span>
                <span className="mt-1 text-[12.5px] text-ink-3">до {t.etaDays} раб. дн.</span>
              </Link>
            </li>
          ))}
        </ul>
        <Link href={`/assistant?q=${encodeURIComponent("Какую справку мне заказать?")}`} className="press mt-3 flex items-center gap-3 rounded-2xl bg-violet-soft p-3.5 text-violet-ink">
          <Sparkles size={18} className="shrink-0" />
          <span className="text-[13.5px] leading-snug">
            <span className="font-semibold">Не знаете, какой документ нужен?</span> Опишите ситуацию NEXT AI — он подготовит заявку.
          </span>
        </Link>
      </aside>
    </div>
  );
}

function match(r: DeanRequest, k: string) {
  if (k === "work") return r.status === "submitted" || r.status === "in_progress";
  if (k === "ready") return r.status === "ready";
  if (k === "done") return r.status === "issued" || r.status === "rejected";
  return true;
}
