"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Check, ChevronRight, Loader2, ShieldCheck } from "lucide-react";
import type { Delivery, DraftPreview, Language, RequestInput, RequestType } from "@/lib/types";
import { DELIVERY_LABEL, LANGUAGE_LABEL } from "@/lib/types";
import { Button } from "@/components/ui/kit";
import { RequestPreview } from "./RequestPreview";

const PURPOSES: Record<string, string[]> = {
  study_certificate: ["По месту требования", "Для банка", "По месту работы родителей", "Для получения налогового вычета"],
  visa_certificate: ["Для туристической визы", "Для учебной визы", "Для поездки на конференцию"],
  transcript: ["Для программы обмена", "Для стажировки", "Для поступления в магистратуру"],
  military: ["Для предоставления в военкомат"],
  social_fund: ["Для назначения выплат", "Для продления выплат"],
  curriculum: ["Для летней школы", "Для перезачёта дисциплин"],
  retake: ["Пересдача академической задолженности"],
  individual_plan: ["Совмещение со стажировкой", "Спортивные сборы", "Семейные обстоятельства"],
};

const STEPS = ["Документ", "Данные", "Проверка"];

export function NewRequestForm({
  types, initialType, profile, prefill = {},
}: { types: RequestType[]; initialType: string | null; profile: DraftPreview["profile"]; prefill?: Partial<Omit<RequestInput, "typeCode" | "copies">> }) {
  const router = useRouter();
  const [step, setStep] = useState(initialType ? 1 : 0);
  const [typeCode, setTypeCode] = useState(initialType ?? "");
  const type = types.find((t) => t.code === typeCode) ?? null;
  const [input, setInput] = useState<Omit<RequestInput, "typeCode">>(() => ({
    purpose: prefill.purpose ?? (initialType ? PURPOSES[initialType]?.[0] ?? "" : ""),
    copies: 1,
    language: prefill.language ?? type?.defaultLanguage ?? "ru",
    delivery: prefill.delivery ?? "electronic",
    country: prefill.country ?? "",
    comment: prefill.comment ?? "",
  }));
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const set = <K extends keyof typeof input>(k: K, v: (typeof input)[K]) => setInput((s) => ({ ...s, [k]: v }));

  const choose = (t: RequestType) => {
    setTypeCode(t.code);
    setInput((s) => ({ ...s, language: t.defaultLanguage, purpose: PURPOSES[t.code]?.[0] ?? "" }));
    setStep(1);
  };

  const detailsError = !type
    ? "Выберите документ"
    : input.purpose.trim().length < 3
      ? "Укажите, для чего нужен документ"
      : type.needsCountry && !input.country?.trim()
        ? "Укажите страну назначения"
        : null;

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await fetch("/api/requests", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ ...input, typeCode }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "Не удалось отправить обращение");
      router.push(`/dean/${d.request.id}?created=1`);
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Не удалось отправить. Проверьте соединение и попробуйте снова.");
      setBusy(false);
    }
  };

  const field = "h-12 w-full rounded-xl border border-line-strong bg-surface px-3.5 text-[16px] outline-none focus:border-primary";

  return (
    <div className="mx-auto max-w-2xl">
      <div className="mb-4 flex items-center gap-2">
        <button
          onClick={() => (step === 0 ? router.push("/dean") : setStep(step - 1))}
          className="press -ml-2 flex h-10 w-10 items-center justify-center rounded-full text-ink-2 hover:bg-surface-2"
          aria-label="Назад"
        >
          <ArrowLeft size={20} />
        </button>
        <h1 className="text-[22px] font-semibold tracking-[-0.025em]">Новое обращение</h1>
      </div>

      <ol className="mb-5 grid grid-cols-3 gap-2" aria-label="Шаги">
        {STEPS.map((s, i) => (
          <li key={s} aria-current={i === step ? "step" : undefined}>
            <div className={`h-1 rounded-full ${i <= step ? "bg-primary" : "bg-line"}`} />
            <p className={`mt-1.5 text-[12.5px] ${i === step ? "font-semibold text-ink" : "text-ink-3"}`}>
              {i + 1}. {s}
            </p>
          </li>
        ))}
      </ol>

      {step === 0 && (
        <ul className="overflow-hidden rounded-[20px] border border-line bg-surface">
          {types.map((t, i) => (
            <li key={t.code} className={i ? "border-t border-line" : ""}>
              <button onClick={() => choose(t)} className="press flex w-full items-center gap-3 px-4 py-3.5 text-left hover:bg-surface-2/60">
                <span className="min-w-0 flex-1">
                  <span className="block text-[15px] font-semibold">{t.title}</span>
                  <span className="mt-0.5 block text-[13px] leading-snug text-ink-3">{t.description}</span>
                </span>
                <span className="shrink-0 text-[12px] text-ink-3">до {t.etaDays} дн.</span>
                <ChevronRight size={17} className="shrink-0 text-ink-3" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {step === 1 && type && (
        <div className="space-y-4">
          <div className="rounded-2xl bg-primary-soft px-4 py-3">
            <p className="text-[15px] font-semibold text-primary-soft-ink">{type.title}</p>
            <p className="mt-0.5 text-[13px] text-ink-2">{type.description}</p>
          </div>

          <fieldset>
            <legend className="mb-1.5 text-[13px] font-medium text-ink-2">Для чего нужен документ</legend>
            <div className="mb-2 flex flex-wrap gap-1.5">
              {(PURPOSES[type.code] ?? []).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => set("purpose", p)}
                  className={`press h-8 rounded-full px-3 text-[13px] ${input.purpose === p ? "bg-navy font-semibold text-white dark:bg-primary" : "border border-line bg-surface text-ink-2"}`}
                >
                  {p}
                </button>
              ))}
            </div>
            <input value={input.purpose} onChange={(e) => set("purpose", e.target.value)} className={field} maxLength={200} placeholder="Своими словами" />
          </fieldset>

          {type.needsCountry && (
            <label className="block">
              <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Страна назначения</span>
              <input value={input.country ?? ""} onChange={(e) => set("country", e.target.value)} className={field} placeholder="Например, Италия" maxLength={60} />
            </label>
          )}

          <fieldset>
            <legend className="mb-1.5 text-[13px] font-medium text-ink-2">Язык документа</legend>
            <div className="grid grid-cols-3 gap-1.5 rounded-xl bg-surface-2 p-1">
              {(Object.keys(LANGUAGE_LABEL) as Language[]).map((l) => (
                <button key={l} type="button" onClick={() => set("language", l)} className={`press h-10 rounded-lg text-[13px] font-semibold ${input.language === l ? "bg-surface shadow-soft" : "text-ink-3"}`}>
                  {l === "ru+en" ? "RU + EN" : LANGUAGE_LABEL[l]}
                </button>
              ))}
            </div>
          </fieldset>

          <fieldset>
            <legend className="mb-1.5 text-[13px] font-medium text-ink-2">Формат</legend>
            <div className="grid gap-2 sm:grid-cols-2">
              {(Object.keys(DELIVERY_LABEL) as Delivery[]).map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => set("delivery", d)}
                  className={`press flex items-center gap-3 rounded-xl border px-3.5 py-3 text-left ${input.delivery === d ? "border-primary bg-primary-soft/50" : "border-line bg-surface"}`}
                >
                  <span className={`flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 ${input.delivery === d ? "border-primary bg-primary text-white" : "border-line-strong"}`}>
                    {input.delivery === d && <Check size={12} strokeWidth={3} />}
                  </span>
                  <span>
                    <span className="block text-[14px] font-semibold">{d === "electronic" ? "Электронно" : "Бумажный оригинал"}</span>
                    <span className="block text-[12.5px] text-ink-3">{d === "electronic" ? "PDF с электронной подписью в заявке" : "Забрать в деканате"}</span>
                  </span>
                </button>
              ))}
            </div>
          </fieldset>

          {input.delivery === "paper" && (
            <label className="block">
              <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Количество экземпляров</span>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} type="button" onClick={() => set("copies", n)} className={`press h-11 w-11 rounded-xl text-[15px] font-semibold ${input.copies === n ? "bg-navy text-white dark:bg-primary" : "border border-line bg-surface"}`}>
                    {n}
                  </button>
                ))}
              </div>
            </label>
          )}

          <label className="block">
            <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Комментарий для деканата (необязательно)</span>
            <textarea
              value={input.comment ?? ""}
              onChange={(e) => set("comment", e.target.value)}
              rows={3}
              maxLength={500}
              className="w-full rounded-xl border border-line-strong bg-surface px-3.5 py-3 text-[16px] outline-none focus:border-primary"
            />
          </label>

          {detailsError && <p className="text-[13px] text-ink-3">{detailsError}</p>}
          <Button size="lg" className="w-full" disabled={!!detailsError} onClick={() => setStep(2)}>
            Проверить данные
          </Button>
        </div>
      )}

      {step === 2 && type && (
        <div className="space-y-4">
          <RequestPreview d={{ type: { code: type.code, title: type.title, etaDays: type.etaDays }, input: { ...input, typeCode }, profile }} />
          <p className="flex gap-2 text-[12.5px] leading-snug text-ink-3">
            <ShieldCheck size={16} className="shrink-0 text-green" />
            Обращение увидят только вы и сотрудники деканата. Данные других студентов недоступны.
          </p>
          {error && (
            <p role="alert" className="rounded-xl bg-red-soft px-3.5 py-2.5 text-[13.5px] text-red">
              {error}
            </p>
          )}
          <div className="grid gap-2 sm:grid-cols-2">
            <Button variant="secondary" size="lg" onClick={() => setStep(1)} disabled={busy}>
              Изменить
            </Button>
            <Button size="lg" onClick={submit} disabled={busy}>
              {busy && <Loader2 size={18} className="animate-spin" />} Отправить в деканат
            </Button>
          </div>
        </div>
      )}

      {step === 0 && (
        <p className="mt-4 text-center text-[13px] text-ink-3">
          Не нашли нужный документ? <Link href="/assistant" className="font-semibold text-violet-ink">Спросите NEXT AI</Link>
        </p>
      )}
    </div>
  );
}
