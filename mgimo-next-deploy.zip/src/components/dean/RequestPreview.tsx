import type { DraftPreview } from "@/lib/types";
import { DELIVERY_LABEL, LANGUAGE_LABEL } from "@/lib/types";

/** Предпросмотр заявки: какие данные уйдут в деканат. Используется формой и NEXT AI. */
export function RequestPreview({ d }: { d: Omit<DraftPreview, "draftId" | "status"> }) {
  const rows: [string, string | null | undefined][] = [
    ["Документ", d.type.title],
    ["Назначение", d.input.purpose],
    ["Страна", d.input.country],
    ["Язык", LANGUAGE_LABEL[d.input.language]],
    ["Формат", DELIVERY_LABEL[d.input.delivery]],
    ["Экземпляров", String(d.input.copies)],
    ["Комментарий", d.input.comment],
  ];
  const profile: [string, string | null][] = [
    ["ФИО", d.profile.fullName],
    ["Факультет", d.profile.faculty],
    ["Направление", d.profile.program],
    ["Курс, группа", `${d.profile.course ?? "—"} курс, ${d.profile.group ?? "—"}`],
    ["Учебный год", d.profile.studyYear],
  ];
  return (
    <div className="overflow-hidden rounded-2xl border border-line bg-surface">
      <dl className="divide-y divide-line">
        {rows
          .filter(([, v]) => v)
          .map(([k, v]) => (
            <div key={k} className="grid grid-cols-[110px_1fr] gap-3 px-3.5 py-2.5 text-[13.5px]">
              <dt className="text-ink-3">{k}</dt>
              <dd className="font-medium">{v}</dd>
            </div>
          ))}
      </dl>
      <div className="border-t border-line bg-surface-2/60 px-3.5 py-2.5">
        <p className="mb-1.5 text-[12px] font-medium text-ink-3">Из профиля подставятся только эти данные</p>
        <dl className="space-y-1">
          {profile.map(([k, v]) => (
            <div key={k} className="grid grid-cols-[110px_1fr] gap-3 text-[12.5px]">
              <dt className="text-ink-3">{k}</dt>
              <dd className="text-ink-2">{v}</dd>
            </div>
          ))}
        </dl>
      </div>
      <p className="border-t border-line px-3.5 py-2 text-[12px] text-ink-3">Срок подготовки — до {d.type.etaDays} рабочих дней.</p>
    </div>
  );
}
