"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { BellRing, CheckCircle2, Loader2 } from "lucide-react";
import type { RequestStatus } from "@/lib/types";
import { STATUS_LABEL } from "@/lib/types";
import { Button } from "@/components/ui/kit";

const ACTION_LABEL: Record<RequestStatus, string> = {
  submitted: "Принять",
  in_progress: "Взять в работу",
  ready: "Документ готов",
  issued: "Отметить выданным",
  rejected: "Отклонить",
};

const TEMPLATES: Partial<Record<RequestStatus, string>> = {
  in_progress: "Заявка принята в работу.",
  ready: "Документ готов и подписан электронной подписью.",
  issued: "Выдано лично.",
  rejected: "Не хватает данных: уточните, пожалуйста, назначение документа и подайте заявку повторно.",
};

export function StaffActions({ id, status, next, studentName }: { id: number; status: RequestStatus; next: RequestStatus[]; studentName: string }) {
  const router = useRouter();
  const [target, setTarget] = useState<RequestStatus | null>(next.find((s) => s !== "rejected") ?? null);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);

  const save = async (withStatus: boolean) => {
    setBusy(true);
    setError(null);
    setDone(null);
    const r = await fetch(`/api/staff/requests/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ status: withStatus ? target : null, comment: comment.trim() || null }),
    });
    const d = await r.json().catch(() => ({}));
    setBusy(false);
    if (!r.ok) {
      setError(d.error ?? "Не удалось сохранить изменения");
      return;
    }
    setDone(withStatus && target ? `Статус «${STATUS_LABEL[target]}» сохранён` : "Комментарий отправлен");
    setComment("");
    router.refresh();
  };

  return (
    <section className="rounded-[20px] border border-line bg-surface p-4">
      <h2 className="text-[16px] font-semibold tracking-[-0.015em]">Обработка</h2>
      {next.length === 0 ? (
        <p className="mt-2 text-[13.5px] text-ink-3">Обращение закрыто. Можно оставить комментарий для студента.</p>
      ) : (
        <>
          <p className="mt-1 text-[13px] text-ink-3">Текущий статус: {STATUS_LABEL[status]}. Следующий шаг:</p>
          <div className="mt-3 grid gap-2">
            {next.map((s) => (
              <button
                key={s}
                onClick={() => {
                  setTarget(s);
                  if (!comment && TEMPLATES[s]) setComment(TEMPLATES[s]!);
                }}
                className={`press flex h-11 items-center gap-2.5 rounded-xl border px-3.5 text-left text-[14px] font-semibold ${
                  target === s ? (s === "rejected" ? "border-red bg-red-soft text-red" : "border-primary bg-primary-soft text-primary-soft-ink") : "border-line text-ink-2"
                }`}
              >
                <span className={`h-4 w-4 rounded-full border-2 ${target === s ? (s === "rejected" ? "border-red bg-red" : "border-primary bg-primary") : "border-line-strong"}`} />
                {ACTION_LABEL[s]}
              </button>
            ))}
          </div>
        </>
      )}
      <label className="mt-4 block">
        <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Комментарий для студента{target === "rejected" ? " (обязательно)" : ""}</span>
        <textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          rows={4}
          maxLength={800}
          className="w-full rounded-xl border border-line-strong bg-surface px-3.5 py-3 text-[15px] outline-none focus:border-primary"
          placeholder="Например: справка готова, PDF во вложении"
        />
      </label>
      {error && <p className="mt-2 rounded-xl bg-red-soft px-3 py-2 text-[13px] text-red">{error}</p>}
      {done && (
        <p className="mt-2 flex items-center gap-2 rounded-xl bg-green-soft px-3 py-2 text-[13px] font-medium text-green">
          <CheckCircle2 size={15} /> {done}. {studentName.split(" ")[1]} получит уведомление.
        </p>
      )}
      <div className="mt-3 grid gap-2">
        {next.length > 0 && target && (
          <Button size="lg" variant={target === "rejected" ? "danger" : "primary"} onClick={() => save(true)} disabled={busy || (target === "rejected" && !comment.trim())}>
            {busy ? <Loader2 size={17} className="animate-spin" /> : <BellRing size={17} />}
            {ACTION_LABEL[target]} и уведомить
          </Button>
        )}
        <Button variant="secondary" onClick={() => save(false)} disabled={busy || !comment.trim()}>
          Только комментарий
        </Button>
      </div>
    </section>
  );
}
