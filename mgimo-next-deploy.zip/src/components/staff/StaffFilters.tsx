"use client";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Search } from "lucide-react";

const TABS = [
  ["active", "Активные"],
  ["submitted", "Новые"],
  ["in_progress", "В работе"],
  ["ready", "Готовы"],
  ["issued", "Выданы"],
  ["rejected", "Отклонены"],
  ["all", "Все"],
] as const;

export function StaffFilters({ status, q }: { status: string; q: string }) {
  const router = useRouter();
  const [text, setText] = useState(q);
  useEffect(() => {
    if (text === q) return;
    const t = setTimeout(() => router.replace(`/staff?status=${status}${text ? `&q=${encodeURIComponent(text)}` : ""}`), 250);
    return () => clearTimeout(t);
  }, [text, q, status, router]);
  return (
    <div className="mt-5 space-y-3">
      <div className="no-scrollbar -mx-4 flex gap-1.5 overflow-x-auto px-4 lg:mx-0 lg:px-0">
        {TABS.map(([k, l]) => (
          <button
            key={k}
            onClick={() => router.replace(`/staff?status=${k}${text ? `&q=${encodeURIComponent(text)}` : ""}`)}
            className={`press h-9 shrink-0 rounded-full px-3.5 text-[13.5px] font-semibold ${status === k ? "bg-navy text-white dark:bg-primary" : "border border-line bg-surface text-ink-2"}`}
          >
            {l}
          </button>
        ))}
      </div>
      <label className="flex h-11 items-center gap-2.5 rounded-xl border border-line bg-surface px-3.5 focus-within:border-primary">
        <Search size={17} className="text-ink-3" />
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Номер, ФИО, группа или документ" className="h-full min-w-0 flex-1 bg-transparent text-[15px] outline-none placeholder:text-ink-3" />
      </label>
    </div>
  );
}
