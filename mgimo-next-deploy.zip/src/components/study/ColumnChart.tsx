"use client";
import { useState } from "react";

type Datum = { label: string; value: number; tip: string; current?: boolean };

/**
 * Столбчатая диаграмма одного ряда: тонкие столбцы от базовой линии, скругление 4px сверху,
 * приглушённая сетка, подсказка по наведению/фокусу, подпись только у выделенного значения.
 */
export function ColumnChart({ data, min = 0, max, format, highlightLast = false }: { data: Datum[]; min?: number; max?: number; format: (v: number) => string; highlightLast?: boolean }) {
  const [hover, setHover] = useState<number | null>(null);
  const top = max ?? Math.max(1, ...data.map((d) => d.value)) * 1.15;
  const span = top - min || 1;
  const ticks = [min, min + span / 2, top].map((v) => Math.round(v * 10) / 10);
  const H = 132;
  const emphasis = highlightLast ? data.length - 1 : data.findIndex((d) => d.current);

  return (
    <figure>
      <div className="relative" style={{ height: H + 22 }}>
        {/* сетка */}
        {ticks.map((t) => (
          <div key={t} className="absolute inset-x-0 flex items-center gap-2" style={{ bottom: 22 + ((t - min) / span) * H - 6 }}>
            <span className="tnum w-7 shrink-0 text-right text-[10.5px] text-ink-3">{Number.isInteger(t) ? t : t.toFixed(1)}</span>
            <span className={`h-px flex-1 ${t === min ? "bg-line-strong" : "bg-line"}`} />
          </div>
        ))}
        {/* столбцы */}
        <div className="absolute bottom-[22px] left-9 right-0 flex items-end justify-around gap-1.5" style={{ height: H }} onMouseLeave={() => setHover(null)}>
          {data.map((d, i) => {
            const h = Math.max(d.value > min ? 3 : 0, ((Math.max(d.value, min) - min) / span) * H);
            const on = hover === i;
            const hi = i === emphasis;
            return (
              <button
                key={i}
                type="button"
                className="group relative flex h-full flex-1 items-end justify-center outline-none"
                onMouseEnter={() => setHover(i)}
                onFocus={() => setHover(i)}
                onBlur={() => setHover(null)}
                onClick={() => setHover(on ? null : i)}
                aria-label={d.tip}
              >
                <span
                  className={`block w-full max-w-[28px] rounded-t-[4px] transition-colors ${hi ? "bg-primary" : on ? "bg-primary/70" : "bg-primary/35 dark:bg-primary/45"}`}
                  style={{ height: h }}
                />
                {hi && !on && d.value > 0 && (
                  <span className="tnum absolute left-1/2 -translate-x-1/2 text-[11.5px] font-semibold text-ink" style={{ bottom: h + 4 }}>
                    {format(d.value)}
                  </span>
                )}
                {on && (
                  <span
                    className="pointer-events-none absolute left-1/2 z-10 -translate-x-1/2 whitespace-nowrap rounded-lg bg-navy px-2 py-1 text-[11.5px] font-medium text-white shadow-float dark:bg-surface-3"
                    style={{ bottom: h + 6 }}
                  >
                    {d.tip}
                  </span>
                )}
              </button>
            );
          })}
        </div>
        <div className="absolute bottom-0 left-9 right-0 flex justify-around gap-1.5">
          {data.map((d, i) => (
            <span key={i} className={`flex-1 truncate text-center text-[11px] ${d.current || i === emphasis ? "font-semibold text-ink" : "text-ink-3"}`}>
              {d.label}
            </span>
          ))}
        </div>
      </div>
      <figcaption className="sr-only">
        {data.map((d) => d.tip).join("; ")}
      </figcaption>
    </figure>
  );
}
