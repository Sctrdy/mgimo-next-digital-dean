"use client";
import Link from "next/link";
import { useState } from "react";
import { AlertTriangle, CheckCircle2, ChevronRight, FlagTriangleRight, Sparkles } from "lucide-react";
import type { getAcademicSummary, getWorkload } from "@/server/academics";
import type { CourseProgress, SessionResult } from "@/lib/types";
import { PageHeader, SectionTitle } from "@/components/ui/kit";
import { Sheet } from "@/components/ui/Sheet";
import { diffDays, inDays, relDay, wdShort, type Now } from "@/lib/time";
import { ColumnChart } from "./ColumnChart";

export type Recommendation = { tone: "red" | "amber" | "blue" | "violet"; title: string; text: string; action: { label: string; href: string } };
type Summary = ReturnType<typeof getAcademicSummary>;
type Workload = ReturnType<typeof getWorkload>;

const TONE = { red: "bg-red-soft text-red", amber: "bg-amber-soft text-amber", blue: "bg-primary-soft text-primary-soft-ink", violet: "bg-violet-soft text-violet-ink" };

function markFor(avg: number | null) {
  if (avg === null) return "";
  return avg >= 90 ? "отлично" : avg >= 75 ? "хорошо" : avg >= 60 ? "удовлетворительно" : "ниже порога";
}

export function StudyView({
  now, summary, progress, sessions, workload, recs, openCourse,
}: { now: Now; summary: Summary; progress: CourseProgress[]; sessions: SessionResult[]; workload: Workload; recs: Recommendation[]; openCourse: number | null }) {
  const [course, setCourse] = useState<CourseProgress | null>(progress.find((p) => p.courseId === openCourse) ?? null);
  const [sem, setSem] = useState(summary.semesters.length - 1);
  const semesterRows = sessions.filter((s) => s.order === summary.semesters[sem]?.order);

  return (
    <div>
      <PageHeader title="Учёба" subtitle={`Осенний семестр ${now.date.slice(0, 4)}/${Number(now.date.slice(2, 4)) + 1}, текущий контроль и сессии`} />

      {/* Сводка */}
      <section aria-label="Сводка" className="grid grid-cols-2 gap-2 lg:grid-cols-4">
        <Tile label="Средний балл" value={summary.average?.toFixed(1) ?? "—"} hint={`из 100, ${markFor(summary.average)}`} />
        <Tile label="Закрыто дисциплин" value={`${summary.closed}`} hint={`из ${summary.totalClosedTarget} в сессиях`} />
        <Tile
          label="Контроль за 2 недели"
          value={`${summary.upcomingCount}`}
          hint={summary.nextUpcoming ? `ближайший ${relDay(summary.nextUpcoming.date, now.date)}` : "ничего не запланировано"}
        />
        <Tile
          label="Задолженности"
          value={`${summary.debts.length}`}
          hint={summary.debts.length ? summary.debts.map((d) => d.course).join(", ") : "нет"}
          tone={summary.debts.length ? "red" : "green"}
        />
      </section>

      <div className="mt-8 lg:grid lg:grid-cols-[minmax(0,1fr)_380px] lg:gap-8">
        <div className="min-w-0 space-y-8">
          {/* Рекомендации */}
          {recs.length > 0 && (
            <section>
              <SectionTitle>Рекомендации по подготовке</SectionTitle>
              <ul className="grid gap-2 sm:grid-cols-2">
                {recs.map((r) => (
                  <li key={r.title} className="flex flex-col rounded-[20px] border border-line bg-surface p-4">
                    <span className={`mb-2.5 flex h-8 w-8 items-center justify-center rounded-xl ${TONE[r.tone]}`}>
                      {r.tone === "red" ? <AlertTriangle size={16} /> : r.tone === "violet" ? <Sparkles size={16} /> : <FlagTriangleRight size={16} />}
                    </span>
                    <p className="text-[14.5px] font-semibold leading-snug">{r.title}</p>
                    <p className="mt-1 flex-1 text-[13px] leading-snug text-ink-3">{r.text}</p>
                    <Link href={r.action.href} className={`press mt-3 inline-flex h-9 w-fit items-center gap-1.5 rounded-lg px-3 text-[13px] font-semibold ${r.action.href.startsWith("/assistant") ? "bg-violet-soft text-violet-ink" : "bg-primary-soft text-primary-soft-ink"}`}>
                      {r.action.href.startsWith("/assistant") && <Sparkles size={13} />} {r.action.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* Дисциплины */}
          <section>
            <SectionTitle>Дисциплины семестра</SectionTitle>
            <ul className="overflow-hidden rounded-[20px] border border-line bg-surface">
              {progress.map((p, i) => {
                const pct = p.gradedMax ? Math.round((p.earned / p.gradedMax) * 100) : null;
                const next = p.items.find((x) => !x.past);
                return (
                  <li key={p.courseId} className={i ? "border-t border-line" : ""}>
                    <button onClick={() => setCourse(p)} className="press flex w-full items-center gap-3 px-4 py-3.5 text-left hover:bg-surface-2/60">
                      <span className="min-w-0 flex-1">
                        <span className="flex items-baseline justify-between gap-3">
                          <span className="line-clamp-2 text-[15px] font-semibold leading-snug">{p.name}</span>
                          <span className="tnum shrink-0 text-[14px] font-semibold">
                            {p.gradedMax ? (
                              <>
                                {p.earned}
                                <span className="font-normal text-ink-3">/{p.gradedMax}</span>
                              </>
                            ) : (
                              <span className="font-normal text-ink-3">нет оценок</span>
                            )}
                          </span>
                        </span>
                        <span className="mt-2 block h-1.5 overflow-hidden rounded-full bg-surface-2" aria-hidden>
                          <span className="block h-full rounded-full bg-primary" style={{ width: `${pct ?? 0}%` }} />
                        </span>
                        <span className="mt-1.5 flex justify-between gap-3 text-[12.5px] text-ink-3">
                          <span className="truncate">
                            {p.control}
                            <span className="hidden sm:inline">, {p.credits} з. е., пройдено {p.doneCount} из {p.totalCount}</span>
                          </span>
                          {next && <span className="shrink-0">{next.kind.toLowerCase()} {relDay(next.date, now.date)}</span>}
                        </span>
                      </span>
                      <ChevronRight size={17} className="hidden shrink-0 text-ink-3 sm:block" />
                    </button>
                  </li>
                );
              })}
            </ul>
            <p className="mt-2 px-1 text-[12px] text-ink-3">Баллы — сумма оценок за уже проверенные работы из максимума этих работ.</p>
          </section>

          {/* Сессии */}
          <section>
            <SectionTitle>Результаты сессий</SectionTitle>
            <div className="no-scrollbar -mx-4 mb-2 flex gap-1.5 overflow-x-auto px-4 lg:mx-0 lg:px-0">
              {summary.semesters.map((s, i) => (
                <button key={s.order} onClick={() => setSem(i)} className={`press h-9 shrink-0 rounded-full px-3.5 text-[13px] font-semibold ${sem === i ? "bg-navy text-white dark:bg-primary" : "border border-line bg-surface text-ink-2"}`}>
                  {s.label}
                </button>
              ))}
            </div>
            <div className="overflow-hidden rounded-[20px] border border-line bg-surface">
              <table className="w-full text-[14px]">
                <thead className="border-b border-line text-left text-[12px] text-ink-3">
                  <tr>
                    <th className="px-4 py-2 font-medium">Дисциплина</th>
                    <th className="px-2 py-2 text-right font-medium">Балл</th>
                    <th className="px-4 py-2 text-right font-medium">Оценка</th>
                  </tr>
                </thead>
                <tbody>
                  {semesterRows.map((r) => (
                    <tr key={r.course} className="border-t border-line first:border-t-0">
                      <td className="px-4 py-2.5">
                        <span className="block font-medium leading-snug">{r.course}</span>
                        <span className="text-[12px] text-ink-3">
                          {r.control}, {r.credits} з. е.
                        </span>
                      </td>
                      <td className="tnum px-2 py-2.5 text-right font-semibold">{r.score}</td>
                      <td className="px-4 py-2.5 text-right">
                        <span className={`inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[12px] font-semibold ${r.passed ? "bg-surface-2 text-ink-2" : "bg-red-soft text-red"}`}>
                          {!r.passed && <AlertTriangle size={12} />}
                          {r.mark}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </div>

        {/* Графики */}
        <aside className="mt-8 space-y-6 lg:mt-0">
          <ChartCard title="Средний балл по сессиям" note="Взвешен по зачётным единицам, шкала 0–100">
            <ColumnChart
              data={summary.semesters.map((s) => ({ label: s.label.replace(/\s\d{4}\/(\d{2})$/, " $1"), value: s.average, tip: `${s.label}: ${s.average.toFixed(1)}` }))}
              min={50}
              max={100}
              highlightLast
              format={(v) => v.toFixed(1)}
            />
          </ChartCard>
          <ChartCard title="Нагрузка на этой неделе" note="Аудиторные часы по дням">
            <ColumnChart
              data={workload.days.map((d) => ({ label: wdShort(d.date), value: d.hours, tip: `${wdShort(d.date)}: ${d.count} ${d.count === 1 ? "пара" : d.count < 5 ? "пары" : "пар"}, ${d.hours} ч`, current: d.date === now.date }))}
              min={0}
              format={(v) => `${v}`}
            />
          </ChartCard>
          <ChartCard title="Контрольные точки по неделям" note="Будущие события контроля, включая сессию">
            <ColumnChart data={workload.weeks.map((w) => ({ label: w.label, value: w.count, tip: `Неделя с ${relDay(w.from, now.date)}: ${w.count}` }))} min={0} format={(v) => `${v}`} />
          </ChartCard>
        </aside>
      </div>

      <CourseSheet course={course} now={now} onClose={() => setCourse(null)} />
    </div>
  );
}

function Tile({ label, value, hint, tone }: { label: string; value: string; hint: string; tone?: "red" | "green" }) {
  return (
    <div className="rounded-[18px] border border-line bg-surface px-3.5 py-3">
      <p className="truncate text-[12.5px] leading-tight text-ink-3">{label}</p>
      <p className={`tnum mt-1.5 text-[24px] font-semibold leading-none tracking-[-0.03em] sm:text-[28px] ${tone === "red" ? "text-red" : ""}`}>{value}</p>
      <p className="mt-1 flex items-center gap-1 truncate text-[12px] leading-snug text-ink-3">
        {tone === "green" && <CheckCircle2 size={13} className="shrink-0 text-green" />}
        {hint}
      </p>
    </div>
  );
}

function ChartCard({ title, note, children }: { title: string; note: string; children: React.ReactNode }) {
  return (
    <section className="rounded-[20px] border border-line bg-surface p-4">
      <h2 className="text-[15px] font-semibold tracking-[-0.01em]">{title}</h2>
      <p className="mb-3 text-[12.5px] text-ink-3">{note}</p>
      {children}
    </section>
  );
}

function CourseSheet({ course: p, now, onClose }: { course: CourseProgress | null; now: Now; onClose: () => void }) {
  if (!p) return null;
  return (
    <Sheet open onClose={onClose} title={p.control}>
      <h3 className="text-[20px] font-semibold leading-tight tracking-[-0.02em]">{p.name}</h3>
      <p className="mt-1 text-[13px] text-ink-3">
        {p.teacher}, {p.credits} з. е.
      </p>
      <div className="mt-4 grid grid-cols-3 gap-2 text-center">
        {[
          ["Набрано", `${p.earned}`],
          ["Из проверенных", `${p.gradedMax}`],
          ["Всего в курсе", `${p.totalMax}`],
        ].map(([l, v]) => (
          <div key={l} className="rounded-xl bg-surface-2 px-2 py-2.5">
            <p className="tnum text-[19px] font-semibold">{v}</p>
            <p className="text-[11.5px] text-ink-3">{l}</p>
          </div>
        ))}
      </div>
      <ul className="mt-4 divide-y divide-line">
        {p.items.map((i) => (
          <li key={i.id} className="flex items-center gap-3 py-2.5">
            <span className={`h-2 w-2 shrink-0 rounded-full ${i.past ? (i.score !== null ? "bg-primary" : "bg-amber") : "border-2 border-line-strong"}`} />
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[14px] font-medium">{i.title}</span>
              <span className="text-[12px] text-ink-3">
                {i.kind}, {relDay(i.date, now.date)}
              </span>
            </span>
            <span className="tnum shrink-0 text-[13.5px]">
              {i.score !== null ? (
                <b>
                  {i.score}
                  <span className="font-normal text-ink-3">/{i.maxScore}</span>
                </b>
              ) : i.past ? (
                <span className="text-amber">ждёт оценки</span>
              ) : (
                <span className="text-ink-3">{inDays(diffDays(now.date, i.date))}</span>
              )}
            </span>
          </li>
        ))}
      </ul>
      {p.items.some((i) => !i.past) && (
        <Link
          href={`/assistant?q=${encodeURIComponent(`Помоги подготовиться по предмету «${p.name}»`)}`}
          className="press mt-4 flex h-11 items-center justify-center gap-2 rounded-xl bg-violet-soft text-[14px] font-semibold text-violet-ink"
        >
          <Sparkles size={16} /> План подготовки с NEXT AI
        </Link>
      )}
    </Sheet>
  );
}
