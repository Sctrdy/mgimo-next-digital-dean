import Link from "next/link";
import type { ComponentProps } from "react";
import type { RequestStatus } from "@/lib/types";
import { STATUS_LABEL } from "@/lib/types";

type BtnProps = { variant?: "primary" | "secondary" | "ghost" | "ai" | "danger"; size?: "md" | "sm" | "lg" };

export const btnClass = ({ variant = "primary", size = "md" }: BtnProps) =>
  [
    "press inline-flex items-center justify-center gap-2 rounded-xl font-semibold tracking-[-0.005em] disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap",
    size === "sm" ? "h-9 px-3 text-[13px]" : size === "lg" ? "h-12 px-5 text-[15px]" : "h-11 px-4 text-[14px]",
    variant === "primary" && "bg-primary text-primary-ink hover:brightness-110",
    variant === "secondary" && "border border-line-strong bg-surface text-ink hover:bg-surface-2",
    variant === "ghost" && "text-primary-soft-ink hover:bg-primary-soft",
    variant === "ai" && "bg-violet text-white hover:brightness-110",
    variant === "danger" && "border border-red/30 bg-red-soft text-red hover:brightness-95",
  ]
    .filter(Boolean)
    .join(" ");

export function Button({ variant, size, className = "", ...p }: ComponentProps<"button"> & BtnProps) {
  return <button {...p} className={`${btnClass({ variant, size })} ${className}`} />;
}

export function ButtonLink({ variant, size, className = "", ...p }: ComponentProps<typeof Link> & BtnProps) {
  return <Link {...p} className={`${btnClass({ variant, size })} ${className}`} />;
}

export function Card({ className = "", ...p }: ComponentProps<"section">) {
  return <section {...p} className={`rounded-[20px] border border-line bg-surface ${className}`} />;
}

export function SectionTitle({ children, action, id }: { children: React.ReactNode; action?: React.ReactNode; id?: string }) {
  return (
    <div className="mb-2.5 flex items-end justify-between gap-3 px-0.5" id={id}>
      <h2 className="text-[16px] font-semibold tracking-[-0.015em] text-ink">{children}</h2>
      {action}
    </div>
  );
}

const STATUS_TONE: Record<RequestStatus, string> = {
  submitted: "bg-surface-2 text-ink-2",
  in_progress: "bg-primary-soft text-primary-soft-ink",
  ready: "bg-green-soft text-green",
  issued: "bg-surface-2 text-ink-3",
  rejected: "bg-red-soft text-red",
};
const STATUS_DOT: Record<RequestStatus, string> = {
  submitted: "bg-ink-3",
  in_progress: "bg-primary",
  ready: "bg-green",
  issued: "bg-ink-3",
  rejected: "bg-red",
};

export function StatusBadge({ status }: { status: RequestStatus }) {
  return (
    <span className={`inline-flex h-6 shrink-0 items-center gap-1.5 rounded-full px-2.5 text-[12px] font-semibold ${STATUS_TONE[status]}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${STATUS_DOT[status]}`} />
      {STATUS_LABEL[status]}
    </span>
  );
}

export function PageHeader({ title, subtitle, action }: { title: string; subtitle?: React.ReactNode; action?: React.ReactNode }) {
  return (
    <header className="mb-4 flex items-end justify-between gap-3">
      <div className="min-w-0">
        <h1 className="text-[26px] font-semibold leading-[1.1] tracking-[-0.03em] text-ink sm:text-[30px]">{title}</h1>
        {subtitle && <p className="mt-1 text-[14px] text-ink-3">{subtitle}</p>}
      </div>
      {action}
    </header>
  );
}

export function Empty({ icon, title, text, action }: { icon: React.ReactNode; title: string; text?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center px-6 py-10 text-center">
      <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-surface-2 text-ink-3">{icon}</div>
      <p className="text-[15px] font-semibold">{title}</p>
      {text && <p className="mt-1 max-w-xs text-[13.5px] text-ink-3">{text}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`skeleton rounded-xl ${className}`} />;
}

export function Disclaimer({ className = "" }: { className?: string }) {
  return (
    <p className={`text-[12px] leading-snug text-ink-3 ${className}`}>
      MGIMO NEXT — неофициальный конкурсный прототип. Все данные демонстрационные и вымышленные.
    </p>
  );
}
