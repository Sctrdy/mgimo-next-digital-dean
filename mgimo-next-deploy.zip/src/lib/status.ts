import { toMinutes, type Now } from "./time";
import type { Lesson } from "./types";

export type DayStatus =
  | { kind: "during"; lesson: Lesson; minutesLeft: number; progress: number }
  | { kind: "before"; lesson: Lesson; minutesUntil: number }
  | { kind: "next_day"; lesson: Lesson; date: string }
  | { kind: "none" };

/** lessons — отсортированы по дате и паре, начиная с сегодняшнего дня */
export function dayStatusFrom(lessons: Lesson[], now: Now): DayStatus {
  const active = lessons.filter((l) => l.status !== "cancelled");
  for (const l of active) {
    if (l.date !== now.date) continue;
    const s = toMinutes(l.start);
    const e = toMinutes(l.end);
    if (now.minutes >= s && now.minutes < e) return { kind: "during", lesson: l, minutesLeft: e - now.minutes, progress: (now.minutes - s) / (e - s) };
    if (now.minutes < s) return { kind: "before", lesson: l, minutesUntil: s - now.minutes };
  }
  const next = active.find((l) => l.date > now.date);
  return next ? { kind: "next_day", lesson: next, date: next.date } : { kind: "none" };
}
