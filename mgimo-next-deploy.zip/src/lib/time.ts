// Время и даты. Вся логика «сейчас/до/после» — строго по Москве,
// независимо от часового пояса сервера.

export const TZ = "Europe/Moscow";

export const PAIRS = [
  { n: 1, start: "09:00", end: "10:20" },
  { n: 2, start: "10:30", end: "11:50" },
  { n: 3, start: "12:40", end: "14:00" },
  { n: 4, start: "14:10", end: "15:30" },
  { n: 5, start: "15:40", end: "17:00" },
  { n: 6, start: "17:10", end: "18:30" },
  { n: 7, start: "18:40", end: "20:00" },
] as const;

export function pairTime(n: number) {
  return PAIRS.find((p) => p.n === n) ?? PAIRS[0];
}

export type Now = {
  /** YYYY-MM-DD по Москве */
  date: string;
  /** минуты с полуночи по Москве */
  minutes: number;
};

export function moscowNow(at: Date = new Date()): Now {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(at);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "00";
  return {
    date: `${get("year")}-${get("month")}-${get("day")}`,
    minutes: Number(get("hour")) * 60 + Number(get("minute")),
  };
}

export function toMinutes(hhmm: string) {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}

function parse(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}

function fmt(d: Date) {
  return d.toISOString().slice(0, 10);
}

export function addDays(iso: string, n: number) {
  const d = parse(iso);
  d.setUTCDate(d.getUTCDate() + n);
  return fmt(d);
}

export function diffDays(fromIso: string, toIso: string) {
  return Math.round((parse(toIso).getTime() - parse(fromIso).getTime()) / 86400000);
}

/** 1 = понедельник … 7 = воскресенье */
export function weekday(iso: string) {
  const w = parse(iso).getUTCDay();
  return w === 0 ? 7 : w;
}

export function mondayOf(iso: string) {
  return addDays(iso, 1 - weekday(iso));
}

export function isoWeek(iso: string) {
  const d = parse(iso);
  const day = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
}

export function isStudyDay(iso: string) {
  return weekday(iso) !== 7;
}

/** n-й учебный день начиная с сегодняшнего (0 — сегодня, если учебный) */
export function studyDay(today: string, n: number) {
  let d = today;
  while (!isStudyDay(d)) d = addDays(d, 1);
  let left = n;
  while (left > 0) {
    d = addDays(d, 1);
    if (isStudyDay(d)) left--;
  }
  return d;
}

const MONTHS_GEN = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"];
const MONTHS_SHORT = ["янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"];
const WD_FULL = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"];
const WD_SHORT = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"];

export function wdShort(iso: string) {
  return WD_SHORT[weekday(iso) - 1];
}
export function wdFull(iso: string) {
  return WD_FULL[weekday(iso) - 1];
}
export function dayNum(iso: string) {
  return Number(iso.slice(8, 10));
}
/** «20 ноября» */
export function dateLong(iso: string) {
  return `${dayNum(iso)} ${MONTHS_GEN[Number(iso.slice(5, 7)) - 1]}`;
}
/** «20 ноя» */
export function dateShort(iso: string) {
  return `${dayNum(iso)} ${MONTHS_SHORT[Number(iso.slice(5, 7)) - 1]}`;
}

/** «сегодня», «завтра», «вчера», «пн, 23 ноя» */
export function relDay(iso: string, today: string) {
  const d = diffDays(today, iso);
  if (d === 0) return "сегодня";
  if (d === 1) return "завтра";
  if (d === -1) return "вчера";
  return `${wdShort(iso)}, ${dateShort(iso)}`;
}

export function plural(n: number, one: string, few: string, many: string) {
  const a = Math.abs(n) % 100;
  const b = a % 10;
  if (a > 10 && a < 20) return many;
  if (b > 1 && b < 5) return few;
  if (b === 1) return one;
  return many;
}

/** «1 ч 05 мин», «34 мин» */
export function duration(min: number) {
  const m = Math.max(0, Math.round(min));
  if (m < 60) return `${m} мин`;
  const h = Math.floor(m / 60);
  const r = m % 60;
  return r ? `${h} ч ${String(r).padStart(2, "0")} мин` : `${h} ч`;
}

/** «через 3 дня», «через 2 недели» */
export function inDays(n: number) {
  if (n <= 0) return "сегодня";
  if (n === 1) return "завтра";
  if (n === 2) return "послезавтра";
  if (n < 14) return `через ${n} ${plural(n, "день", "дня", "дней")}`;
  const w = Math.round(n / 7);
  return `через ${w} ${plural(w, "неделю", "недели", "недель")}`;
}

export function formatTimestamp(ms: number) {
  return new Intl.DateTimeFormat("ru-RU", {
    timeZone: TZ,
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(ms));
}
