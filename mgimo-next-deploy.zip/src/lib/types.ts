// Типы, общие для сервера и клиента (без серверных зависимостей).

export type Role = "student" | "staff";

export type PublicUser = {
  id: number;
  login: string;
  role: Role;
  fullName: string;
  shortName: string;
  faculty: string;
  program: string;
  course: number | null;
  group: string | null;
  studyYear: string;
  studentCode: string | null;
  position: string | null;
};

export type LessonStatus = "normal" | "cancelled" | "changed" | "added";

export type Lesson = {
  id: string;
  date: string;
  pair: number;
  start: string;
  end: string;
  courseId: number;
  course: string;
  type: string;
  room: string;
  teacher: string;
  status: LessonStatus;
  note?: string;
  was?: { room?: string; teacher?: string };
};

export type AssessmentKind = "Контрольная" | "Тест" | "Коллоквиум" | "Эссе" | "Презентация" | "Дедлайн" | "Зачёт" | "Экзамен";

export type Assessment = {
  id: number;
  courseId: number;
  course: string;
  kind: AssessmentKind;
  title: string;
  date: string;
  time: string | null;
  room: string | null;
  score: number | null;
  maxScore: number;
  /** прошло ли событие относительно текущего московского времени */
  past: boolean;
};

export type Task = {
  id: number;
  title: string;
  dueDate: string | null;
  dueTime: string | null;
  done: boolean;
  courseId: number | null;
  course: string | null;
};

export type RequestStatus = "submitted" | "in_progress" | "ready" | "issued" | "rejected";

export const STATUS_LABEL: Record<RequestStatus, string> = {
  submitted: "Подана",
  in_progress: "В работе",
  ready: "Готова",
  issued: "Выдана",
  rejected: "Отклонена",
};

export type RequestType = {
  code: string;
  title: string;
  description: string;
  etaDays: number;
  needsCountry: boolean;
  defaultLanguage: Language;
};

export type Language = "ru" | "en" | "ru+en";
export type Delivery = "electronic" | "paper";

export const LANGUAGE_LABEL: Record<Language, string> = { ru: "Русский", en: "Английский", "ru+en": "Русский и английский" };
export const DELIVERY_LABEL: Record<Delivery, string> = { electronic: "Электронно (PDF с ЭП)", paper: "Бумажный оригинал" };

export type RequestInput = {
  typeCode: string;
  purpose: string;
  copies: number;
  language: Language;
  delivery: Delivery;
  country?: string | null;
  comment?: string | null;
};

export type RequestEvent = {
  id: number;
  at: number;
  status: RequestStatus | null;
  actor: string;
  comment: string | null;
};

export type DeanRequest = {
  id: number;
  number: string;
  typeCode: string;
  title: string;
  purpose: string;
  copies: number;
  language: Language;
  delivery: Delivery;
  country: string | null;
  comment: string | null;
  status: RequestStatus;
  source: "form" | "ai";
  createdAt: number;
  updatedAt: number;
  etaDays: number;
  student?: { id: number; fullName: string; group: string | null; faculty: string };
  events?: RequestEvent[];
};

export type Notification = {
  id: number;
  at: number;
  title: string;
  body: string;
  href: string | null;
  read: boolean;
  kind: "request" | "schedule" | "grade" | "system";
};

export type ImportantItem = {
  id: string;
  kind: "assessment" | "exam" | "deadline" | "task" | "request" | "change" | "debt";
  title: string;
  subtitle: string;
  when: string;
  urgency: number; // меньше — срочнее
  tone: "blue" | "violet" | "amber" | "red" | "green" | "slate";
  action: { label: string; href: string };
};

export type CourseProgress = {
  courseId: number;
  name: string;
  control: string;
  teacher: string;
  credits: number;
  earned: number;
  gradedMax: number;
  totalMax: number;
  doneCount: number;
  totalCount: number;
  items: Assessment[];
};

export type SessionResult = {
  semester: string;
  order: number;
  course: string;
  control: string;
  score: number;
  mark: string;
  credits: number;
  passed: boolean;
};

export type ChatMeta = {
  tools?: string[];
  draft?: DraftPreview;
  createdRequest?: { id: number; number: string };
  fallback?: boolean;
};

export type DraftPreview = {
  draftId: number;
  status: "pending" | "confirmed" | "cancelled";
  type: { code: string; title: string; etaDays: number };
  input: RequestInput;
  profile: { fullName: string; faculty: string; program: string; course: number | null; group: string | null; studyYear: string };
};

export type ChatMessage = {
  id: number;
  role: "user" | "assistant";
  content: string;
  at: number;
  meta: ChatMeta | null;
};
