import { apiError, apiUser } from "@/server/auth";
import { staffUpdate } from "@/server/requests";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const staff = await apiUser({ role: "staff", mutating: true });
    const body = (await req.json().catch(() => ({}))) as { status?: string | null; comment?: string | null };
    const r = staffUpdate(staff, Number((await ctx.params).id), body);
    return Response.json({ request: r });
  } catch (e) {
    return apiError(e);
  }
}
