import { apiError, apiUser } from "@/server/auth";
import { setPrefs } from "@/server/notifications";

export async function PATCH(req: Request) {
  try {
    const u = await apiUser({ mutating: true });
    const body = (await req.json().catch(() => ({}))) as { prefs?: Record<string, unknown> };
    return Response.json({ prefs: setPrefs(u.id, body.prefs ?? {}) });
  } catch (e) {
    return apiError(e);
  }
}
