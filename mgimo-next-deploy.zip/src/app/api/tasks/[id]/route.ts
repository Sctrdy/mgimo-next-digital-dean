import { apiError, apiUser } from "@/server/auth";
import { deleteTask, setTaskDone } from "@/server/tasks";

export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const u = await apiUser({ role: "student", mutating: true });
    const { done } = (await req.json().catch(() => ({}))) as { done?: boolean };
    setTaskDone(u.id, Number((await ctx.params).id), !!done);
    return Response.json({ ok: true });
  } catch (e) {
    return apiError(e);
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const u = await apiUser({ role: "student", mutating: true });
    deleteTask(u.id, Number((await ctx.params).id));
    return Response.json({ ok: true });
  } catch (e) {
    return apiError(e);
  }
}
