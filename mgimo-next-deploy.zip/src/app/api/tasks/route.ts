import { apiError, apiUser } from "@/server/auth";
import { createTask } from "@/server/tasks";

export async function POST(req: Request) {
  try {
    const u = await apiUser({ role: "student", mutating: true });
    const b = await req.json().catch(() => ({}));
    return Response.json({ task: createTask(u.id, b) });
  } catch (e) {
    return apiError(e);
  }
}
