import { apiError, apiUser } from "@/server/auth";
import { createRequest } from "@/server/requests";

export async function POST(req: Request) {
  try {
    const u = await apiUser({ role: "student", mutating: true });
    const body = await req.json().catch(() => ({}));
    return Response.json({ request: createRequest(u, body, "form") });
  } catch (e) {
    return apiError(e);
  }
}
