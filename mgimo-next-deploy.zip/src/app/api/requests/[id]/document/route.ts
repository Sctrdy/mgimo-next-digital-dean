import { apiError, apiUser, HttpError } from "@/server/auth";
import { getRequest } from "@/server/requests";
import { getDb } from "@/server/db";
import { formatTimestamp } from "@/lib/time";

const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);

/** Демо-документ для готовых электронных заявок. Явно помечен как DEMO и не имитирует официальный бланк. */
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const u = await apiUser();
    const r = getRequest(u, Number((await ctx.params).id));
    if (r.status !== "ready" && r.status !== "issued") throw new HttpError(409, "Документ ещё не готов");
    const owner = getDb().prepare("SELECT full_name, faculty, program, course, group_name, study_year FROM users WHERE id = (SELECT user_id FROM requests WHERE id = ?)").get(r.id) as {
      full_name: string; faculty: string; program: string; course: number; group_name: string; study_year: string;
    };
    const en = r.language !== "ru";
    const html = `<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(r.number)} — демо-документ</title>
<style>
body{margin:0;background:#eef3fa;font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:#07172f}
.page{max-width:720px;margin:24px auto;background:#fff;border-radius:16px;padding:48px 44px;position:relative;overflow:hidden;box-shadow:0 20px 60px -30px rgba(7,23,47,.4)}
.wm{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:140px;font-weight:800;color:rgba(23,105,224,.07);transform:rotate(-24deg);pointer-events:none}
.top{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e1e8f2;padding-bottom:16px;font-size:13px;color:#6b7a92}
h1{font-size:22px;margin:28px 0 18px}p{line-height:1.6;font-size:15px}.muted{color:#6b7a92;font-size:13px}
.note{margin-top:32px;padding:12px 14px;border-radius:10px;background:#fdf1df;color:#a85d00;font-size:13px}
@media print{body{background:#fff}.page{box-shadow:none;margin:0}}
</style></head><body><div class="page"><div class="wm">DEMO</div>
<div class="top"><b style="color:#07172f">MGIMO NEXT · демонстрационный документ</b><span>${esc(r.number)}</span></div>
<h1>${esc(r.title)}</h1>
<p>Настоящим подтверждается, что <b>${esc(owner.full_name)}</b> является студентом ${owner.course} курса (группа ${esc(owner.group_name)}), направление «${esc(owner.program)}», ${esc(owner.faculty.toLowerCase())}, в ${esc(owner.study_year)} учебном году.</p>
${r.country ? `<p>Документ предназначен для предоставления в консульство: ${esc(r.country)}.</p>` : ""}
${en ? `<p class="muted">This is to certify that ${esc(owner.full_name)} is a ${owner.course}${owner.course === 2 ? "nd" : owner.course === 3 ? "rd" : "th"}-year student (demo data).</p>` : ""}
<p>Назначение: ${esc(r.purpose)}.</p>
<p class="muted">Сформировано: ${esc(formatTimestamp(r.updatedAt))}. Подписано (демо): специалист деканата.</p>
<div class="note">Неофициальный конкурсный прототип. Документ не имеет юридической силы, все данные вымышленные.</div>
</div></body></html>`;
    return new Response(html, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
  } catch (e) {
    return apiError(e);
  }
}
