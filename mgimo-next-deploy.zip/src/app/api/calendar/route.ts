import { apiError, apiUser } from "@/server/auth";
import { getAssessments, getLessons } from "@/server/schedule";
import { addDays, moscowNow } from "@/lib/time";

const esc = (s: string) => s.replace(/\\/g, "\\\\").replace(/;/g, "\\;").replace(/,/g, "\\,").replace(/\n/g, "\\n");
// Москва — UTC+3 без перехода на летнее время с 2014 года, поэтому пишем время в UTC:
// так событие корректно читают все календари (без блока VTIMEZONE).
const dt = (date: string, hhmm: string) => {
  const [y, m, d] = date.split("-").map(Number);
  const [h, min] = hhmm.split(":").map(Number);
  return new Date(Date.UTC(y, m - 1, d, h - 3, min)).toISOString().replace(/[-:]/g, "").slice(0, 15) + "Z";
};

/** Экспорт в .ics: занятия на 4 недели и события контроля (или одно занятие). */
export async function GET(req: Request) {
  try {
    const u = await apiUser({ role: "student" });
    const now = moscowNow();
    const one = new URL(req.url).searchParams.get("lesson");
    const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//MGIMO NEXT demo//RU", "CALSCALE:GREGORIAN", "X-WR-CALNAME:MGIMO NEXT (демо)"];
    const stamp = new Date().toISOString().replace(/[-:]/g, "").slice(0, 15) + "Z";
    let lessons = getLessons(u.id, now.date, addDays(now.date, 27), now).filter((l) => l.status !== "cancelled");
    if (one) {
      const date = one.slice(0, 10);
      lessons = /^\d{4}-\d{2}-\d{2}$/.test(date) ? getLessons(u.id, date, date, now).filter((l) => l.id === one) : [];
    }
    for (const l of lessons) {
      lines.push(
        "BEGIN:VEVENT", `UID:${l.id}-${u.id}@mgimo-next.demo`, `DTSTAMP:${stamp}`,
        `DTSTART:${dt(l.date, l.start)}`, `DTEND:${dt(l.date, l.end)}`,
        `SUMMARY:${esc(`${l.course} (${l.type})`)}`, `LOCATION:${esc(l.room)}`,
        `DESCRIPTION:${esc(`${l.teacher}${l.note ? `\n${l.note}` : ""}`)}`, "END:VEVENT",
      );
    }
    if (!one) {
      for (const a of getAssessments(u.id, now).filter((x) => !x.past)) {
        const t = a.time && a.time !== "23:59" ? a.time : "09:00";
        const end = a.time === "23:59" ? "23:59" : `${String(Math.min(23, Number(t.slice(0, 2)) + 1)).padStart(2, "0")}${t.slice(2)}`;
        lines.push(
          "BEGIN:VEVENT", `UID:asm-${a.id}@mgimo-next.demo`, `DTSTAMP:${stamp}`,
          `DTSTART:${dt(a.date, t)}`, `DTEND:${dt(a.date, end)}`,
          `SUMMARY:${esc(`${a.kind}: ${a.course}`)}`, `DESCRIPTION:${esc(a.title)}`, ...(a.room ? [`LOCATION:${esc(a.room)}`] : []), "END:VEVENT",
        );
      }
    }
    lines.push("END:VCALENDAR");
    return new Response(lines.join("\r\n"), {
      headers: {
        "content-type": "text/calendar; charset=utf-8",
        "content-disposition": `attachment; filename="mgimo-next-${one ? "lesson" : "schedule"}.ics"`,
      },
    });
  } catch (e) {
    return apiError(e);
  }
}
