import { cookies } from "next/headers";
import { createSession, verifyCredentials, SESSION_COOKIE } from "@/server/auth";

export async function POST(req: Request) {
  const body = (await req.json().catch(() => ({}))) as { login?: string; password?: string };
  const login = String(body.login ?? "").slice(0, 64);
  const password = String(body.password ?? "").slice(0, 128);
  if (!login || !password) return Response.json({ error: "Введите логин и пароль" }, { status: 400 });
  const user = await verifyCredentials(login, password);
  if (user === "locked") return Response.json({ error: "Слишком много попыток. Подождите минуту и попробуйте снова." }, { status: 429 });
  if (!user) return Response.json({ error: "Неверный логин или пароль" }, { status: 401 });
  const { token, maxAge } = createSession(user.id);
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production" && process.env.INSECURE_COOKIES !== "1",
    path: "/",
    maxAge,
  });
  return Response.json({ ok: true, home: user.role === "staff" ? "/staff" : "/schedule" });
}
