import { apiError, apiUser } from "@/server/auth";
import { getCourses } from "@/server/academics";
import { listRequests, staffListRequests } from "@/server/requests";
import { getAssessments, getTasks } from "@/server/schedule";
import { relDay, moscowNow } from "@/lib/time";

export async function GET(req: Request) {
  try {
    const u = await apiUser();
    const q = (new URL(req.url).searchParams.get("q") ?? "").trim().toLowerCase().slice(0, 60);
    if (q.length < 2) return Response.json({ hits: [] });
    const has = (...s: (string | null | undefined)[]) => s.some((x) => x?.toLowerCase().includes(q));
    const hits: { type: string; title: string; subtitle: string; href: string }[] = [];
    if (u.role === "staff") {
      for (const r of staffListRequests({ q }).slice(0, 10))
        hits.push({ type: "Заявка", title: `${r.number}, ${r.title}`, subtitle: r.student?.fullName ?? "", href: `/staff/${r.id}` });
      return Response.json({ hits });
    }
    const now = moscowNow();
    for (const c of getCourses(u.id)) if (has(c.name, c.short, c.teacher)) hits.push({ type: "Дисциплина", title: c.name, subtitle: c.teacher, href: `/study?course=${c.id}` });
    for (const a of getAssessments(u.id, now))
      if (!a.past && has(a.title, a.course, a.kind))
        hits.push({ type: a.kind, title: a.title === a.kind ? `${a.kind}: ${a.course}` : a.title, subtitle: relDay(a.date, now.date), href: `/schedule?date=${a.date}` });
    for (const r of listRequests(u.id)) if (has(r.number, r.title, r.purpose)) hits.push({ type: "Заявка", title: r.title, subtitle: r.number, href: `/dean/${r.id}` });
    for (const t of getTasks(u.id, now))
      if (has(t.title, t.course)) hits.push({ type: "Задача", title: t.title, subtitle: t.done ? "выполнена" : t.dueDate ? relDay(t.dueDate, now.date) : "без срока", href: "/schedule#tasks" });
    return Response.json({ hits: hits.slice(0, 12) });
  } catch (e) {
    return apiError(e);
  }
}
