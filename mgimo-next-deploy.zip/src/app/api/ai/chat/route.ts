import { apiError, apiUser, HttpError } from "@/server/auth";
import { answer, clearHistory, history, saveMessage } from "@/server/ai/agent";

export const maxDuration = 60;

// простое ограничение частоты: не больше 12 сообщений в минуту на пользователя
const hits = new Map<number, number[]>();
function rateLimit(userId: number) {
  const now = Date.now();
  const list = (hits.get(userId) ?? []).filter((t) => now - t < 60_000);
  if (list.length >= 12) throw new HttpError(429, "Слишком много сообщений подряд. Подожди минуту.");
  list.push(now);
  hits.set(userId, list);
}

export async function GET() {
  try {
    const u = await apiUser({ role: "student" });
    return Response.json({ messages: history(u.id), mode: process.env.DEEPSEEK_API_KEY ? "llm" : "fallback" });
  } catch (e) {
    return apiError(e);
  }
}

export async function POST(req: Request) {
  try {
    const u = await apiUser({ role: "student", mutating: true });
    const { message } = (await req.json().catch(() => ({}))) as { message?: string };
    const text = String(message ?? "").trim().slice(0, 1500);
    if (!text) throw new HttpError(400, "Пустое сообщение");
    rateLimit(u.id);
    const userMessage = saveMessage(u.id, "user", text);
    const res = await answer(u, text);
    const reply = saveMessage(u.id, "assistant", res.content, res.meta);
    return Response.json({ userMessage, message: reply });
  } catch (e) {
    return apiError(e);
  }
}

export async function DELETE() {
  try {
    const u = await apiUser({ role: "student", mutating: true });
    clearHistory(u.id);
    return Response.json({ ok: true });
  } catch (e) {
    return apiError(e);
  }
}
