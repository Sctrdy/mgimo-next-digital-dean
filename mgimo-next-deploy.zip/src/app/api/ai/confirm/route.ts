import { apiError, apiUser } from "@/server/auth";
import { cancelDraft, confirmDraft } from "@/server/ai/confirm";

/** Подтверждение черновика NEXT AI — отдельное действие пользователя, а не вызов инструмента моделью. */
export async function POST(req: Request) {
  try {
    const u = await apiUser({ role: "student", mutating: true });
    const { draftId, cancel } = (await req.json().catch(() => ({}))) as { draftId?: number; cancel?: boolean };
    const id = Number(draftId);
    if (cancel) return Response.json(cancelDraft(u, id));
    return Response.json(confirmDraft(u, id));
  } catch (e) {
    return apiError(e);
  }
}
