import { apiError, apiUser } from "@/server/auth";
import { listNotifications, markRead, unreadCount } from "@/server/notifications";

export async function GET(req: Request) {
  try {
    const u = await apiUser();
    const countOnly = new URL(req.url).searchParams.get("count");
    if (countOnly) return Response.json({ unread: unreadCount(u.id) });
    return Response.json({ items: listNotifications(u.id), unread: unreadCount(u.id) });
  } catch (e) {
    return apiError(e);
  }
}

export async function POST(req: Request) {
  try {
    const u = await apiUser({ mutating: true });
    const { id } = (await req.json().catch(() => ({}))) as { id?: number };
    markRead(u.id, id ? Number(id) : undefined);
    return Response.json({ ok: true, unread: unreadCount(u.id) });
  } catch (e) {
    return apiError(e);
  }
}
