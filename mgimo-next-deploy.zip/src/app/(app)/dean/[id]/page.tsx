import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CheckCircle2, Sparkles } from "lucide-react";
import { requireStudentPage } from "@/server/auth";
import { getRequest } from "@/server/requests";
import { HttpError } from "@/server/errors";
import { DocumentLink, RequestFields, RequestHeader, RequestHistory, StatusTrack } from "@/components/dean/RequestDetails";
import { SectionTitle } from "@/components/ui/kit";

export const metadata: Metadata = { title: "Обращение" };

export default async function RequestPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: Promise<{ created?: string }> }) {
  const user = await requireStudentPage();
  const { id } = await params;
  const { created } = await searchParams;
  let r;
  try {
    r = getRequest(user, Number(id));
  } catch (e) {
    if (e instanceof HttpError && e.status === 404) notFound();
    throw e;
  }
  return (
    <div className="mx-auto max-w-2xl">
      <Link href="/dean" className="press -ml-1 mb-3 inline-flex h-9 items-center gap-1.5 rounded-lg px-1 text-[14px] font-medium text-ink-2">
        <ArrowLeft size={18} /> Все обращения
      </Link>
      {created && (
        <div className="mb-4 flex items-start gap-3 rounded-2xl bg-green-soft px-4 py-3 text-green">
          <CheckCircle2 size={20} className="mt-0.5 shrink-0" />
          <p className="text-[14px] font-medium">Обращение отправлено. Мы пришлём уведомление, когда статус изменится.</p>
        </div>
      )}
      <RequestHeader r={r} />
      <div className="mt-5">
        <StatusTrack status={r.status} />
      </div>
      <div className="mt-5 space-y-6">
        <DocumentLink r={r} />
        <RequestFields r={r} />
        <section>
          <SectionTitle>История обработки</SectionTitle>
          <div className="rounded-[20px] border border-line bg-surface p-4">
            <RequestHistory r={r} />
          </div>
        </section>
        <Link
          href={`/assistant?q=${encodeURIComponent(`Какой статус моего обращения ${r.number}?`)}`}
          className="press flex items-center gap-2 rounded-2xl bg-violet-soft px-4 py-3 text-[14px] font-medium text-violet-ink"
        >
          <Sparkles size={17} /> Спросить NEXT AI об этом обращении
        </Link>
      </div>
    </div>
  );
}
