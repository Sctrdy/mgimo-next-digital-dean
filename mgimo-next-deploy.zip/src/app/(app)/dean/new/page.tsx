import type { Metadata } from "next";
import { requireStudentPage } from "@/server/auth";
import { getRequestTypes } from "@/server/requests";
import { NewRequestForm } from "@/components/dean/NewRequestForm";

export const metadata: Metadata = { title: "Новое обращение" };

export default async function NewRequestPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const user = await requireStudentPage();
  const sp = await searchParams;
  const types = getRequestTypes();
  return (
    <NewRequestForm
      types={types}
      initialType={types.some((t) => t.code === sp.type) ? sp.type! : null}
      prefill={{
        purpose: sp.purpose?.slice(0, 200),
        country: sp.country?.slice(0, 60),
        comment: sp.comment?.slice(0, 500),
        language: sp.language === "ru" || sp.language === "en" || sp.language === "ru+en" ? sp.language : undefined,
        delivery: sp.delivery === "paper" || sp.delivery === "electronic" ? sp.delivery : undefined,
      }}
      profile={{ fullName: user.fullName, faculty: user.faculty, program: user.program, course: user.course, group: user.group, studyYear: user.studyYear }}
    />
  );
}
