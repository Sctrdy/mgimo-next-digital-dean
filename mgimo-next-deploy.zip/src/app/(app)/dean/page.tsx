import type { Metadata } from "next";
import { requireStudentPage } from "@/server/auth";
import { listRequests, getRequestTypes } from "@/server/requests";
import { DeanList } from "@/components/dean/DeanList";

export const metadata: Metadata = { title: "Деканат" };

export default async function DeanPage({ searchParams }: { searchParams: Promise<{ filter?: string }> }) {
  const user = await requireStudentPage();
  const sp = await searchParams;
  const types = getRequestTypes();
  return <DeanList requests={listRequests(user.id)} popular={types.slice(0, 4)} initialFilter={sp.filter ?? "all"} />;
}
