"use client";
import { RotateCcw, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/kit";

export default function ErrorPage({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="flex flex-col items-center px-6 py-16 text-center">
      <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-red-soft text-red">
        <TriangleAlert size={22} />
      </span>
      <h1 className="mt-4 text-[20px] font-semibold tracking-[-0.02em]">Не удалось загрузить раздел</h1>
      <p className="mt-1 max-w-sm text-[14px] text-ink-3">Сервер не ответил. Проверьте соединение и обновите страницу — ваши данные не потеряны.</p>
      <Button className="mt-5" onClick={reset}>
        <RotateCcw size={16} /> Обновить
      </Button>
    </div>
  );
}
