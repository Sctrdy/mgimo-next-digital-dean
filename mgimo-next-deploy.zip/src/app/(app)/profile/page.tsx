import type { Metadata } from "next";
import { requireUser } from "@/server/auth";
import { getDb } from "@/server/db";
import { getPrefs } from "@/server/notifications";
import { getAcademicSummary, getCourses } from "@/server/academics";
import { addDays, moscowNow } from "@/lib/time";
import { ProfileView } from "@/components/profile/ProfileView";

export const metadata: Metadata = { title: "Профиль" };

export default async function ProfilePage() {
  const user = await requireUser();
  const now = moscowNow();
  const events = (getDb().prepare("SELECT * FROM campus_events ORDER BY offset_days").all() as { id: number; title: string; offset_days: number; time: string; place: string; tag: string }[]).map(
    (e) => ({ id: e.id, title: e.title, date: addDays(now.date, e.offset_days), time: e.time, place: e.place, tag: e.tag }),
  );
  const academic =
    user.role === "student"
      ? (() => {
          const s = getAcademicSummary(user.id, now);
          const courses = getCourses(user.id);
          return { average: s.average, closed: s.closed, credits: courses.reduce((a, c) => a + c.credits, 0), courses: courses.length, debts: s.debts.length };
        })()
      : null;
  return <ProfileView user={user} prefs={getPrefs(user.id)} events={events} academic={academic} today={now.date} />;
}
