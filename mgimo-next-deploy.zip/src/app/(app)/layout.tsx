import { requireUser } from "@/server/auth";
import { unreadCount } from "@/server/notifications";
import { BottomNav } from "@/components/shell/BottomNav";
import { SideNav } from "@/components/shell/SideNav";
import { TopBar } from "@/components/shell/TopBar";
import { Disclaimer } from "@/components/ui/kit";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const home = user.role === "staff" ? "/staff" : "/schedule";
  return (
    <div className="flex min-h-dvh">
      <SideNav user={user} />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar unread={unreadCount(user.id)} home={home} />
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 pb-8 pt-3 lg:px-8 lg:pb-10 lg:pt-2">
          {children}
        </main>
        <footer className="mx-auto w-full max-w-6xl px-4 pb-[calc(84px+env(safe-area-inset-bottom))] lg:px-8 lg:pb-6">
          <Disclaimer />
        </footer>
      </div>
      <BottomNav role={user.role} />
    </div>
  );
}
