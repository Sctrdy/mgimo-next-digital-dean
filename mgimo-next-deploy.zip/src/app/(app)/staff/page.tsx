import type { Metadata } from "next";
import Link from "next/link";
import { Inbox, Sparkles } from "lucide-react";
import { requireStaffPage } from "@/server/auth";
import { staffListRequests, staffStats } from "@/server/requests";
import { PageHeader, StatusBadge, Empty } from "@/components/ui/kit";
import { StaffFilters } from "@/components/staff/StaffFilters";
import { formatTimestamp } from "@/lib/time";

export const metadata: Metadata = { title: "Обращения студентов" };

export default async function StaffPage({ searchParams }: { searchParams: Promise<{ status?: string; q?: string }> }) {
  const user = await requireStaffPage();
  const sp = await searchParams;
  const status = sp.status ?? "active";
  const q = (sp.q ?? "").slice(0, 60);
  const list = staffListRequests({ status, q });
  const stats = staffStats();
  const tiles = [
    { label: "Новые", value: stats.submitted, status: "submitted" },
    { label: "В работе", value: stats.in_progress, status: "in_progress" },
    { label: "Готовы к выдаче", value: stats.ready, status: "ready" },
    { label: "Выданы и закрыты", value: stats.done, status: "issued" },
  ];
  return (
    <div>
      <PageHeader title="Обращения студентов" subtitle={`${user.shortName}, ${user.position?.toLowerCase()}`} />
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        {tiles.map((t) => (
          <Link
            key={t.label}
            href={`/staff?status=${t.status}`}
            className={`press rounded-2xl border px-4 py-3 ${status === t.status ? "border-primary bg-primary-soft/40" : "border-line bg-surface hover:border-line-strong"}`}
          >
            <span className="tnum block text-[26px] font-semibold leading-none tracking-[-0.03em]">{t.value}</span>
            <span className="mt-1.5 block text-[13px] text-ink-3">{t.label}</span>
          </Link>
        ))}
      </div>

      <StaffFilters status={status} q={q} />

      <div className="mt-3 overflow-hidden rounded-[20px] border border-line bg-surface">
        {list.length === 0 ? (
          <Empty icon={<Inbox size={22} />} title="Заявок нет" text={q ? "По запросу ничего не найдено." : "В этой категории пусто."} />
        ) : (
          <table className="w-full text-left text-[14px]">
            <thead className="hidden border-b border-line text-[12.5px] text-ink-3 md:table-header-group">
              <tr>
                <th className="px-4 py-2.5 font-medium">Заявка</th>
                <th className="px-4 py-2.5 font-medium">Студент</th>
                <th className="px-4 py-2.5 font-medium">Подана</th>
                <th className="px-4 py-2.5 font-medium">Статус</th>
              </tr>
            </thead>
            <tbody>
              {list.map((r, i) => (
                <tr key={r.id} className={`relative block hover:bg-surface-2/60 md:table-row ${i ? "border-t border-line" : ""}`}>
                  <td className="block px-4 pt-3 md:table-cell md:py-3">
                    <Link href={`/staff/${r.id}`} className="font-semibold after:absolute after:inset-0">
                      {r.title}
                    </Link>
                    <span className="tnum mt-0.5 flex items-center gap-1.5 text-[12.5px] text-ink-3">
                      {r.number}
                      {r.source === "ai" && <Sparkles size={12} className="text-violet" aria-label="через NEXT AI" />}
                    </span>
                  </td>
                  <td className="block px-4 md:table-cell md:py-3">
                    <span className="text-[13.5px]">{r.student?.fullName}</span>
                    <span className="block text-[12.5px] text-ink-3">{r.student?.group}</span>
                  </td>
                  <td className="tnum hidden px-4 py-3 text-[13px] text-ink-3 md:table-cell">{formatTimestamp(r.createdAt)}</td>
                  <td className="block px-4 pb-3 pt-1.5 md:table-cell md:py-3">
                    <StatusBadge status={r.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
