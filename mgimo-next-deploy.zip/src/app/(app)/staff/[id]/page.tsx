import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { requireStaffPage } from "@/server/auth";
import { allowedTransitions, getRequest } from "@/server/requests";
import { HttpError } from "@/server/errors";
import { RequestFields, RequestHeader, RequestHistory, StatusTrack } from "@/components/dean/RequestDetails";
import { SectionTitle } from "@/components/ui/kit";
import { StaffActions } from "@/components/staff/StaffActions";

export const metadata: Metadata = { title: "Обработка обращения" };

export default async function StaffRequestPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await requireStaffPage();
  const { id } = await params;
  let r;
  try {
    r = getRequest(user, Number(id));
  } catch (e) {
    if (e instanceof HttpError && e.status === 404) notFound();
    throw e;
  }
  return (
    <div>
      <Link href="/staff" className="press -ml-1 mb-3 inline-flex h-9 items-center gap-1.5 rounded-lg px-1 text-[14px] font-medium text-ink-2">
        <ArrowLeft size={18} /> Все обращения
      </Link>
      <div className="lg:grid lg:grid-cols-[minmax(0,1fr)_380px] lg:gap-8">
        <div className="min-w-0 space-y-6">
          <RequestHeader r={r} />
          <StatusTrack status={r.status} />
          <section>
            <SectionTitle>Студент</SectionTitle>
            <div className="rounded-[20px] border border-line bg-surface px-4 py-3">
              <p className="text-[15px] font-semibold">{r.student?.fullName}</p>
              <p className="text-[13px] text-ink-3">
                {r.student?.faculty}, группа {r.student?.group}
              </p>
            </div>
          </section>
          <section>
            <SectionTitle>Параметры документа</SectionTitle>
            <RequestFields r={r} />
          </section>
          <section>
            <SectionTitle>История обработки</SectionTitle>
            <div className="rounded-[20px] border border-line bg-surface p-4">
              <RequestHistory r={r} />
            </div>
          </section>
        </div>
        <aside className="mt-6 lg:mt-0">
          <div className="lg:sticky lg:top-20">
            <StaffActions id={r.id} status={r.status} next={allowedTransitions(r.status)} studentName={r.student?.fullName ?? ""} />
          </div>
        </aside>
      </div>
    </div>
  );
}
