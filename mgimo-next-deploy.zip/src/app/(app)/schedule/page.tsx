import type { Metadata } from "next";
import { requireStudentPage } from "@/server/auth";
import { getAssessments, getLessons, getTasks } from "@/server/schedule";
import { getImportant, weekMarks } from "@/server/important";
import { getCourses } from "@/server/academics";
import { addDays, moscowNow, mondayOf } from "@/lib/time";
import { ScheduleView } from "@/components/schedule/ScheduleView";

export const metadata: Metadata = { title: "Расписание" };

export default async function SchedulePage({ searchParams }: { searchParams: Promise<{ date?: string; view?: string }> }) {
  const user = await requireStudentPage();
  const sp = await searchParams;
  const now = moscowNow();
  const selected = sp.date && /^\d{4}-\d{2}-\d{2}$/.test(sp.date) ? sp.date : now.date;
  const monday = mondayOf(selected);
  const sunday = addDays(monday, 6);

  const weekLessons = getLessons(user.id, monday, sunday, now);
  const upcoming = getLessons(user.id, now.date, addDays(now.date, 9), now);
  const assessments = getAssessments(user.id, now);

  return (
    <ScheduleView
      key={monday}
      now={now}
      selected={selected}
      monday={monday}
      view={sp.view === "week" ? "week" : "day"}
      marks={weekMarks(user.id, monday, now)}
      lessons={weekLessons}
      upcoming={upcoming}
      assessments={assessments}
      important={getImportant(user.id, now)}
      tasks={getTasks(user.id, now)}
      courses={getCourses(user.id).map((c) => ({ id: c.id, name: c.name }))}
      firstName={user.shortName.split(" ")[0]}
    />
  );
}
