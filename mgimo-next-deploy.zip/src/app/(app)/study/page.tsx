import type { Metadata } from "next";
import { requireStudentPage } from "@/server/auth";
import { getAcademicSummary, getCourseProgress, getSessionResults, getWorkload } from "@/server/academics";
import { getLessons } from "@/server/schedule";
import { addDays, diffDays, inDays, mondayOf, moscowNow, relDay } from "@/lib/time";
import { StudyView, type Recommendation } from "@/components/study/StudyView";

export const metadata: Metadata = { title: "Учёба" };

export default async function StudyPage({ searchParams }: { searchParams: Promise<{ course?: string }> }) {
  const user = await requireStudentPage();
  const sp = await searchParams;
  const now = moscowNow();
  const summary = getAcademicSummary(user.id, now);
  const progress = getCourseProgress(user.id, now);
  const sessions = getSessionResults(user.id);

  const monday = mondayOf(now.date);
  const week = getLessons(user.id, monday, addDays(monday, 5), now).filter((l) => l.status !== "cancelled");
  const workload = getWorkload(
    user.id,
    Array.from({ length: 6 }, (_, i) => addDays(monday, i)).map((date) => ({ date, count: week.filter((l) => l.date === date).length })),
    now,
  );

  // Рекомендации строятся только из будущих событий и реальных баллов
  const recs: Recommendation[] = [];
  for (const d of summary.debts) {
    recs.push({
      tone: "red", title: `Закрыть задолженность: ${d.course}`,
      text: d.retakeDate && d.retakeDate >= now.date ? `Пересдача ${relDay(d.retakeDate, now.date)}. Сначала подай заявление, затем повтори темы с наименьшими баллами.` : "Согласуй дату пересдачи через деканат.",
      action: { label: "Подать заявление", href: "/dean/new?type=retake" },
    });
  }
  const upcoming = progress
    .flatMap((p) => p.items.filter((i) => !i.past && i.kind !== "Экзамен" && i.kind !== "Зачёт").map((i) => ({ i, p })))
    .sort((a, b) => a.i.date.localeCompare(b.i.date))
    .slice(0, 2);
  for (const { i, p } of upcoming) {
    const pct = p.gradedMax ? Math.round((p.earned / p.gradedMax) * 100) : null;
    recs.push({
      tone: diffDays(now.date, i.date) <= 3 ? "amber" : "blue",
      title: `${i.kind}: ${p.name}`,
      text: `${inDays(diffDays(now.date, i.date))}, ${i.maxScore} баллов.${pct !== null ? ` Сейчас по предмету ${pct}% от возможного.` : ""}`,
      action: { label: "План подготовки", href: `/assistant?q=${encodeURIComponent(`Помоги подготовиться: ${i.title} (${p.name})`)}` },
    });
  }
  const weakest = progress.filter((p) => p.gradedMax > 0).sort((a, b) => a.earned / a.gradedMax - b.earned / b.gradedMax)[0];
  if (weakest && weakest.earned / weakest.gradedMax < 0.8) {
    const exam = weakest.items.find((i) => !i.past && (i.kind === "Экзамен" || i.kind === "Зачёт"));
    recs.push({
      tone: "violet",
      title: `Подтянуть: ${weakest.name}`,
      text: `${weakest.earned} из ${weakest.gradedMax} баллов (${Math.round((weakest.earned / weakest.gradedMax) * 100)}%) — самый низкий результат в семестре.${exam ? ` ${exam.kind} ${relDay(exam.date, now.date)}.` : ""}`,
      action: { label: "Разобрать с NEXT AI", href: `/assistant?q=${encodeURIComponent(`Как подтянуть ${weakest.name}? Какие у меня баллы по предмету?`)}` },
    });
  }

  return (
    <StudyView
      now={now}
      summary={summary}
      progress={progress}
      sessions={sessions}
      workload={workload}
      recs={recs}
      openCourse={sp.course ? Number(sp.course) : null}
    />
  );
}
