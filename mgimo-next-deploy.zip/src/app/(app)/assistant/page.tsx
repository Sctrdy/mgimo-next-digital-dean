import type { Metadata } from "next";
import { requireStudentPage } from "@/server/auth";
import { history } from "@/server/ai/agent";
import { Assistant } from "@/components/ai/Assistant";

export const metadata: Metadata = { title: "NEXT AI" };

export default async function AssistantPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const user = await requireStudentPage();
  const { q } = await searchParams;
  return (
    <Assistant
      initial={history(user.id)}
      firstName={user.shortName.split(" ")[0]}
      mode={process.env.DEEPSEEK_API_KEY ? "llm" : "fallback"}
      prefill={q?.slice(0, 500) ?? null}
    />
  );
}
