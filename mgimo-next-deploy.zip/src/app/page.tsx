import { redirect } from "next/navigation";
import { requireUser } from "@/server/auth";

export default async function Home() {
  const u = await requireUser();
  redirect(u.role === "staff" ? "/staff" : "/schedule");
}
