import Link from "next/link";
import { Monogram } from "@/components/shell/Logo";

export default function NotFound() {
  return (
    <main className="flex min-h-dvh flex-col items-center justify-center px-6 text-center">
      <Monogram size={44} />
      <h1 className="mt-5 text-[22px] font-semibold tracking-[-0.02em]">Страница не найдена</h1>
      <p className="mt-1 max-w-sm text-[14px] text-ink-3">Возможно, ссылка устарела или у вас нет доступа к этим данным.</p>
      <Link href="/" className="press mt-5 inline-flex h-11 items-center rounded-xl bg-primary px-5 text-[14px] font-semibold text-white">
        На главную
      </Link>
    </main>
  );
}
