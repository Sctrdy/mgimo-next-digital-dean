"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Loader2, GraduationCap, Briefcase, Eye, EyeOff } from "lucide-react";
import { Monogram } from "@/components/shell/Logo";
import { Disclaimer } from "@/components/ui/kit";

const DEMO = [
  { login: "alina", name: "Алина Воронцова", role: "Студентка, 2 курс, МО", icon: GraduationCap },
  { login: "matvey", name: "Матвей Лебедев", role: "Студент, 3 курс, экономика", icon: GraduationCap },
  { login: "dekanat", name: "Елена Карпова", role: "Сотрудник деканата", icon: Briefcase },
];

export default function LoginPage() {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [show, setShow] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  async function signIn(l: string, p: string) {
    setBusy(l || "form");
    setError(null);
    try {
      const r = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ login: l, password: p }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error ?? "Не удалось войти");
      router.replace(d.home);
      router.refresh();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Не удалось войти. Проверьте соединение.");
      setBusy(null);
    }
  }

  return (
    <main className="flex min-h-dvh flex-col bg-bg px-4 pt-safe">
      <div className="mx-auto flex w-full max-w-[420px] flex-1 flex-col justify-center py-10">
        <div className="flex items-center gap-3">
          <Monogram size={44} />
          <div>
            <p className="text-[19px] font-semibold tracking-[-0.02em]">
              MGIMO <span className="font-bold text-primary">NEXT</span>
            </p>
            <p className="text-[13px] text-ink-3">Цифровой деканат</p>
          </div>
        </div>

        <h1 className="mt-10 text-[30px] font-semibold leading-[1.08] tracking-[-0.035em]">
          Расписание, оценки, справки и ассистент в одном месте
        </h1>
        <p className="mt-3 text-[15px] text-ink-2">Войдите, чтобы увидеть свой учебный день.</p>

        <form
          className="mt-7 space-y-3"
          onSubmit={(e) => {
            e.preventDefault();
            signIn(login, password);
          }}
        >
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Логин</span>
            <input
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              autoComplete="username"
              autoCapitalize="none"
              className="h-12 w-full rounded-xl border border-line-strong bg-surface px-3.5 text-[16px] outline-none focus:border-primary"
              placeholder="alina"
            />
          </label>
          <label className="block">
            <span className="mb-1.5 block text-[13px] font-medium text-ink-2">Пароль</span>
            <span className="relative block">
              <input
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                type={show ? "text" : "password"}
                autoComplete="current-password"
                className="h-12 w-full rounded-xl border border-line-strong bg-surface px-3.5 pr-12 text-[16px] outline-none focus:border-primary"
              />
              <button
                type="button"
                onClick={() => setShow((s) => !s)}
                className="absolute right-1 top-1 flex h-10 w-10 items-center justify-center rounded-lg text-ink-3"
                aria-label={show ? "Скрыть пароль" : "Показать пароль"}
              >
                {show ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </span>
          </label>
          {error && (
            <p role="alert" className="rounded-xl bg-red-soft px-3.5 py-2.5 text-[13.5px] text-red">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={!!busy}
            className="press flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-[15px] font-semibold text-white disabled:opacity-60"
          >
            {busy === "form" && <Loader2 size={18} className="animate-spin" />}
            Войти
          </button>
        </form>

        <div className="mt-8">
          <p className="mb-2.5 text-[13px] font-medium text-ink-2">Демо-аккаунты, пароль demo2026</p>
          <ul className="overflow-hidden rounded-2xl border border-line bg-surface">
            {DEMO.map((d, i) => (
              <li key={d.login} className={i ? "border-t border-line" : ""}>
                <button
                  onClick={() => signIn(d.login, "demo2026")}
                  disabled={!!busy}
                  className="press flex w-full items-center gap-3 px-3.5 py-3 text-left hover:bg-surface-2 disabled:opacity-60"
                >
                  <span className={`flex h-9 w-9 items-center justify-center rounded-xl ${d.login === "dekanat" ? "bg-violet-soft text-violet-ink" : "bg-primary-soft text-primary-soft-ink"}`}>
                    <d.icon size={18} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-[14.5px] font-semibold">{d.name}</span>
                    <span className="block text-[12.5px] text-ink-3">{d.role}</span>
                  </span>
                  {busy === d.login ? <Loader2 size={17} className="animate-spin text-ink-3" /> : <span className="text-[13px] font-semibold text-primary-soft-ink">Войти</span>}
                </button>
              </li>
            ))}
          </ul>
        </div>

        <Disclaimer className="mt-8" />
      </div>
    </main>
  );
}
