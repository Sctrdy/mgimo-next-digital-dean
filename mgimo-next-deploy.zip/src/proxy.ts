import { NextResponse, type NextRequest } from "next/server";

// Оптимистичная проверка: есть ли cookie сессии. Настоящая проверка — на сервере
// в каждой странице и API (requireUser / apiUser).
export function proxy(req: NextRequest) {
  if (!req.cookies.get("mn_session")) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.search = "";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!login|api|_next|.*\\..*).*)"],
};
