// Сквозная проверка живого сервера: авторизация, разделение данных, роли, заявка → статус → уведомление.
// Запуск на свежей демо-базе: node scripts/smoke.mjs [http://localhost:3100]
// (NEXT AI с подключённой моделью может отказаться создавать дубль, если похожая заявка уже есть — это ожидаемо)
const B = process.argv[2] ?? "http://localhost:3100";
let fails = 0;
const ok = (cond, msg) => {
  console.log(`${cond ? "✓" : "✗"} ${msg}`);
  if (!cond) fails++;
};

async function login(login) {
  const r = await fetch(`${B}/api/auth/login`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ login, password: "demo2026" }) });
  const cookie = r.headers.get("set-cookie")?.split(";")[0];
  return (path, init = {}) =>
    fetch(`${B}${path}`, { redirect: "manual", ...init, headers: { cookie, origin: B, "content-type": "application/json", ...(init.headers ?? {}) } });
}

const bad = await fetch(`${B}/api/auth/login`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ login: "alina", password: "nope" }) });
ok(bad.status === 401, "неверный пароль отклоняется");

const A = await login("alina");
const M = await login("matvey");
const S = await login("dekanat");

ok((await fetch(`${B}/api/notifications`)).status === 401, "API без сессии → 401");

const created = await A("/api/requests", {
  method: "POST",
  body: JSON.stringify({ typeCode: "study_certificate", purpose: "Для банка", language: "ru", delivery: "electronic" }),
});
const { request } = await created.json();
ok(created.status === 200 && request?.status === "submitted", `студент создаёт заявку (${request?.number})`);

ok((await M(`/dean/${request.id}`)).status === 404, "другой студент не видит чужую заявку (страница → 404)");
ok((await M(`/api/requests/${request.id}/document`)).status === 404, "другой студент не получает чужой документ");
ok((await A(`/api/staff/requests/${request.id}`, { method: "PATCH", body: JSON.stringify({ status: "ready" }) })).status === 403, "студент не может менять статусы");
ok(
  (await S(`/api/staff/requests/${request.id}`, { method: "PATCH", headers: { origin: "http://evil.example" }, body: JSON.stringify({ status: "in_progress" }) })).status === 403,
  "запрос с чужого origin отклоняется",
);
ok((await S(`/api/staff/requests/${request.id}`, { method: "PATCH", body: JSON.stringify({ status: "ready" }) })).status === 409, "нельзя перепрыгнуть этап");
ok((await S(`/api/staff/requests/${request.id}`, { method: "PATCH", body: JSON.stringify({ status: "in_progress" }) })).status === 200, "сотрудник берёт в работу");
ok((await S(`/api/staff/requests/${request.id}`, { method: "PATCH", body: JSON.stringify({ status: "ready", comment: "PDF готов" }) })).status === 200, "сотрудник отмечает готовность");

const notes = await (await A("/api/notifications")).json();
ok(notes.items.some((n) => n.body.includes(request.number) && n.title.includes("готово")), "студент получил уведомление о готовности");
const mNotes = await (await M("/api/notifications")).json();
ok(!mNotes.items.some((n) => n.body.includes(request.number)), "другой студент уведомление не получил");
ok((await A(`/api/requests/${request.id}/document`)).status === 200, "владелец открывает готовый документ");

ok((await A("/staff")).status === 307, "студента не пускает в кабинет сотрудника");
ok((await S("/schedule")).status === 307, "сотрудника перенаправляет из студенческого расписания");

for (const p of ["/schedule", "/study", "/assistant", "/dean", "/dean/new", "/profile"]) {
  ok((await A(p)).status === 200, `alina: страница ${p} открывается`);
  ok((await M(p)).status === 200, `matvey: страница ${p} открывается`);
}
for (const p of ["/staff", `/staff/${request.id}`, "/profile"]) ok((await S(p)).status === 200, `сотрудник: страница ${p} открывается`);
ok((await M("/schedule?view=week")).status === 200, "недельный вид открывается");

const found = await (await S(`/api/search?q=${encodeURIComponent("лебедев")}`)).json();
ok(found.hits?.length > 0, "поиск сотрудника по кириллице без учёта регистра");
const own = await (await A(`/api/search?q=${encodeURIComponent("экономика")}`)).json();
ok(own.hits?.length > 0 && !JSON.stringify(own).includes("Эконометрика"), "поиск студента находит только его дисциплины");

const ics = await A("/api/calendar");
const icsText = await ics.text();
ok(ics.status === 200 && ics.headers.get("content-type")?.startsWith("text/calendar") && /DTSTART:\d{8}T\d{6}Z/.test(icsText), "экспорт .ics в UTC");

const chat = await A("/api/ai/chat", { method: "POST", body: JSON.stringify({ message: "Подготовь выписку оценок на английском для программы обмена" }) });
const cj = await chat.json();
ok(chat.status === 200 && cj.message?.meta?.draft?.draftId, `NEXT AI готовит черновик заявки${cj.message?.meta?.fallback ? " (резервный режим)" : ""}`);
if (cj.message?.meta?.draft) {
  const draftId = cj.message.meta.draft.draftId;
  ok((await M("/api/ai/confirm", { method: "POST", body: JSON.stringify({ draftId }) })).status === 404, "чужой черновик подтвердить нельзя");
  const conf = await A("/api/ai/confirm", { method: "POST", body: JSON.stringify({ draftId }) });
  const cf = await conf.json();
  ok(conf.status === 200 && cf.request?.source === "ai", `подтверждение создаёт настоящую заявку (${cf.request?.number})`);
  ok((await A("/api/ai/confirm", { method: "POST", body: JSON.stringify({ draftId }) })).status === 409, "повторное подтверждение не создаёт дубль");
}

console.log(fails ? `\n${fails} проверок не прошло` : "\nВсе проверки пройдены");
process.exit(fails ? 1 : 0);
