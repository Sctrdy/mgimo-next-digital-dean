# MGIMO NEXT Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Working mobile-first web prototype MGIMO NEXT: schedule, academics, NEXT AI (DeepSeek + actions), dean requests with staff cabinet, profile.

**Architecture:** Next.js App Router monolith. SQLite (better-sqlite3) accessed only from server code (`src/server/*`). Session cookie auth; every data function takes `userId` from the session. NEXT AI = server-side tool-calling loop against DeepSeek's OpenAI-compatible API, with rule-based fallback.

**Tech Stack:** Next.js 15+, TypeScript, Tailwind (v4 if scaffolded), lucide-react, better-sqlite3, bcryptjs, node:test via `tsx` for server tests.

**Spec:** `docs/superpowers/specs/2026-11-20-mgimo-next-design.md`

## Global Constraints

- Palette: Deep Navy #07172F, Primary #1769E0, Cyan #45C9FF, Violet #7657D8, Light BG #F4F7FC, White #FFFFFF.
- All time logic in `Europe/Moscow` explicitly (server may run in UTC).
- Seed data is relative to "today" (week template + day offsets), resolved at query time — never frozen dates.
- Disclaimer on every page: «MGIMO NEXT — неофициальный конкурсный прототип. Все данные демонстрационные и вымышленные».
- No real people, no official MGIMO logo; monogram N is original SVG.
- Works from 360 px, no horizontal scroll, safe-area insets, Light/Dark.
- `.env*`, `*.db` gitignored. DeepSeek key only server-side (`DEEPSEEK_API_KEY`, `DEEPSEEK_MODEL` default `deepseek-chat`).
- Tool loop cap: 5 iterations. Model never supplies userId. Request creation only via user-clicked confirm POST.

## Review Focus

1. Student A requests B's request/draft by id → 404 (test in Task 2/4).
2. Student calls staff endpoint → 403 (Task 4).
3. Exam in the past must never appear in «Важное для тебя» / prep suggestions (Task 3 test).
4. Evening after classes → schedule shows next study day's first lesson, skipping Sunday (Task 3 test).
5. DeepSeek unavailable / no key → assistant still answers via fallback, no crash (Task 5).

---

### Task 1: Scaffold, DB, auth, shell
**Files:** project scaffold; `src/server/db.ts` (open + migrate + seed), `src/server/seed.ts`, `src/server/auth.ts`, `src/middleware.ts`, `src/app/login/page.tsx`, `src/app/(app)/layout.tsx`, `src/components/shell/*` (BottomNav, SideNav, TopBar, Logo, ThemeToggle), `src/app/globals.css`.
**Produces:** `getDb(): Database`; `getSession(): Promise<{user: User} | null>`; `requireUser(): Promise<User>`; `requireStaff(): Promise<User>`; `login(login, password)`, `logout()`; `User = {id, login, role:'student'|'staff', fullName, ...}`.
- [ ] Scaffold Next (`--ts --tailwind --app --src-dir --use-npm`), verify better-sqlite3 loads, add to `serverExternalPackages`.
- [ ] Schema: users, sessions, courses, lesson_templates (weekday, slot, course, type, room, teacher, week parity), lesson_changes (day_offset, …), assessments (course, kind, day_offset, grade?), grades, tasks, request_types, requests, request_events, notifications, chat_messages, drafts.
- [ ] Seed: students `ivanova` / `petrov` (pw `demo2026`), staff `dekanat` (pw `demo2026`); different faculties/groups/schedules/grades.
- [ ] Login page, middleware cookie check, app shell with nav + theme, disclaimer. `npm run build` passes. Commit.

### Task 2: Domain/time library + tests
**Files:** `src/server/time.ts`, `src/server/schedule.ts`, `src/server/academics.ts`, `tests/*.test.ts`.
**Produces:** `moscowNow(): Date-like {dateISO, minutes}`; `getLessons(userId, fromISO, toISO): Lesson[]`; `getDayStatus(userId, now): {kind:'during'|'before'|'after', lesson, minutesLeft}`; `getUpcomingAssessments(userId)`; `getAcademicSummary(userId)`; `getImportant(userId): ImportantItem[]` (each has `action:{label, href}`).
- [ ] Tests: past exam excluded from important; after last lesson → next study day; Sunday skipped; average computed from grades. Implement. Pass. Commit.

### Task 3: Schedule screen
**Files:** `src/app/(app)/schedule/page.tsx`, `src/components/schedule/*`, `src/app/api/tasks/route.ts`, `src/app/api/calendar.ics/route.ts`.
- [ ] Week strip, Day/Week toggle, timeline with breaks, now/countdown, lesson sheet, «Важное для тебя», quick actions, tasks CRUD, .ics export. Commit.

### Task 4: Dean (student + staff) + notifications
**Files:** `src/server/requests.ts`, `src/app/(app)/dean/*`, `src/app/(app)/staff/*`, `src/app/api/requests/*`, `src/app/api/notifications/*`, `tests/security.test.ts`.
**Produces:** `listRequests(userId, filter)`, `getRequest(userId, id)`, `createRequest(userId, input)`, `staffUpdateStatus(staffId, id, status, comment)`, `notify(userId, …)`.
- [ ] Security tests (A↔B isolation, staff 403, foreign draft confirm rejected). Implement. Multi-step form (fill → check → confirm). Staff cabinet. Commit.

### Task 5: NEXT AI
**Files:** `src/server/ai/tools.ts`, `src/server/ai/deepseek.ts`, `src/server/ai/fallback.ts`, `src/app/api/ai/chat/route.ts`, `src/app/api/ai/confirm/route.ts`, `src/app/(app)/assistant/page.tsx`.
- [ ] Tools bound to session user; `prepare_request` stores draft → UI preview card → confirm POST creates request. Fallback without key. Commit.

### Task 6: Study, Profile, polish, verification
- [ ] Academic Radar with SVG charts from data; Profile card (DEMO), events, settings, logout; loading/empty/error states; check 360 px + desktop, light/dark in browser; `npm run build` clean. Commit.
