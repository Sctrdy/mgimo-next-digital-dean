import { test } from "node:test";
import assert from "node:assert/strict";
import { getDb } from "../src/server/db";
import { getDayStatus, getLessons } from "../src/server/schedule";
import { getImportant } from "../src/server/important";
import { getAcademicSummary } from "../src/server/academics";
import { getRequest, createRequest, staffUpdate, listRequests } from "../src/server/requests";
import { listNotifications } from "../src/server/notifications";
import { toPublic } from "../src/server/users";

const db = getDb();
const user = (login: string) => toPublic(db.prepare("SELECT * FROM users WHERE login = ?").get(login) as never);
const alina = user("alina");
const matvey = user("matvey");
const staff = user("dekanat");
const FRI = "2026-11-20";

test("после последней пары показывается ближайшая пара следующего учебного дня", () => {
  const s = getDayStatus(alina.id, { date: FRI, minutes: 21 * 60 });
  assert.equal(s.kind, "next_day");
  if (s.kind === "next_day") assert.equal(s.date, "2026-11-21");
});

test("воскресенье пропускается: в субботу вечером следующая пара — в понедельник", () => {
  const s = getDayStatus(alina.id, { date: "2026-11-21", minutes: 22 * 60 });
  assert.equal(s.kind, "next_day");
  if (s.kind === "next_day") assert.equal(s.date, "2026-11-23");
});

test("во время пары — «сейчас идёт» и сколько осталось", () => {
  const s = getDayStatus(alina.id, { date: FRI, minutes: 11 * 60 });
  assert.equal(s.kind, "during");
  if (s.kind === "during") assert.equal(s.minutesLeft, 50);
});

test("в воскресенье занятий нет", () => {
  assert.equal(getLessons(alina.id, "2026-11-22", "2026-11-22", { date: FRI, minutes: 0 }).length, 0);
});

test("прошедший экзамен не попадает в «Важное», будущий — попадает", () => {
  const course = db.prepare("SELECT id FROM courses WHERE user_id = ? LIMIT 1").get(alina.id) as { id: number };
  const id = db.prepare("INSERT INTO assessments (user_id,course_id,kind,title,offset_days,time,room,score,max_score) VALUES (?,?,?,?,?,?,?,?,?)")
    .run(alina.id, course.id, "Экзамен", "Тестовый экзамен", 0, "09:00", "А-1", null, 30).lastInsertRowid;
  const morning = getImportant(alina.id, { date: FRI, minutes: 8 * 60 });
  const evening = getImportant(alina.id, { date: FRI, minutes: 21 * 60 });
  assert.ok(morning.some((i) => i.id === `a${id}`));
  assert.ok(!evening.some((i) => i.id === `a${id}`));
  for (const i of evening) assert.ok(i.action.href.length > 0, "у каждого пункта есть действие");
  db.prepare("DELETE FROM assessments WHERE id = ?").run(id);
});

test("средний балл считается из оценок студента", () => {
  const s = getAcademicSummary(matvey.id, { date: FRI, minutes: 600 });
  assert.equal(s.debts.length, 1);
  assert.equal(s.closed, s.totalClosedTarget - 1);
  assert.ok(s.average! > 60 && s.average! < 100);
});

test("студент не видит чужую заявку", () => {
  const foreign = listRequests(matvey.id)[0];
  assert.throws(() => getRequest(alina, foreign.id), (e: { status?: number }) => e.status === 404);
});

test("студент не может менять статусы", () => {
  const own = listRequests(alina.id)[0];
  assert.throws(() => staffUpdate(alina, own.id, { status: "issued" }), (e: { status?: number }) => e.status === 403);
});

test("смена статуса сотрудником создаёт уведомление владельцу", () => {
  const r = createRequest(alina, { typeCode: "study_certificate", purpose: "Для банка", copies: 1, language: "ru", delivery: "electronic" });
  assert.equal(r.status, "submitted");
  staffUpdate(staff, r.id, { status: "in_progress" });
  const n = listNotifications(alina.id);
  assert.ok(n.some((x) => x.body.includes(r.number) && x.title.includes("в работу")));
  assert.ok(!listNotifications(matvey.id).some((x) => x.body.includes(r.number)));
  assert.throws(() => staffUpdate(staff, r.id, { status: "submitted" }), (e: { status?: number }) => e.status === 409);
});
